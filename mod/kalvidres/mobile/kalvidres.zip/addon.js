angular.module('mm.addons.mod_kalvidres', ['mm.core'])
.constant('mmaModKalvidresComponent', 'mmaModKalvidres')
.config(["$stateProvider", function($stateProvider) {
    $stateProvider
    .state('site.mod_kalvidres', {
      url: '/mod_kalvidres',
      params: {
        module: null,
        courseid: null
      },
      views: {
        'site': {
          controller: 'mmaModKalvidresIndexCtrl',
          templateUrl: '$ADDONPATH$/templates/index.html'
        }
      }
    });
}])
.config(["$mmCourseDelegateProvider", "$mmCoursePrefetchDelegateProvider", "$mmContentLinksDelegateProvider", function($mmCourseDelegateProvider, $mmCoursePrefetchDelegateProvider, $mmContentLinksDelegateProvider) {
    $mmCourseDelegateProvider.registerContentHandler('mmaModKalvidres', 'kalvidres', '$mmaModKalvidresHandlers.courseContent');
    $mmCoursePrefetchDelegateProvider.registerPrefetchHandler('mmaModKalvidres', 'kalvidres', '$mmaModKalvidresPrefetchHandler');
    $mmContentLinksDelegateProvider.registerLinkHandler('mmaModKalvidres', '$mmaModKalvidresHandlers.linksHandler');
}]);

angular.module('mm.addons.mod_kalvidres')
    .controller('mmaModKalvidresIndexCtrl', ["$scope", "$stateParams", "$translate", "$mmUtil", "$mmaModKalvidres", "$mmCourse", "$q", "$log", "$mmApp", "mmaModKalvidresComponent", "$mmText", "$mmaModKalvidresPrefetchHandler", "$mmCourseHelper", function ($scope, $stateParams, $translate, $mmUtil, $mmaModKalvidres, $mmCourse, $q, $log, $mmApp,
                                                      mmaModKalvidresComponent, $mmText, $mmaModKalvidresPrefetchHandler, $mmCourseHelper) {
        $log = $log.getInstance('mmaModKalvidresIndexCtrl');
        var module = $stateParams.module || {},
            courseId = $stateParams.courseid;
        $scope.title = module.name;
        $scope.description = module.description;
        $scope.component = mmaModKalvidresComponent;
        $scope.componentId = module.id;
        $scope.externalUrl = module.url;
        $scope.loaded = false;
        $scope.refreshIcon = 'spinner';
        function fetchContent(refresh) {
            return $mmaModKalvidres.getKalturaVideo(courseId, module.id).catch(function (error) {
                $mmUtil.showErrorModalDefault(error, 'mma.mod_kalvidres.errorwhileloadingthevideo', true);
                return $q.reject();
            }).then(function (currentKalturaVideo) {
                $scope.title = currentKalturaVideo.name;
                $scope.description = currentKalturaVideo.intro || currentKalturaVideo.description;
                $scope.videourl = currentKalturaVideo.videourl;
            }).then(
                $mmCourseHelper.fillContextMenu($scope, module, courseId, refresh, mmaModKalvidresComponent)
            ).finally(function () {
                $scope.loaded = true;
                $scope.refreshIcon = 'ion-refresh';
            });
        }
        $scope.removeFiles = function () {
            $mmCourseHelper.confirmAndRemove(module, courseId);
        };
        $scope.prefetch = function () {
            $mmCourseHelper.contextMenuPrefetch($scope, module, courseId);
        };
        $scope.expandDescription = function () {
            $mmText.expandText($translate.instant('mm.core.description'), $scope.description, false, mmaModKalvidresComponent, module.id);
        };
        $scope.doRefresh = function () {
            if ($scope.loaded) {
                $scope.refreshIcon = 'spinner';
                return $mmaModKalvidres.invalidateContent(module.id, courseId).then(function () {
                    return fetchContent(true);
                }).finally(function () {
                    $scope.$broadcast('scroll.refreshComplete');
                });
            }
        };
        fetchContent().then(function () {
            $mmaModKalvidres.logView(module.instance).then(function () {
                $mmCourse.checkModuleCompletion(courseId, module.completionstatus);
            });
        });
    }]);

angular.module('mm.addons.mod_kalvidres')
.factory('$mmaModKalvidresHandlers', ["$mmCourse", "$mmaModKalvidres", "$mmEvents", "$state", "$mmSite", "$mmCourseHelper", "$mmUtil", "$mmCoursePrefetchDelegate", "mmCoreDownloading", "mmCoreNotDownloaded", "mmCoreOutdated", "mmCoreEventPackageStatusChanged", "mmaModKalvidresComponent", "$mmContentLinksHelper", "$mmaModKalvidresPrefetchHandler", function($mmCourse, $mmaModKalvidres, $mmEvents, $state, $mmSite, $mmCourseHelper, $mmUtil,
            $mmCoursePrefetchDelegate, mmCoreDownloading, mmCoreNotDownloaded, mmCoreOutdated, mmCoreEventPackageStatusChanged,
            mmaModKalvidresComponent, $mmContentLinksHelper, $mmaModKalvidresPrefetchHandler) {
    var self = {};
    self.courseContent = function() {
        var self = {};
        self.isEnabled = function() {
            return $mmaModKalvidres.isPluginEnabled();
        };
        self.getController = function(module, courseid) {
            return function($scope) {
                var downloadBtn,
                    refreshBtn;
                downloadBtn = {
                    hidden: true,
                    icon: 'ion-ios-cloud-download-outline',
                    label: 'mm.core.download',
                    action: function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        download(false);
                    }
                };
                refreshBtn = {
                    icon: 'ion-android-refresh',
                    label: 'mm.core.refresh',
                    hidden: true,
                    action: function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        download(true);
                    }
                };
                $scope.title = module.name;
                $scope.icon = '$ADDONPATH$/img/icon.gif';
                $scope.class = 'mma-mod_kalvidres-handler';
                $scope.buttons = [downloadBtn, refreshBtn];
                $scope.spinner = true; 
                $scope.action = function(e) {
                    if (e) {
                        e.preventDefault();
                        e.stopPropagation();
                    }
                    $state.go('site.mod_kalvidres', {module: module, courseid: courseid});
                };
                function download(refresh) {
                    var dwnBtnHidden = downloadBtn.hidden,
                        rfrshBtnHidden = refreshBtn.hidden;
                    $scope.spinner = true;
                    downloadBtn.hidden = true;
                    refreshBtn.hidden = true;
                    $mmaModKalvidresPrefetchHandler.getDownloadSize(module, courseid).then(function(size) {
                        $mmCourseHelper.prefetchModule($scope, $mmaModKalvidresPrefetchHandler, module, size, refresh, courseid)
                                .catch(function() {
                            $scope.spinner = false;
                            downloadBtn.hidden = dwnBtnHidden;
                            refreshBtn.hidden = rfrshBtnHidden;
                        });
                    }).catch(function(error) {
                        $scope.spinner = false;
                        downloadBtn.hidden = dwnBtnHidden;
                        refreshBtn.hidden = rfrshBtnHidden;
                        if (error) {
                            $mmUtil.showErrorModal(error);
                        } else {
                            $mmUtil.showErrorModal('mm.core.errordownloading', true);
                        }
                    });
                }
                function showStatus(status) {
                    if (status) {
                        $scope.spinner = status === mmCoreDownloading;
                        downloadBtn.hidden = status !== mmCoreNotDownloaded;
                        refreshBtn.hidden = status !== mmCoreOutdated;
                    }
                }
                var statusObserver = $mmEvents.on(mmCoreEventPackageStatusChanged, function(data) {
                    if (data.siteid === $mmSite.getId() && data.componentId === module.id && data.component === mmaModKalvidresComponent) {
                        showStatus(data.status);
                    }
                });
                $mmCoursePrefetchDelegate.getModuleStatus(module, courseid).then(showStatus);
                $scope.$on('$destroy', function() {
                    statusObserver && statusObserver.off && statusObserver.off();
                });
            };
        };
        return self;
    };
    self.linksHandler = $mmContentLinksHelper.createModuleIndexLinkHandler('mmaModKalvidres', 'kalvidres', $mmaModKalvidres);
    return self;
}]);

angular.module('mm.addons.mod_kalvidres')
    .factory('$mmaModKalvidresKalturalib', function () {
        !function (a, b) {
            "use strict";
            "object" == typeof module && "object" == typeof module.exports ? module.exports = a.document ? b(a, !0) : function (a) {
                if (!a.document)throw new Error("jQuery requires a window with a document");
                return b(a)
            } : b(a)
        }("undefined" != typeof window ? window : this, function (a, b) {
            "use strict";
            var c = [], d = a.document, e = Object.getPrototypeOf, f = c.slice, g = c.concat, h = c.push, i = c.indexOf, j = {}, k = j.toString, l = j.hasOwnProperty,
                m = l.toString, n = m.call(Object), o = {};
            function p(a, b) {
                b = b || d;
                var c = b.createElement("script");
                c.text = a, b.head.appendChild(c).parentNode.removeChild(c)
            }
            var q = "3.2.1", r = function (a, b) {
                return new r.fn.init(a, b)
            }, s = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, t = /^-ms-/, u = /-([a-z])/g, v = function (a, b) {
                return b.toUpperCase()
            };
            r.fn = r.prototype = {
                jquery: q, constructor: r, length: 0, toArray: function () {
                    return f.call(this)
                }, get: function (a) {
                    return null == a ? f.call(this) : a < 0 ? this[a + this.length] : this[a]
                }, pushStack: function (a) {
                    var b = r.merge(this.constructor(), a);
                    return b.prevObject = this, b
                }, each: function (a) {
                    return r.each(this, a)
                }, map: function (a) {
                    return this.pushStack(r.map(this, function (b, c) {
                        return a.call(b, c, b)
                    }))
                }, slice: function () {
                    return this.pushStack(f.apply(this, arguments))
                }, first: function () {
                    return this.eq(0)
                }, last: function () {
                    return this.eq(-1)
                }, eq: function (a) {
                    var b = this.length, c = +a + (a < 0 ? b : 0);
                    return this.pushStack(c >= 0 && c < b ? [this[c]] : [])
                }, end: function () {
                    return this.prevObject || this.constructor()
                }, push: h, sort: c.sort, splice: c.splice
            }, r.extend = r.fn.extend = function () {
                var a, b, c, d, e, f, g = arguments[0] || {}, h = 1, i = arguments.length, j = !1;
                for ("boolean" == typeof g && (j = g, g = arguments[h] || {}, h++), "object" == typeof g || r.isFunction(g) || (g = {}), h === i && (g = this, h--); h < i; h++)if (null != (a = arguments[h]))for (b in a)c = g[b], d = a[b], g !== d && (j && d && (r.isPlainObject(d) || (e = Array.isArray(d))) ? (e ? (e = !1, f = c && Array.isArray(c) ? c : []) : f = c && r.isPlainObject(c) ? c : {}, g[b] = r.extend(j, f, d)) : void 0 !== d && (g[b] = d));
                return g
            }, r.extend({
                expando: "jQuery" + (q + Math.random()).replace(/\D/g, ""), isReady: !0, error: function (a) {
                    throw new Error(a)
                }, noop: function () {
                }, isFunction: function (a) {
                    return "function" === r.type(a)
                }, isWindow: function (a) {
                    return null != a && a === a.window
                }, isNumeric: function (a) {
                    var b = r.type(a);
                    return ("number" === b || "string" === b) && !isNaN(a - parseFloat(a))
                }, isPlainObject: function (a) {
                    var b, c;
                    return !(!a || "[object Object]" !== k.call(a)) && (!(b = e(a)) || (c = l.call(b, "constructor") && b.constructor, "function" == typeof c && m.call(c) === n))
                }, isEmptyObject: function (a) {
                    var b;
                    for (b in a)return !1;
                    return !0
                }, type: function (a) {
                    return null == a ? a + "" : "object" == typeof a || "function" == typeof a ? j[k.call(a)] || "object" : typeof a
                }, globalEval: function (a) {
                    p(a)
                }, camelCase: function (a) {
                    return a.replace(t, "ms-").replace(u, v)
                }, each: function (a, b) {
                    var c, d = 0;
                    if (w(a)) {
                        for (c = a.length; d < c; d++)if (b.call(a[d], d, a[d]) === !1)break
                    } else for (d in a)if (b.call(a[d], d, a[d]) === !1)break;
                    return a
                }, trim: function (a) {
                    return null == a ? "" : (a + "").replace(s, "")
                }, makeArray: function (a, b) {
                    var c = b || [];
                    return null != a && (w(Object(a)) ? r.merge(c, "string" == typeof a ? [a] : a) : h.call(c, a)), c
                }, inArray: function (a, b, c) {
                    return null == b ? -1 : i.call(b, a, c)
                }, merge: function (a, b) {
                    for (var c = +b.length, d = 0, e = a.length; d < c; d++)a[e++] = b[d];
                    return a.length = e, a
                }, grep: function (a, b, c) {
                    for (var d, e = [], f = 0, g = a.length, h = !c; f < g; f++)d = !b(a[f], f), d !== h && e.push(a[f]);
                    return e
                }, map: function (a, b, c) {
                    var d, e, f = 0, h = [];
                    if (w(a))for (d = a.length; f < d; f++)e = b(a[f], f, c), null != e && h.push(e); else for (f in a)e = b(a[f], f, c), null != e && h.push(e);
                    return g.apply([], h)
                }, guid: 1, proxy: function (a, b) {
                    var c, d, e;
                    if ("string" == typeof b && (c = a[b], b = a, a = c), r.isFunction(a))return d = f.call(arguments, 2), e = function () {
                        return a.apply(b || this, d.concat(f.call(arguments)))
                    }, e.guid = a.guid = a.guid || r.guid++, e
                }, now: Date.now, support: o
            }), "function" == typeof Symbol && (r.fn[Symbol.iterator] = c[Symbol.iterator]), r.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function (a, b) {
                j["[object " + b + "]"] = b.toLowerCase()
            });
            function w(a) {
                var b = !!a && "length" in a && a.length, c = r.type(a);
                return "function" !== c && !r.isWindow(a) && ("array" === c || 0 === b || "number" == typeof b && b > 0 && b - 1 in a)
            }
            var x = function (a) {
                var b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u = "sizzle" + 1 * new Date, v = a.document, w = 0, x = 0, y = ha(), z = ha(), A = ha(),
                    B = function (a, b) {
                        return a === b && (l = !0), 0
                    }, C = {}.hasOwnProperty, D = [], E = D.pop, F = D.push, G = D.push, H = D.slice, I = function (a, b) {
                        for (var c = 0, d = a.length; c < d; c++)if (a[c] === b)return c;
                        return -1
                    }, J = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped", K = "[\\x20\\t\\r\\n\\f]",
                    L = "(?:\\\\.|[\\w-]|[^\0-\\xa0])+",
                    M = "\\[" + K + "*(" + L + ")(?:" + K + "*([*^$|!~]?=)" + K + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + L + "))|)" + K + "*\\]",
                    N = ":(" + L + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + M + ")*)|.*)\\)|)", O = new RegExp(K + "+", "g"),
                    P = new RegExp("^" + K + "+|((?:^|[^\\\\])(?:\\\\.)*)" + K + "+$", "g"), Q = new RegExp("^" + K + "*," + K + "*"),
                    R = new RegExp("^" + K + "*([>+~]|" + K + ")" + K + "*"), S = new RegExp("=" + K + "*([^\\]'\"]*?)" + K + "*\\]", "g"), T = new RegExp(N),
                    U = new RegExp("^" + L + "$"), V = {
                        ID: new RegExp("^#(" + L + ")"),
                        CLASS: new RegExp("^\\.(" + L + ")"),
                        TAG: new RegExp("^(" + L + "|[*])"),
                        ATTR: new RegExp("^" + M),
                        PSEUDO: new RegExp("^" + N),
                        CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + K + "*(even|odd|(([+-]|)(\\d*)n|)" + K + "*(?:([+-]|)" + K + "*(\\d+)|))" + K + "*\\)|)", "i"),
                        bool: new RegExp("^(?:" + J + ")$", "i"),
                        needsContext: new RegExp("^" + K + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + K + "*((?:-\\d)?\\d*)" + K + "*\\)|)(?=[^-]|$)", "i")
                    }, W = /^(?:input|select|textarea|button)$/i, X = /^h\d$/i, Y = /^[^{]+\{\s*\[native \w/, Z = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/, $ = /[+~]/,
                    _ = new RegExp("\\\\([\\da-f]{1,6}" + K + "?|(" + K + ")|.)", "ig"), aa = function (a, b, c) {
                        var d = "0x" + b - 65536;
                        return d !== d || c ? b : d < 0 ? String.fromCharCode(d + 65536) : String.fromCharCode(d >> 10 | 55296, 1023 & d | 56320)
                    }, ba = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g, ca = function (a, b) {
                        return b ? "\0" === a ? "\ufffd" : a.slice(0, -1) + "\\" + a.charCodeAt(a.length - 1).toString(16) + " " : "\\" + a
                    }, da = function () {
                        m()
                    }, ea = ta(function (a) {
                        return a.disabled === !0 && ("form" in a || "label" in a)
                    }, {dir: "parentNode", next: "legend"});
                try {
                    G.apply(D = H.call(v.childNodes), v.childNodes), D[v.childNodes.length].nodeType
                } catch (fa) {
                    G = {
                        apply: D.length ? function (a, b) {
                            F.apply(a, H.call(b))
                        } : function (a, b) {
                            var c = a.length, d = 0;
                            while (a[c++] = b[d++]);
                            a.length = c - 1
                        }
                    }
                }
                function ga(a, b, d, e) {
                    var f, h, j, k, l, o, r, s = b && b.ownerDocument, w = b ? b.nodeType : 9;
                    if (d = d || [], "string" != typeof a || !a || 1 !== w && 9 !== w && 11 !== w)return d;
                    if (!e && ((b ? b.ownerDocument || b : v) !== n && m(b), b = b || n, p)) {
                        if (11 !== w && (l = Z.exec(a)))if (f = l[1]) {
                            if (9 === w) {
                                if (!(j = b.getElementById(f)))return d;
                                if (j.id === f)return d.push(j), d
                            } else if (s && (j = s.getElementById(f)) && t(b, j) && j.id === f)return d.push(j), d
                        } else {
                            if (l[2])return G.apply(d, b.getElementsByTagName(a)), d;
                            if ((f = l[3]) && c.getElementsByClassName && b.getElementsByClassName)return G.apply(d, b.getElementsByClassName(f)), d
                        }
                        if (c.qsa && !A[a + " "] && (!q || !q.test(a))) {
                            if (1 !== w) s = b, r = a; else if ("object" !== b.nodeName.toLowerCase()) {
                                (k = b.getAttribute("id")) ? k = k.replace(ba, ca) : b.setAttribute("id", k = u), o = g(a), h = o.length;
                                while (h--)o[h] = "#" + k + " " + sa(o[h]);
                                r = o.join(","), s = $.test(a) && qa(b.parentNode) || b
                            }
                            if (r)try {
                                return G.apply(d, s.querySelectorAll(r)), d
                            } catch (x) {
                            } finally {
                                k === u && b.removeAttribute("id")
                            }
                        }
                    }
                    return i(a.replace(P, "$1"), b, d, e)
                }
                function ha() {
                    var a = [];
                    function b(c, e) {
                        return a.push(c + " ") > d.cacheLength && delete b[a.shift()], b[c + " "] = e
                    }
                    return b
                }
                function ia(a) {
                    return a[u] = !0, a
                }
                function ja(a) {
                    var b = n.createElement("fieldset");
                    try {
                        return !!a(b)
                    } catch (c) {
                        return !1
                    } finally {
                        b.parentNode && b.parentNode.removeChild(b), b = null
                    }
                }
                function ka(a, b) {
                    var c = a.split("|"), e = c.length;
                    while (e--)d.attrHandle[c[e]] = b
                }
                function la(a, b) {
                    var c = b && a, d = c && 1 === a.nodeType && 1 === b.nodeType && a.sourceIndex - b.sourceIndex;
                    if (d)return d;
                    if (c)while (c = c.nextSibling)if (c === b)return -1;
                    return a ? 1 : -1
                }
                function ma(a) {
                    return function (b) {
                        var c = b.nodeName.toLowerCase();
                        return "input" === c && b.type === a
                    }
                }
                function na(a) {
                    return function (b) {
                        var c = b.nodeName.toLowerCase();
                        return ("input" === c || "button" === c) && b.type === a
                    }
                }
                function oa(a) {
                    return function (b) {
                        return "form" in b ? b.parentNode && b.disabled === !1 ? "label" in b ? "label" in b.parentNode ? b.parentNode.disabled === a : b.disabled === a : b.isDisabled === a || b.isDisabled !== !a && ea(b) === a : b.disabled === a : "label" in b && b.disabled === a
                    }
                }
                function pa(a) {
                    return ia(function (b) {
                        return b = +b, ia(function (c, d) {
                            var e, f = a([], c.length, b), g = f.length;
                            while (g--)c[e = f[g]] && (c[e] = !(d[e] = c[e]))
                        })
                    })
                }
                function qa(a) {
                    return a && "undefined" != typeof a.getElementsByTagName && a
                }
                c = ga.support = {}, f = ga.isXML = function (a) {
                    var b = a && (a.ownerDocument || a).documentElement;
                    return !!b && "HTML" !== b.nodeName
                }, m = ga.setDocument = function (a) {
                    var b, e, g = a ? a.ownerDocument || a : v;
                    return g !== n && 9 === g.nodeType && g.documentElement ? (n = g, o = n.documentElement, p = !f(n), v !== n && (e = n.defaultView) && e.top !== e && (e.addEventListener ? e.addEventListener("unload", da, !1) : e.attachEvent && e.attachEvent("onunload", da)), c.attributes = ja(function (a) {
                        return a.className = "i", !a.getAttribute("className")
                    }), c.getElementsByTagName = ja(function (a) {
                        return a.appendChild(n.createComment("")), !a.getElementsByTagName("*").length
                    }), c.getElementsByClassName = Y.test(n.getElementsByClassName), c.getById = ja(function (a) {
                        return o.appendChild(a).id = u, !n.getElementsByName || !n.getElementsByName(u).length
                    }), c.getById ? (d.filter.ID = function (a) {
                        var b = a.replace(_, aa);
                        return function (a) {
                            return a.getAttribute("id") === b
                        }
                    }, d.find.ID = function (a, b) {
                        if ("undefined" != typeof b.getElementById && p) {
                            var c = b.getElementById(a);
                            return c ? [c] : []
                        }
                    }) : (d.filter.ID = function (a) {
                        var b = a.replace(_, aa);
                        return function (a) {
                            var c = "undefined" != typeof a.getAttributeNode && a.getAttributeNode("id");
                            return c && c.value === b
                        }
                    }, d.find.ID = function (a, b) {
                        if ("undefined" != typeof b.getElementById && p) {
                            var c, d, e, f = b.getElementById(a);
                            if (f) {
                                if (c = f.getAttributeNode("id"), c && c.value === a)return [f];
                                e = b.getElementsByName(a), d = 0;
                                while (f = e[d++])if (c = f.getAttributeNode("id"), c && c.value === a)return [f]
                            }
                            return []
                        }
                    }), d.find.TAG = c.getElementsByTagName ? function (a, b) {
                        return "undefined" != typeof b.getElementsByTagName ? b.getElementsByTagName(a) : c.qsa ? b.querySelectorAll(a) : void 0
                    } : function (a, b) {
                        var c, d = [], e = 0, f = b.getElementsByTagName(a);
                        if ("*" === a) {
                            while (c = f[e++])1 === c.nodeType && d.push(c);
                            return d
                        }
                        return f
                    }, d.find.CLASS = c.getElementsByClassName && function (a, b) {
                            if ("undefined" != typeof b.getElementsByClassName && p)return b.getElementsByClassName(a)
                        }, r = [], q = [], (c.qsa = Y.test(n.querySelectorAll)) && (ja(function (a) {
                        o.appendChild(a).innerHTML = "<a id='" + u + "'></a><select id='" + u + "-\r\\' msallowcapture=''><option selected=''></option></select>", a.querySelectorAll("[msallowcapture^='']").length && q.push("[*^$]=" + K + "*(?:''|\"\")"), a.querySelectorAll("[selected]").length || q.push("\\[" + K + "*(?:value|" + J + ")"), a.querySelectorAll("[id~=" + u + "-]").length || q.push("~="), a.querySelectorAll(":checked").length || q.push(":checked"), a.querySelectorAll("a#" + u + "+*").length || q.push(".#.+[+~]")
                    }), ja(function (a) {
                        a.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
                        var b = n.createElement("input");
                        b.setAttribute("type", "hidden"), a.appendChild(b).setAttribute("name", "D"), a.querySelectorAll("[name=d]").length && q.push("name" + K + "*[*^$|!~]?="), 2 !== a.querySelectorAll(":enabled").length && q.push(":enabled", ":disabled"), o.appendChild(a).disabled = !0, 2 !== a.querySelectorAll(":disabled").length && q.push(":enabled", ":disabled"), a.querySelectorAll("*,:x"), q.push(",.*:")
                    })), (c.matchesSelector = Y.test(s = o.matches || o.webkitMatchesSelector || o.mozMatchesSelector || o.oMatchesSelector || o.msMatchesSelector)) && ja(function (a) {
                        c.disconnectedMatch = s.call(a, "*"), s.call(a, "[s!='']:x"), r.push("!=", N)
                    }), q = q.length && new RegExp(q.join("|")), r = r.length && new RegExp(r.join("|")), b = Y.test(o.compareDocumentPosition), t = b || Y.test(o.contains) ? function (a, b) {
                        var c = 9 === a.nodeType ? a.documentElement : a, d = b && b.parentNode;
                        return a === d || !(!d || 1 !== d.nodeType || !(c.contains ? c.contains(d) : a.compareDocumentPosition && 16 & a.compareDocumentPosition(d)))
                    } : function (a, b) {
                        if (b)while (b = b.parentNode)if (b === a)return !0;
                        return !1
                    }, B = b ? function (a, b) {
                        if (a === b)return l = !0, 0;
                        var d = !a.compareDocumentPosition - !b.compareDocumentPosition;
                        return d ? d : (d = (a.ownerDocument || a) === (b.ownerDocument || b) ? a.compareDocumentPosition(b) : 1, 1 & d || !c.sortDetached && b.compareDocumentPosition(a) === d ? a === n || a.ownerDocument === v && t(v, a) ? -1 : b === n || b.ownerDocument === v && t(v, b) ? 1 : k ? I(k, a) - I(k, b) : 0 : 4 & d ? -1 : 1)
                    } : function (a, b) {
                        if (a === b)return l = !0, 0;
                        var c, d = 0, e = a.parentNode, f = b.parentNode, g = [a], h = [b];
                        if (!e || !f)return a === n ? -1 : b === n ? 1 : e ? -1 : f ? 1 : k ? I(k, a) - I(k, b) : 0;
                        if (e === f)return la(a, b);
                        c = a;
                        while (c = c.parentNode)g.unshift(c);
                        c = b;
                        while (c = c.parentNode)h.unshift(c);
                        while (g[d] === h[d])d++;
                        return d ? la(g[d], h[d]) : g[d] === v ? -1 : h[d] === v ? 1 : 0
                    }, n) : n
                }, ga.matches = function (a, b) {
                    return ga(a, null, null, b)
                }, ga.matchesSelector = function (a, b) {
                    if ((a.ownerDocument || a) !== n && m(a), b = b.replace(S, "='$1']"), c.matchesSelector && p && !A[b + " "] && (!r || !r.test(b)) && (!q || !q.test(b)))try {
                        var d = s.call(a, b);
                        if (d || c.disconnectedMatch || a.document && 11 !== a.document.nodeType)return d
                    } catch (e) {
                    }
                    return ga(b, n, null, [a]).length > 0
                }, ga.contains = function (a, b) {
                    return (a.ownerDocument || a) !== n && m(a), t(a, b)
                }, ga.attr = function (a, b) {
                    (a.ownerDocument || a) !== n && m(a);
                    var e = d.attrHandle[b.toLowerCase()], f = e && C.call(d.attrHandle, b.toLowerCase()) ? e(a, b, !p) : void 0;
                    return void 0 !== f ? f : c.attributes || !p ? a.getAttribute(b) : (f = a.getAttributeNode(b)) && f.specified ? f.value : null
                }, ga.escape = function (a) {
                    return (a + "").replace(ba, ca)
                }, ga.error = function (a) {
                    throw new Error("Syntax error, unrecognized expression: " + a)
                }, ga.uniqueSort = function (a) {
                    var b, d = [], e = 0, f = 0;
                    if (l = !c.detectDuplicates, k = !c.sortStable && a.slice(0), a.sort(B), l) {
                        while (b = a[f++])b === a[f] && (e = d.push(f));
                        while (e--)a.splice(d[e], 1)
                    }
                    return k = null, a
                }, e = ga.getText = function (a) {
                    var b, c = "", d = 0, f = a.nodeType;
                    if (f) {
                        if (1 === f || 9 === f || 11 === f) {
                            if ("string" == typeof a.textContent)return a.textContent;
                            for (a = a.firstChild; a; a = a.nextSibling)c += e(a)
                        } else if (3 === f || 4 === f)return a.nodeValue
                    } else while (b = a[d++])c += e(b);
                    return c
                }, d = ga.selectors = {
                    cacheLength: 50,
                    createPseudo: ia,
                    match: V,
                    attrHandle: {},
                    find: {},
                    relative: {">": {dir: "parentNode", first: !0}, " ": {dir: "parentNode"}, "+": {dir: "previousSibling", first: !0}, "~": {dir: "previousSibling"}},
                    preFilter: {
                        ATTR: function (a) {
                            return a[1] = a[1].replace(_, aa), a[3] = (a[3] || a[4] || a[5] || "").replace(_, aa), "~=" === a[2] && (a[3] = " " + a[3] + " "), a.slice(0, 4)
                        }, CHILD: function (a) {
                            return a[1] = a[1].toLowerCase(), "nth" === a[1].slice(0, 3) ? (a[3] || ga.error(a[0]), a[4] = +(a[4] ? a[5] + (a[6] || 1) : 2 * ("even" === a[3] || "odd" === a[3])), a[5] = +(a[7] + a[8] || "odd" === a[3])) : a[3] && ga.error(a[0]), a
                        }, PSEUDO: function (a) {
                            var b, c = !a[6] && a[2];
                            return V.CHILD.test(a[0]) ? null : (a[3] ? a[2] = a[4] || a[5] || "" : c && T.test(c) && (b = g(c, !0)) && (b = c.indexOf(")", c.length - b) - c.length) && (a[0] = a[0].slice(0, b), a[2] = c.slice(0, b)), a.slice(0, 3))
                        }
                    },
                    filter: {
                        TAG: function (a) {
                            var b = a.replace(_, aa).toLowerCase();
                            return "*" === a ? function () {
                                return !0
                            } : function (a) {
                                return a.nodeName && a.nodeName.toLowerCase() === b
                            }
                        }, CLASS: function (a) {
                            var b = y[a + " "];
                            return b || (b = new RegExp("(^|" + K + ")" + a + "(" + K + "|$)")) && y(a, function (a) {
                                    return b.test("string" == typeof a.className && a.className || "undefined" != typeof a.getAttribute && a.getAttribute("class") || "")
                                })
                        }, ATTR: function (a, b, c) {
                            return function (d) {
                                var e = ga.attr(d, a);
                                return null == e ? "!=" === b : !b || (e += "", "=" === b ? e === c : "!=" === b ? e !== c : "^=" === b ? c && 0 === e.indexOf(c) : "*=" === b ? c && e.indexOf(c) > -1 : "$=" === b ? c && e.slice(-c.length) === c : "~=" === b ? (" " + e.replace(O, " ") + " ").indexOf(c) > -1 : "|=" === b && (e === c || e.slice(0, c.length + 1) === c + "-"))
                            }
                        }, CHILD: function (a, b, c, d, e) {
                            var f = "nth" !== a.slice(0, 3), g = "last" !== a.slice(-4), h = "of-type" === b;
                            return 1 === d && 0 === e ? function (a) {
                                return !!a.parentNode
                            } : function (b, c, i) {
                                var j, k, l, m, n, o, p = f !== g ? "nextSibling" : "previousSibling", q = b.parentNode, r = h && b.nodeName.toLowerCase(), s = !i && !h, t = !1;
                                if (q) {
                                    if (f) {
                                        while (p) {
                                            m = b;
                                            while (m = m[p])if (h ? m.nodeName.toLowerCase() === r : 1 === m.nodeType)return !1;
                                            o = p = "only" === a && !o && "nextSibling"
                                        }
                                        return !0
                                    }
                                    if (o = [g ? q.firstChild : q.lastChild], g && s) {
                                        m = q, l = m[u] || (m[u] = {}), k = l[m.uniqueID] || (l[m.uniqueID] = {}), j = k[a] || [], n = j[0] === w && j[1], t = n && j[2], m = n && q.childNodes[n];
                                        while (m = ++n && m && m[p] || (t = n = 0) || o.pop())if (1 === m.nodeType && ++t && m === b) {
                                            k[a] = [w, n, t];
                                            break
                                        }
                                    } else if (s && (m = b, l = m[u] || (m[u] = {}), k = l[m.uniqueID] || (l[m.uniqueID] = {}), j = k[a] || [], n = j[0] === w && j[1], t = n), t === !1)while (m = ++n && m && m[p] || (t = n = 0) || o.pop())if ((h ? m.nodeName.toLowerCase() === r : 1 === m.nodeType) && ++t && (s && (l = m[u] || (m[u] = {}), k = l[m.uniqueID] || (l[m.uniqueID] = {}), k[a] = [w, t]), m === b))break;
                                    return t -= e, t === d || t % d === 0 && t / d >= 0
                                }
                            }
                        }, PSEUDO: function (a, b) {
                            var c, e = d.pseudos[a] || d.setFilters[a.toLowerCase()] || ga.error("unsupported pseudo: " + a);
                            return e[u] ? e(b) : e.length > 1 ? (c = [a, a, "", b], d.setFilters.hasOwnProperty(a.toLowerCase()) ? ia(function (a, c) {
                                var d, f = e(a, b), g = f.length;
                                while (g--)d = I(a, f[g]), a[d] = !(c[d] = f[g])
                            }) : function (a) {
                                return e(a, 0, c)
                            }) : e
                        }
                    },
                    pseudos: {
                        not: ia(function (a) {
                            var b = [], c = [], d = h(a.replace(P, "$1"));
                            return d[u] ? ia(function (a, b, c, e) {
                                var f, g = d(a, null, e, []), h = a.length;
                                while (h--)(f = g[h]) && (a[h] = !(b[h] = f))
                            }) : function (a, e, f) {
                                return b[0] = a, d(b, null, f, c), b[0] = null, !c.pop()
                            }
                        }), has: ia(function (a) {
                            return function (b) {
                                return ga(a, b).length > 0
                            }
                        }), contains: ia(function (a) {
                            return a = a.replace(_, aa), function (b) {
                                return (b.textContent || b.innerText || e(b)).indexOf(a) > -1
                            }
                        }), lang: ia(function (a) {
                            return U.test(a || "") || ga.error("unsupported lang: " + a), a = a.replace(_, aa).toLowerCase(), function (b) {
                                var c;
                                do if (c = p ? b.lang : b.getAttribute("xml:lang") || b.getAttribute("lang"))return c = c.toLowerCase(), c === a || 0 === c.indexOf(a + "-"); while ((b = b.parentNode) && 1 === b.nodeType);
                                return !1
                            }
                        }), target: function (b) {
                            var c = a.location && a.location.hash;
                            return c && c.slice(1) === b.id
                        }, root: function (a) {
                            return a === o
                        }, focus: function (a) {
                            return a === n.activeElement && (!n.hasFocus || n.hasFocus()) && !!(a.type || a.href || ~a.tabIndex)
                        }, enabled: oa(!1), disabled: oa(!0), checked: function (a) {
                            var b = a.nodeName.toLowerCase();
                            return "input" === b && !!a.checked || "option" === b && !!a.selected
                        }, selected: function (a) {
                            return a.parentNode && a.parentNode.selectedIndex, a.selected === !0
                        }, empty: function (a) {
                            for (a = a.firstChild; a; a = a.nextSibling)if (a.nodeType < 6)return !1;
                            return !0
                        }, parent: function (a) {
                            return !d.pseudos.empty(a)
                        }, header: function (a) {
                            return X.test(a.nodeName)
                        }, input: function (a) {
                            return W.test(a.nodeName)
                        }, button: function (a) {
                            var b = a.nodeName.toLowerCase();
                            return "input" === b && "button" === a.type || "button" === b
                        }, text: function (a) {
                            var b;
                            return "input" === a.nodeName.toLowerCase() && "text" === a.type && (null == (b = a.getAttribute("type")) || "text" === b.toLowerCase())
                        }, first: pa(function () {
                            return [0]
                        }), last: pa(function (a, b) {
                            return [b - 1]
                        }), eq: pa(function (a, b, c) {
                            return [c < 0 ? c + b : c]
                        }), even: pa(function (a, b) {
                            for (var c = 0; c < b; c += 2)a.push(c);
                            return a
                        }), odd: pa(function (a, b) {
                            for (var c = 1; c < b; c += 2)a.push(c);
                            return a
                        }), lt: pa(function (a, b, c) {
                            for (var d = c < 0 ? c + b : c; --d >= 0;)a.push(d);
                            return a
                        }), gt: pa(function (a, b, c) {
                            for (var d = c < 0 ? c + b : c; ++d < b;)a.push(d);
                            return a
                        })
                    }
                }, d.pseudos.nth = d.pseudos.eq;
                for (b in{radio: !0, checkbox: !0, file: !0, password: !0, image: !0})d.pseudos[b] = ma(b);
                for (b in{submit: !0, reset: !0})d.pseudos[b] = na(b);
                function ra() {
                }
                ra.prototype = d.filters = d.pseudos, d.setFilters = new ra, g = ga.tokenize = function (a, b) {
                    var c, e, f, g, h, i, j, k = z[a + " "];
                    if (k)return b ? 0 : k.slice(0);
                    h = a, i = [], j = d.preFilter;
                    while (h) {
                        c && !(e = Q.exec(h)) || (e && (h = h.slice(e[0].length) || h), i.push(f = [])), c = !1, (e = R.exec(h)) && (c = e.shift(), f.push({
                            value: c,
                            type: e[0].replace(P, " ")
                        }), h = h.slice(c.length));
                        for (g in d.filter)!(e = V[g].exec(h)) || j[g] && !(e = j[g](e)) || (c = e.shift(), f.push({value: c, type: g, matches: e}), h = h.slice(c.length));
                        if (!c)break
                    }
                    return b ? h.length : h ? ga.error(a) : z(a, i).slice(0)
                };
                function sa(a) {
                    for (var b = 0, c = a.length, d = ""; b < c; b++)d += a[b].value;
                    return d
                }
                function ta(a, b, c) {
                    var d = b.dir, e = b.next, f = e || d, g = c && "parentNode" === f, h = x++;
                    return b.first ? function (b, c, e) {
                        while (b = b[d])if (1 === b.nodeType || g)return a(b, c, e);
                        return !1
                    } : function (b, c, i) {
                        var j, k, l, m = [w, h];
                        if (i) {
                            while (b = b[d])if ((1 === b.nodeType || g) && a(b, c, i))return !0
                        } else while (b = b[d])if (1 === b.nodeType || g)if (l = b[u] || (b[u] = {}), k = l[b.uniqueID] || (l[b.uniqueID] = {}), e && e === b.nodeName.toLowerCase()) b = b[d] || b; else {
                            if ((j = k[f]) && j[0] === w && j[1] === h)return m[2] = j[2];
                            if (k[f] = m, m[2] = a(b, c, i))return !0
                        }
                        return !1
                    }
                }
                function ua(a) {
                    return a.length > 1 ? function (b, c, d) {
                        var e = a.length;
                        while (e--)if (!a[e](b, c, d))return !1;
                        return !0
                    } : a[0]
                }
                function va(a, b, c) {
                    for (var d = 0, e = b.length; d < e; d++)ga(a, b[d], c);
                    return c
                }
                function wa(a, b, c, d, e) {
                    for (var f, g = [], h = 0, i = a.length, j = null != b; h < i; h++)(f = a[h]) && (c && !c(f, d, e) || (g.push(f), j && b.push(h)));
                    return g
                }
                function xa(a, b, c, d, e, f) {
                    return d && !d[u] && (d = xa(d)), e && !e[u] && (e = xa(e, f)), ia(function (f, g, h, i) {
                        var j, k, l, m = [], n = [], o = g.length, p = f || va(b || "*", h.nodeType ? [h] : h, []), q = !a || !f && b ? p : wa(p, m, a, h, i),
                            r = c ? e || (f ? a : o || d) ? [] : g : q;
                        if (c && c(q, r, h, i), d) {
                            j = wa(r, n), d(j, [], h, i), k = j.length;
                            while (k--)(l = j[k]) && (r[n[k]] = !(q[n[k]] = l))
                        }
                        if (f) {
                            if (e || a) {
                                if (e) {
                                    j = [], k = r.length;
                                    while (k--)(l = r[k]) && j.push(q[k] = l);
                                    e(null, r = [], j, i)
                                }
                                k = r.length;
                                while (k--)(l = r[k]) && (j = e ? I(f, l) : m[k]) > -1 && (f[j] = !(g[j] = l))
                            }
                        } else r = wa(r === g ? r.splice(o, r.length) : r), e ? e(null, g, r, i) : G.apply(g, r)
                    })
                }
                function ya(a) {
                    for (var b, c, e, f = a.length, g = d.relative[a[0].type], h = g || d.relative[" "], i = g ? 1 : 0, k = ta(function (a) {
                        return a === b
                    }, h, !0), l = ta(function (a) {
                        return I(b, a) > -1
                    }, h, !0), m = [function (a, c, d) {
                        var e = !g && (d || c !== j) || ((b = c).nodeType ? k(a, c, d) : l(a, c, d));
                        return b = null, e
                    }]; i < f; i++)if (c = d.relative[a[i].type]) m = [ta(ua(m), c)]; else {
                        if (c = d.filter[a[i].type].apply(null, a[i].matches), c[u]) {
                            for (e = ++i; e < f; e++)if (d.relative[a[e].type])break;
                            return xa(i > 1 && ua(m), i > 1 && sa(a.slice(0, i - 1).concat({value: " " === a[i - 2].type ? "*" : ""})).replace(P, "$1"), c, i < e && ya(a.slice(i, e)), e < f && ya(a = a.slice(e)), e < f && sa(a))
                        }
                        m.push(c)
                    }
                    return ua(m)
                }
                function za(a, b) {
                    var c = b.length > 0, e = a.length > 0, f = function (f, g, h, i, k) {
                        var l, o, q, r = 0, s = "0", t = f && [], u = [], v = j, x = f || e && d.find.TAG("*", k), y = w += null == v ? 1 : Math.random() || .1, z = x.length;
                        for (k && (j = g === n || g || k); s !== z && null != (l = x[s]); s++) {
                            if (e && l) {
                                o = 0, g || l.ownerDocument === n || (m(l), h = !p);
                                while (q = a[o++])if (q(l, g || n, h)) {
                                    i.push(l);
                                    break
                                }
                                k && (w = y)
                            }
                            c && ((l = !q && l) && r--, f && t.push(l))
                        }
                        if (r += s, c && s !== r) {
                            o = 0;
                            while (q = b[o++])q(t, u, g, h);
                            if (f) {
                                if (r > 0)while (s--)t[s] || u[s] || (u[s] = E.call(i));
                                u = wa(u)
                            }
                            G.apply(i, u), k && !f && u.length > 0 && r + b.length > 1 && ga.uniqueSort(i)
                        }
                        return k && (w = y, j = v), t
                    };
                    return c ? ia(f) : f
                }
                return h = ga.compile = function (a, b) {
                    var c, d = [], e = [], f = A[a + " "];
                    if (!f) {
                        b || (b = g(a)), c = b.length;
                        while (c--)f = ya(b[c]), f[u] ? d.push(f) : e.push(f);
                        f = A(a, za(e, d)), f.selector = a
                    }
                    return f
                }, i = ga.select = function (a, b, c, e) {
                    var f, i, j, k, l, m = "function" == typeof a && a, n = !e && g(a = m.selector || a);
                    if (c = c || [], 1 === n.length) {
                        if (i = n[0] = n[0].slice(0), i.length > 2 && "ID" === (j = i[0]).type && 9 === b.nodeType && p && d.relative[i[1].type]) {
                            if (b = (d.find.ID(j.matches[0].replace(_, aa), b) || [])[0], !b)return c;
                            m && (b = b.parentNode), a = a.slice(i.shift().value.length)
                        }
                        f = V.needsContext.test(a) ? 0 : i.length;
                        while (f--) {
                            if (j = i[f], d.relative[k = j.type])break;
                            if ((l = d.find[k]) && (e = l(j.matches[0].replace(_, aa), $.test(i[0].type) && qa(b.parentNode) || b))) {
                                if (i.splice(f, 1), a = e.length && sa(i), !a)return G.apply(c, e), c;
                                break
                            }
                        }
                    }
                    return (m || h(a, n))(e, b, !p, c, !b || $.test(a) && qa(b.parentNode) || b), c
                }, c.sortStable = u.split("").sort(B).join("") === u, c.detectDuplicates = !!l, m(), c.sortDetached = ja(function (a) {
                    return 1 & a.compareDocumentPosition(n.createElement("fieldset"))
                }), ja(function (a) {
                    return a.innerHTML = "<a href='#'></a>", "#" === a.firstChild.getAttribute("href")
                }) || ka("type|href|height|width", function (a, b, c) {
                    if (!c)return a.getAttribute(b, "type" === b.toLowerCase() ? 1 : 2)
                }), c.attributes && ja(function (a) {
                    return a.innerHTML = "<input/>", a.firstChild.setAttribute("value", ""), "" === a.firstChild.getAttribute("value")
                }) || ka("value", function (a, b, c) {
                    if (!c && "input" === a.nodeName.toLowerCase())return a.defaultValue
                }), ja(function (a) {
                    return null == a.getAttribute("disabled")
                }) || ka(J, function (a, b, c) {
                    var d;
                    if (!c)return a[b] === !0 ? b.toLowerCase() : (d = a.getAttributeNode(b)) && d.specified ? d.value : null
                }), ga
            }(a);
            r.find = x, r.expr = x.selectors, r.expr[":"] = r.expr.pseudos, r.uniqueSort = r.unique = x.uniqueSort, r.text = x.getText, r.isXMLDoc = x.isXML, r.contains = x.contains, r.escapeSelector = x.escape;
            var y = function (a, b, c) {
                var d = [], e = void 0 !== c;
                while ((a = a[b]) && 9 !== a.nodeType)if (1 === a.nodeType) {
                    if (e && r(a).is(c))break;
                    d.push(a)
                }
                return d
            }, z = function (a, b) {
                for (var c = []; a; a = a.nextSibling)1 === a.nodeType && a !== b && c.push(a);
                return c
            }, A = r.expr.match.needsContext;
            function B(a, b) {
                return a.nodeName && a.nodeName.toLowerCase() === b.toLowerCase()
            }
            var C = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i, D = /^.[^:#\[\.,]*$/;
            function E(a, b, c) {
                return r.isFunction(b) ? r.grep(a, function (a, d) {
                    return !!b.call(a, d, a) !== c
                }) : b.nodeType ? r.grep(a, function (a) {
                    return a === b !== c
                }) : "string" != typeof b ? r.grep(a, function (a) {
                    return i.call(b, a) > -1 !== c
                }) : D.test(b) ? r.filter(b, a, c) : (b = r.filter(b, a), r.grep(a, function (a) {
                    return i.call(b, a) > -1 !== c && 1 === a.nodeType
                }))
            }
            r.filter = function (a, b, c) {
                var d = b[0];
                return c && (a = ":not(" + a + ")"), 1 === b.length && 1 === d.nodeType ? r.find.matchesSelector(d, a) ? [d] : [] : r.find.matches(a, r.grep(b, function (a) {
                    return 1 === a.nodeType
                }))
            }, r.fn.extend({
                find: function (a) {
                    var b, c, d = this.length, e = this;
                    if ("string" != typeof a)return this.pushStack(r(a).filter(function () {
                        for (b = 0; b < d; b++)if (r.contains(e[b], this))return !0
                    }));
                    for (c = this.pushStack([]), b = 0; b < d; b++)r.find(a, e[b], c);
                    return d > 1 ? r.uniqueSort(c) : c
                }, filter: function (a) {
                    return this.pushStack(E(this, a || [], !1))
                }, not: function (a) {
                    return this.pushStack(E(this, a || [], !0))
                }, is: function (a) {
                    return !!E(this, "string" == typeof a && A.test(a) ? r(a) : a || [], !1).length
                }
            });
            var F, G = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/, H = r.fn.init = function (a, b, c) {
                var e, f;
                if (!a)return this;
                if (c = c || F, "string" == typeof a) {
                    if (e = "<" === a[0] && ">" === a[a.length - 1] && a.length >= 3 ? [null, a, null] : G.exec(a), !e || !e[1] && b)return !b || b.jquery ? (b || c).find(a) : this.constructor(b).find(a);
                    if (e[1]) {
                        if (b = b instanceof r ? b[0] : b, r.merge(this, r.parseHTML(e[1], b && b.nodeType ? b.ownerDocument || b : d, !0)), C.test(e[1]) && r.isPlainObject(b))for (e in b)r.isFunction(this[e]) ? this[e](b[e]) : this.attr(e, b[e]);
                        return this
                    }
                    return f = d.getElementById(e[2]), f && (this[0] = f, this.length = 1), this
                }
                return a.nodeType ? (this[0] = a, this.length = 1, this) : r.isFunction(a) ? void 0 !== c.ready ? c.ready(a) : a(r) : r.makeArray(a, this)
            };
            H.prototype = r.fn, F = r(d);
            var I = /^(?:parents|prev(?:Until|All))/, J = {children: !0, contents: !0, next: !0, prev: !0};
            r.fn.extend({
                has: function (a) {
                    var b = r(a, this), c = b.length;
                    return this.filter(function () {
                        for (var a = 0; a < c; a++)if (r.contains(this, b[a]))return !0
                    })
                }, closest: function (a, b) {
                    var c, d = 0, e = this.length, f = [], g = "string" != typeof a && r(a);
                    if (!A.test(a))for (; d < e; d++)for (c = this[d]; c && c !== b; c = c.parentNode)if (c.nodeType < 11 && (g ? g.index(c) > -1 : 1 === c.nodeType && r.find.matchesSelector(c, a))) {
                        f.push(c);
                        break
                    }
                    return this.pushStack(f.length > 1 ? r.uniqueSort(f) : f)
                }, index: function (a) {
                    return a ? "string" == typeof a ? i.call(r(a), this[0]) : i.call(this, a.jquery ? a[0] : a) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
                }, add: function (a, b) {
                    return this.pushStack(r.uniqueSort(r.merge(this.get(), r(a, b))))
                }, addBack: function (a) {
                    return this.add(null == a ? this.prevObject : this.prevObject.filter(a))
                }
            });
            function K(a, b) {
                while ((a = a[b]) && 1 !== a.nodeType);
                return a
            }
            r.each({
                parent: function (a) {
                    var b = a.parentNode;
                    return b && 11 !== b.nodeType ? b : null
                }, parents: function (a) {
                    return y(a, "parentNode")
                }, parentsUntil: function (a, b, c) {
                    return y(a, "parentNode", c)
                }, next: function (a) {
                    return K(a, "nextSibling")
                }, prev: function (a) {
                    return K(a, "previousSibling")
                }, nextAll: function (a) {
                    return y(a, "nextSibling")
                }, prevAll: function (a) {
                    return y(a, "previousSibling")
                }, nextUntil: function (a, b, c) {
                    return y(a, "nextSibling", c)
                }, prevUntil: function (a, b, c) {
                    return y(a, "previousSibling", c)
                }, siblings: function (a) {
                    return z((a.parentNode || {}).firstChild, a)
                }, children: function (a) {
                    return z(a.firstChild)
                }, contents: function (a) {
                    return B(a, "iframe") ? a.contentDocument : (B(a, "template") && (a = a.content || a), r.merge([], a.childNodes))
                }
            }, function (a, b) {
                r.fn[a] = function (c, d) {
                    var e = r.map(this, b, c);
                    return "Until" !== a.slice(-5) && (d = c), d && "string" == typeof d && (e = r.filter(d, e)), this.length > 1 && (J[a] || r.uniqueSort(e), I.test(a) && e.reverse()), this.pushStack(e)
                }
            });
            var L = /[^\x20\t\r\n\f]+/g;
            function M(a) {
                var b = {};
                return r.each(a.match(L) || [], function (a, c) {
                    b[c] = !0
                }), b
            }
            r.Callbacks = function (a) {
                a = "string" == typeof a ? M(a) : r.extend({}, a);
                var b, c, d, e, f = [], g = [], h = -1, i = function () {
                    for (e = e || a.once, d = b = !0; g.length; h = -1) {
                        c = g.shift();
                        while (++h < f.length)f[h].apply(c[0], c[1]) === !1 && a.stopOnFalse && (h = f.length, c = !1)
                    }
                    a.memory || (c = !1), b = !1, e && (f = c ? [] : "")
                }, j = {
                    add: function () {
                        return f && (c && !b && (h = f.length - 1, g.push(c)), function d(b) {
                            r.each(b, function (b, c) {
                                r.isFunction(c) ? a.unique && j.has(c) || f.push(c) : c && c.length && "string" !== r.type(c) && d(c)
                            })
                        }(arguments), c && !b && i()), this
                    }, remove: function () {
                        return r.each(arguments, function (a, b) {
                            var c;
                            while ((c = r.inArray(b, f, c)) > -1)f.splice(c, 1), c <= h && h--
                        }), this
                    }, has: function (a) {
                        return a ? r.inArray(a, f) > -1 : f.length > 0
                    }, empty: function () {
                        return f && (f = []), this
                    }, disable: function () {
                        return e = g = [], f = c = "", this
                    }, disabled: function () {
                        return !f
                    }, lock: function () {
                        return e = g = [], c || b || (f = c = ""), this
                    }, locked: function () {
                        return !!e
                    }, fireWith: function (a, c) {
                        return e || (c = c || [], c = [a, c.slice ? c.slice() : c], g.push(c), b || i()), this
                    }, fire: function () {
                        return j.fireWith(this, arguments), this
                    }, fired: function () {
                        return !!d
                    }
                };
                return j
            };
            function N(a) {
                return a
            }
            function O(a) {
                throw a
            }
            function P(a, b, c, d) {
                var e;
                try {
                    a && r.isFunction(e = a.promise) ? e.call(a).done(b).fail(c) : a && r.isFunction(e = a.then) ? e.call(a, b, c) : b.apply(void 0, [a].slice(d))
                } catch (a) {
                    c.apply(void 0, [a])
                }
            }
            r.extend({
                Deferred: function (b) {
                    var c = [["notify", "progress", r.Callbacks("memory"), r.Callbacks("memory"), 2], ["resolve", "done", r.Callbacks("once memory"), r.Callbacks("once memory"), 0, "resolved"], ["reject", "fail", r.Callbacks("once memory"), r.Callbacks("once memory"), 1, "rejected"]],
                        d = "pending", e = {
                            state: function () {
                                return d
                            }, always: function () {
                                return f.done(arguments).fail(arguments), this
                            }, "catch": function (a) {
                                return e.then(null, a)
                            }, pipe: function () {
                                var a = arguments;
                                return r.Deferred(function (b) {
                                    r.each(c, function (c, d) {
                                        var e = r.isFunction(a[d[4]]) && a[d[4]];
                                        f[d[1]](function () {
                                            var a = e && e.apply(this, arguments);
                                            a && r.isFunction(a.promise) ? a.promise().progress(b.notify).done(b.resolve).fail(b.reject) : b[d[0] + "With"](this, e ? [a] : arguments)
                                        })
                                    }), a = null
                                }).promise()
                            }, then: function (b, d, e) {
                                var f = 0;
                                function g(b, c, d, e) {
                                    return function () {
                                        var h = this, i = arguments, j = function () {
                                            var a, j;
                                            if (!(b < f)) {
                                                if (a = d.apply(h, i), a === c.promise())throw new TypeError("Thenable self-resolution");
                                                j = a && ("object" == typeof a || "function" == typeof a) && a.then, r.isFunction(j) ? e ? j.call(a, g(f, c, N, e), g(f, c, O, e)) : (f++, j.call(a, g(f, c, N, e), g(f, c, O, e), g(f, c, N, c.notifyWith))) : (d !== N && (h = void 0, i = [a]), (e || c.resolveWith)(h, i))
                                            }
                                        }, k = e ? j : function () {
                                            try {
                                                j()
                                            } catch (a) {
                                                r.Deferred.exceptionHook && r.Deferred.exceptionHook(a, k.stackTrace), b + 1 >= f && (d !== O && (h = void 0, i = [a]), c.rejectWith(h, i))
                                            }
                                        };
                                        b ? k() : (r.Deferred.getStackHook && (k.stackTrace = r.Deferred.getStackHook()), a.setTimeout(k))
                                    }
                                }
                                return r.Deferred(function (a) {
                                    c[0][3].add(g(0, a, r.isFunction(e) ? e : N, a.notifyWith)), c[1][3].add(g(0, a, r.isFunction(b) ? b : N)), c[2][3].add(g(0, a, r.isFunction(d) ? d : O))
                                }).promise()
                            }, promise: function (a) {
                                return null != a ? r.extend(a, e) : e
                            }
                        }, f = {};
                    return r.each(c, function (a, b) {
                        var g = b[2], h = b[5];
                        e[b[1]] = g.add, h && g.add(function () {
                            d = h
                        }, c[3 - a][2].disable, c[0][2].lock), g.add(b[3].fire), f[b[0]] = function () {
                            return f[b[0] + "With"](this === f ? void 0 : this, arguments), this
                        }, f[b[0] + "With"] = g.fireWith
                    }), e.promise(f), b && b.call(f, f), f
                }, when: function (a) {
                    var b = arguments.length, c = b, d = Array(c), e = f.call(arguments), g = r.Deferred(), h = function (a) {
                        return function (c) {
                            d[a] = this, e[a] = arguments.length > 1 ? f.call(arguments) : c, --b || g.resolveWith(d, e)
                        }
                    };
                    if (b <= 1 && (P(a, g.done(h(c)).resolve, g.reject, !b), "pending" === g.state() || r.isFunction(e[c] && e[c].then)))return g.then();
                    while (c--)P(e[c], h(c), g.reject);
                    return g.promise()
                }
            });
            var Q = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
            r.Deferred.exceptionHook = function (b, c) {
                a.console && a.console.warn && b && Q.test(b.name) && a.console.warn("jQuery.Deferred exception: " + b.message, b.stack, c)
            }, r.readyException = function (b) {
                a.setTimeout(function () {
                    throw b
                })
            };
            var R = r.Deferred();
            r.fn.ready = function (a) {
                return R.then(a)["catch"](function (a) {
                    r.readyException(a)
                }), this
            }, r.extend({
                isReady: !1, readyWait: 1, ready: function (a) {
                    (a === !0 ? --r.readyWait : r.isReady) || (r.isReady = !0, a !== !0 && --r.readyWait > 0 || R.resolveWith(d, [r]))
                }
            }), r.ready.then = R.then;
            function S() {
                d.removeEventListener("DOMContentLoaded", S),
                    a.removeEventListener("load", S), r.ready()
            }
            "complete" === d.readyState || "loading" !== d.readyState && !d.documentElement.doScroll ? a.setTimeout(r.ready) : (d.addEventListener("DOMContentLoaded", S), a.addEventListener("load", S));
            var T = function (a, b, c, d, e, f, g) {
                var h = 0, i = a.length, j = null == c;
                if ("object" === r.type(c)) {
                    e = !0;
                    for (h in c)T(a, b, h, c[h], !0, f, g)
                } else if (void 0 !== d && (e = !0, r.isFunction(d) || (g = !0), j && (g ? (b.call(a, d), b = null) : (j = b, b = function (a, b, c) {
                        return j.call(r(a), c)
                    })), b))for (; h < i; h++)b(a[h], c, g ? d : d.call(a[h], h, b(a[h], c)));
                return e ? a : j ? b.call(a) : i ? b(a[0], c) : f
            }, U = function (a) {
                return 1 === a.nodeType || 9 === a.nodeType || !+a.nodeType
            };
            function V() {
                this.expando = r.expando + V.uid++
            }
            V.uid = 1, V.prototype = {
                cache: function (a) {
                    var b = a[this.expando];
                    return b || (b = {}, U(a) && (a.nodeType ? a[this.expando] = b : Object.defineProperty(a, this.expando, {value: b, configurable: !0}))), b
                }, set: function (a, b, c) {
                    var d, e = this.cache(a);
                    if ("string" == typeof b) e[r.camelCase(b)] = c; else for (d in b)e[r.camelCase(d)] = b[d];
                    return e
                }, get: function (a, b) {
                    return void 0 === b ? this.cache(a) : a[this.expando] && a[this.expando][r.camelCase(b)]
                }, access: function (a, b, c) {
                    return void 0 === b || b && "string" == typeof b && void 0 === c ? this.get(a, b) : (this.set(a, b, c), void 0 !== c ? c : b)
                }, remove: function (a, b) {
                    var c, d = a[this.expando];
                    if (void 0 !== d) {
                        if (void 0 !== b) {
                            Array.isArray(b) ? b = b.map(r.camelCase) : (b = r.camelCase(b), b = b in d ? [b] : b.match(L) || []), c = b.length;
                            while (c--)delete d[b[c]]
                        }
                        (void 0 === b || r.isEmptyObject(d)) && (a.nodeType ? a[this.expando] = void 0 : delete a[this.expando])
                    }
                }, hasData: function (a) {
                    var b = a[this.expando];
                    return void 0 !== b && !r.isEmptyObject(b)
                }
            };
            var W = new V, X = new V, Y = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/, Z = /[A-Z]/g;
            function $(a) {
                return "true" === a || "false" !== a && ("null" === a ? null : a === +a + "" ? +a : Y.test(a) ? JSON.parse(a) : a)
            }
            function _(a, b, c) {
                var d;
                if (void 0 === c && 1 === a.nodeType)if (d = "data-" + b.replace(Z, "-$&").toLowerCase(), c = a.getAttribute(d), "string" == typeof c) {
                    try {
                        c = $(c)
                    } catch (e) {
                    }
                    X.set(a, b, c)
                } else c = void 0;
                return c
            }
            r.extend({
                hasData: function (a) {
                    return X.hasData(a) || W.hasData(a)
                }, data: function (a, b, c) {
                    return X.access(a, b, c)
                }, removeData: function (a, b) {
                    X.remove(a, b)
                }, _data: function (a, b, c) {
                    return W.access(a, b, c)
                }, _removeData: function (a, b) {
                    W.remove(a, b)
                }
            }), r.fn.extend({
                data: function (a, b) {
                    var c, d, e, f = this[0], g = f && f.attributes;
                    if (void 0 === a) {
                        if (this.length && (e = X.get(f), 1 === f.nodeType && !W.get(f, "hasDataAttrs"))) {
                            c = g.length;
                            while (c--)g[c] && (d = g[c].name, 0 === d.indexOf("data-") && (d = r.camelCase(d.slice(5)), _(f, d, e[d])));
                            W.set(f, "hasDataAttrs", !0)
                        }
                        return e
                    }
                    return "object" == typeof a ? this.each(function () {
                        X.set(this, a)
                    }) : T(this, function (b) {
                        var c;
                        if (f && void 0 === b) {
                            if (c = X.get(f, a), void 0 !== c)return c;
                            if (c = _(f, a), void 0 !== c)return c
                        } else this.each(function () {
                            X.set(this, a, b)
                        })
                    }, null, b, arguments.length > 1, null, !0)
                }, removeData: function (a) {
                    return this.each(function () {
                        X.remove(this, a)
                    })
                }
            }), r.extend({
                queue: function (a, b, c) {
                    var d;
                    if (a)return b = (b || "fx") + "queue", d = W.get(a, b), c && (!d || Array.isArray(c) ? d = W.access(a, b, r.makeArray(c)) : d.push(c)), d || []
                }, dequeue: function (a, b) {
                    b = b || "fx";
                    var c = r.queue(a, b), d = c.length, e = c.shift(), f = r._queueHooks(a, b), g = function () {
                        r.dequeue(a, b)
                    };
                    "inprogress" === e && (e = c.shift(), d--), e && ("fx" === b && c.unshift("inprogress"), delete f.stop, e.call(a, g, f)), !d && f && f.empty.fire()
                }, _queueHooks: function (a, b) {
                    var c = b + "queueHooks";
                    return W.get(a, c) || W.access(a, c, {
                            empty: r.Callbacks("once memory").add(function () {
                                W.remove(a, [b + "queue", c])
                            })
                        })
                }
            }), r.fn.extend({
                queue: function (a, b) {
                    var c = 2;
                    return "string" != typeof a && (b = a, a = "fx", c--), arguments.length < c ? r.queue(this[0], a) : void 0 === b ? this : this.each(function () {
                        var c = r.queue(this, a, b);
                        r._queueHooks(this, a), "fx" === a && "inprogress" !== c[0] && r.dequeue(this, a)
                    })
                }, dequeue: function (a) {
                    return this.each(function () {
                        r.dequeue(this, a)
                    })
                }, clearQueue: function (a) {
                    return this.queue(a || "fx", [])
                }, promise: function (a, b) {
                    var c, d = 1, e = r.Deferred(), f = this, g = this.length, h = function () {
                        --d || e.resolveWith(f, [f])
                    };
                    "string" != typeof a && (b = a, a = void 0), a = a || "fx";
                    while (g--)c = W.get(f[g], a + "queueHooks"), c && c.empty && (d++, c.empty.add(h));
                    return h(), e.promise(b)
                }
            });
            var aa = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source, ba = new RegExp("^(?:([+-])=|)(" + aa + ")([a-z%]*)$", "i"), ca = ["Top", "Right", "Bottom", "Left"],
                da = function (a, b) {
                    return a = b || a, "none" === a.style.display || "" === a.style.display && r.contains(a.ownerDocument, a) && "none" === r.css(a, "display")
                }, ea = function (a, b, c, d) {
                    var e, f, g = {};
                    for (f in b)g[f] = a.style[f], a.style[f] = b[f];
                    e = c.apply(a, d || []);
                    for (f in b)a.style[f] = g[f];
                    return e
                };
            function fa(a, b, c, d) {
                var e, f = 1, g = 20, h = d ? function () {
                    return d.cur()
                } : function () {
                    return r.css(a, b, "")
                }, i = h(), j = c && c[3] || (r.cssNumber[b] ? "" : "px"), k = (r.cssNumber[b] || "px" !== j && +i) && ba.exec(r.css(a, b));
                if (k && k[3] !== j) {
                    j = j || k[3], c = c || [], k = +i || 1;
                    do f = f || ".5", k /= f, r.style(a, b, k + j); while (f !== (f = h() / i) && 1 !== f && --g)
                }
                return c && (k = +k || +i || 0, e = c[1] ? k + (c[1] + 1) * c[2] : +c[2], d && (d.unit = j, d.start = k, d.end = e)), e
            }
            var ga = {};
            function ha(a) {
                var b, c = a.ownerDocument, d = a.nodeName, e = ga[d];
                return e ? e : (b = c.body.appendChild(c.createElement(d)), e = r.css(b, "display"), b.parentNode.removeChild(b), "none" === e && (e = "block"), ga[d] = e, e)
            }
            function ia(a, b) {
                for (var c, d, e = [], f = 0, g = a.length; f < g; f++)d = a[f], d.style && (c = d.style.display, b ? ("none" === c && (e[f] = W.get(d, "display") || null, e[f] || (d.style.display = "")), "" === d.style.display && da(d) && (e[f] = ha(d))) : "none" !== c && (e[f] = "none", W.set(d, "display", c)));
                for (f = 0; f < g; f++)null != e[f] && (a[f].style.display = e[f]);
                return a
            }
            r.fn.extend({
                show: function () {
                    return ia(this, !0)
                }, hide: function () {
                    return ia(this)
                }, toggle: function (a) {
                    return "boolean" == typeof a ? a ? this.show() : this.hide() : this.each(function () {
                        da(this) ? r(this).show() : r(this).hide()
                    })
                }
            });
            var ja = /^(?:checkbox|radio)$/i, ka = /<([a-z][^\/\0>\x20\t\r\n\f]+)/i, la = /^$|\/(?:java|ecma)script/i, ma = {
                option: [1, "<select multiple='multiple'>", "</select>"],
                thead: [1, "<table>", "</table>"],
                col: [2, "<table><colgroup>", "</colgroup></table>"],
                tr: [2, "<table><tbody>", "</tbody></table>"],
                td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
                _default: [0, "", ""]
            };
            ma.optgroup = ma.option, ma.tbody = ma.tfoot = ma.colgroup = ma.caption = ma.thead, ma.th = ma.td;
            function na(a, b) {
                var c;
                return c = "undefined" != typeof a.getElementsByTagName ? a.getElementsByTagName(b || "*") : "undefined" != typeof a.querySelectorAll ? a.querySelectorAll(b || "*") : [], void 0 === b || b && B(a, b) ? r.merge([a], c) : c
            }
            function oa(a, b) {
                for (var c = 0, d = a.length; c < d; c++)W.set(a[c], "globalEval", !b || W.get(b[c], "globalEval"))
            }
            var pa = /<|&#?\w+;/;
            function qa(a, b, c, d, e) {
                for (var f, g, h, i, j, k, l = b.createDocumentFragment(), m = [], n = 0, o = a.length; n < o; n++)if (f = a[n], f || 0 === f)if ("object" === r.type(f)) r.merge(m, f.nodeType ? [f] : f); else if (pa.test(f)) {
                    g = g || l.appendChild(b.createElement("div")), h = (ka.exec(f) || ["", ""])[1].toLowerCase(), i = ma[h] || ma._default, g.innerHTML = i[1] + r.htmlPrefilter(f) + i[2], k = i[0];
                    while (k--)g = g.lastChild;
                    r.merge(m, g.childNodes), g = l.firstChild, g.textContent = ""
                } else m.push(b.createTextNode(f));
                l.textContent = "", n = 0;
                while (f = m[n++])if (d && r.inArray(f, d) > -1) e && e.push(f); else if (j = r.contains(f.ownerDocument, f), g = na(l.appendChild(f), "script"), j && oa(g), c) {
                    k = 0;
                    while (f = g[k++])la.test(f.type || "") && c.push(f)
                }
                return l
            }
            !function () {
                var a = d.createDocumentFragment(), b = a.appendChild(d.createElement("div")), c = d.createElement("input");
                c.setAttribute("type", "radio"), c.setAttribute("checked", "checked"), c.setAttribute("name", "t"), b.appendChild(c), o.checkClone = b.cloneNode(!0).cloneNode(!0).lastChild.checked, b.innerHTML = "<textarea>x</textarea>", o.noCloneChecked = !!b.cloneNode(!0).lastChild.defaultValue
            }();
            var ra = d.documentElement, sa = /^key/, ta = /^(?:mouse|pointer|contextmenu|drag|drop)|click/, ua = /^([^.]*)(?:\.(.+)|)/;
            function va() {
                return !0
            }
            function wa() {
                return !1
            }
            function xa() {
                try {
                    return d.activeElement
                } catch (a) {
                }
            }
            function ya(a, b, c, d, e, f) {
                var g, h;
                if ("object" == typeof b) {
                    "string" != typeof c && (d = d || c, c = void 0);
                    for (h in b)ya(a, h, c, d, b[h], f);
                    return a
                }
                if (null == d && null == e ? (e = c, d = c = void 0) : null == e && ("string" == typeof c ? (e = d, d = void 0) : (e = d, d = c, c = void 0)), e === !1) e = wa; else if (!e)return a;
                return 1 === f && (g = e, e = function (a) {
                    return r().off(a), g.apply(this, arguments)
                }, e.guid = g.guid || (g.guid = r.guid++)), a.each(function () {
                    r.event.add(this, b, e, d, c)
                })
            }
            r.event = {
                global: {}, add: function (a, b, c, d, e) {
                    var f, g, h, i, j, k, l, m, n, o, p, q = W.get(a);
                    if (q) {
                        c.handler && (f = c, c = f.handler, e = f.selector), e && r.find.matchesSelector(ra, e), c.guid || (c.guid = r.guid++), (i = q.events) || (i = q.events = {}), (g = q.handle) || (g = q.handle = function (b) {
                            return "undefined" != typeof r && r.event.triggered !== b.type ? r.event.dispatch.apply(a, arguments) : void 0
                        }), b = (b || "").match(L) || [""], j = b.length;
                        while (j--)h = ua.exec(b[j]) || [], n = p = h[1], o = (h[2] || "").split(".").sort(), n && (l = r.event.special[n] || {}, n = (e ? l.delegateType : l.bindType) || n, l = r.event.special[n] || {}, k = r.extend({
                            type: n,
                            origType: p,
                            data: d,
                            handler: c,
                            guid: c.guid,
                            selector: e,
                            needsContext: e && r.expr.match.needsContext.test(e),
                            namespace: o.join(".")
                        }, f), (m = i[n]) || (m = i[n] = [], m.delegateCount = 0, l.setup && l.setup.call(a, d, o, g) !== !1 || a.addEventListener && a.addEventListener(n, g)), l.add && (l.add.call(a, k), k.handler.guid || (k.handler.guid = c.guid)), e ? m.splice(m.delegateCount++, 0, k) : m.push(k), r.event.global[n] = !0)
                    }
                }, remove: function (a, b, c, d, e) {
                    var f, g, h, i, j, k, l, m, n, o, p, q = W.hasData(a) && W.get(a);
                    if (q && (i = q.events)) {
                        b = (b || "").match(L) || [""], j = b.length;
                        while (j--)if (h = ua.exec(b[j]) || [], n = p = h[1], o = (h[2] || "").split(".").sort(), n) {
                            l = r.event.special[n] || {}, n = (d ? l.delegateType : l.bindType) || n, m = i[n] || [], h = h[2] && new RegExp("(^|\\.)" + o.join("\\.(?:.*\\.|)") + "(\\.|$)"), g = f = m.length;
                            while (f--)k = m[f], !e && p !== k.origType || c && c.guid !== k.guid || h && !h.test(k.namespace) || d && d !== k.selector && ("**" !== d || !k.selector) || (m.splice(f, 1), k.selector && m.delegateCount--, l.remove && l.remove.call(a, k));
                            g && !m.length && (l.teardown && l.teardown.call(a, o, q.handle) !== !1 || r.removeEvent(a, n, q.handle), delete i[n])
                        } else for (n in i)r.event.remove(a, n + b[j], c, d, !0);
                        r.isEmptyObject(i) && W.remove(a, "handle events")
                    }
                }, dispatch: function (a) {
                    var b = r.event.fix(a), c, d, e, f, g, h, i = new Array(arguments.length), j = (W.get(this, "events") || {})[b.type] || [], k = r.event.special[b.type] || {};
                    for (i[0] = b, c = 1; c < arguments.length; c++)i[c] = arguments[c];
                    if (b.delegateTarget = this, !k.preDispatch || k.preDispatch.call(this, b) !== !1) {
                        h = r.event.handlers.call(this, b, j), c = 0;
                        while ((f = h[c++]) && !b.isPropagationStopped()) {
                            b.currentTarget = f.elem, d = 0;
                            while ((g = f.handlers[d++]) && !b.isImmediatePropagationStopped())b.rnamespace && !b.rnamespace.test(g.namespace) || (b.handleObj = g, b.data = g.data, e = ((r.event.special[g.origType] || {}).handle || g.handler).apply(f.elem, i), void 0 !== e && (b.result = e) === !1 && (b.preventDefault(), b.stopPropagation()))
                        }
                        return k.postDispatch && k.postDispatch.call(this, b), b.result
                    }
                }, handlers: function (a, b) {
                    var c, d, e, f, g, h = [], i = b.delegateCount, j = a.target;
                    if (i && j.nodeType && !("click" === a.type && a.button >= 1))for (; j !== this; j = j.parentNode || this)if (1 === j.nodeType && ("click" !== a.type || j.disabled !== !0)) {
                        for (f = [], g = {}, c = 0; c < i; c++)d = b[c], e = d.selector + " ", void 0 === g[e] && (g[e] = d.needsContext ? r(e, this).index(j) > -1 : r.find(e, this, null, [j]).length), g[e] && f.push(d);
                        f.length && h.push({elem: j, handlers: f})
                    }
                    return j = this, i < b.length && h.push({elem: j, handlers: b.slice(i)}), h
                }, addProp: function (a, b) {
                    Object.defineProperty(r.Event.prototype, a, {
                        enumerable: !0, configurable: !0, get: r.isFunction(b) ? function () {
                            if (this.originalEvent)return b(this.originalEvent)
                        } : function () {
                            if (this.originalEvent)return this.originalEvent[a]
                        }, set: function (b) {
                            Object.defineProperty(this, a, {enumerable: !0, configurable: !0, writable: !0, value: b})
                        }
                    })
                }, fix: function (a) {
                    return a[r.expando] ? a : new r.Event(a)
                }, special: {
                    load: {noBubble: !0}, focus: {
                        trigger: function () {
                            if (this !== xa() && this.focus)return this.focus(), !1
                        }, delegateType: "focusin"
                    }, blur: {
                        trigger: function () {
                            if (this === xa() && this.blur)return this.blur(), !1
                        }, delegateType: "focusout"
                    }, click: {
                        trigger: function () {
                            if ("checkbox" === this.type && this.click && B(this, "input"))return this.click(), !1
                        }, _default: function (a) {
                            return B(a.target, "a")
                        }
                    }, beforeunload: {
                        postDispatch: function (a) {
                            void 0 !== a.result && a.originalEvent && (a.originalEvent.returnValue = a.result)
                        }
                    }
                }
            }, r.removeEvent = function (a, b, c) {
                a.removeEventListener && a.removeEventListener(b, c)
            }, r.Event = function (a, b) {
                return this instanceof r.Event ? (a && a.type ? (this.originalEvent = a, this.type = a.type, this.isDefaultPrevented = a.defaultPrevented || void 0 === a.defaultPrevented && a.returnValue === !1 ? va : wa, this.target = a.target && 3 === a.target.nodeType ? a.target.parentNode : a.target, this.currentTarget = a.currentTarget, this.relatedTarget = a.relatedTarget) : this.type = a, b && r.extend(this, b), this.timeStamp = a && a.timeStamp || r.now(), void(this[r.expando] = !0)) : new r.Event(a, b)
            }, r.Event.prototype = {
                constructor: r.Event,
                isDefaultPrevented: wa,
                isPropagationStopped: wa,
                isImmediatePropagationStopped: wa,
                isSimulated: !1,
                preventDefault: function () {
                    var a = this.originalEvent;
                    this.isDefaultPrevented = va, a && !this.isSimulated && a.preventDefault()
                },
                stopPropagation: function () {
                    var a = this.originalEvent;
                    this.isPropagationStopped = va, a && !this.isSimulated && a.stopPropagation()
                },
                stopImmediatePropagation: function () {
                    var a = this.originalEvent;
                    this.isImmediatePropagationStopped = va, a && !this.isSimulated && a.stopImmediatePropagation(), this.stopPropagation()
                }
            }, r.each({
                altKey: !0,
                bubbles: !0,
                cancelable: !0,
                changedTouches: !0,
                ctrlKey: !0,
                detail: !0,
                eventPhase: !0,
                metaKey: !0,
                pageX: !0,
                pageY: !0,
                shiftKey: !0,
                view: !0,
                "char": !0,
                charCode: !0,
                key: !0,
                keyCode: !0,
                button: !0,
                buttons: !0,
                clientX: !0,
                clientY: !0,
                offsetX: !0,
                offsetY: !0,
                pointerId: !0,
                pointerType: !0,
                screenX: !0,
                screenY: !0,
                targetTouches: !0,
                toElement: !0,
                touches: !0,
                which: function (a) {
                    var b = a.button;
                    return null == a.which && sa.test(a.type) ? null != a.charCode ? a.charCode : a.keyCode : !a.which && void 0 !== b && ta.test(a.type) ? 1 & b ? 1 : 2 & b ? 3 : 4 & b ? 2 : 0 : a.which
                }
            }, r.event.addProp), r.each({mouseenter: "mouseover", mouseleave: "mouseout", pointerenter: "pointerover", pointerleave: "pointerout"}, function (a, b) {
                r.event.special[a] = {
                    delegateType: b, bindType: b, handle: function (a) {
                        var c, d = this, e = a.relatedTarget, f = a.handleObj;
                        return e && (e === d || r.contains(d, e)) || (a.type = f.origType, c = f.handler.apply(this, arguments), a.type = b), c
                    }
                }
            }), r.fn.extend({
                on: function (a, b, c, d) {
                    return ya(this, a, b, c, d)
                }, one: function (a, b, c, d) {
                    return ya(this, a, b, c, d, 1)
                }, off: function (a, b, c) {
                    var d, e;
                    if (a && a.preventDefault && a.handleObj)return d = a.handleObj, r(a.delegateTarget).off(d.namespace ? d.origType + "." + d.namespace : d.origType, d.selector, d.handler), this;
                    if ("object" == typeof a) {
                        for (e in a)this.off(e, b, a[e]);
                        return this
                    }
                    return b !== !1 && "function" != typeof b || (c = b, b = void 0), c === !1 && (c = wa), this.each(function () {
                        r.event.remove(this, a, c, b)
                    })
                }
            });
            var za = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi, Aa = /<script|<style|<link/i,
                Ba = /checked\s*(?:[^=]|=\s*.checked.)/i, Ca = /^true\/(.*)/, Da = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
            function Ea(a, b) {
                return B(a, "table") && B(11 !== b.nodeType ? b : b.firstChild, "tr") ? r(">tbody", a)[0] || a : a
            }
            function Fa(a) {
                return a.type = (null !== a.getAttribute("type")) + "/" + a.type, a
            }
            function Ga(a) {
                var b = Ca.exec(a.type);
                return b ? a.type = b[1] : a.removeAttribute("type"), a
            }
            function Ha(a, b) {
                var c, d, e, f, g, h, i, j;
                if (1 === b.nodeType) {
                    if (W.hasData(a) && (f = W.access(a), g = W.set(b, f), j = f.events)) {
                        delete g.handle, g.events = {};
                        for (e in j)for (c = 0, d = j[e].length; c < d; c++)r.event.add(b, e, j[e][c])
                    }
                    X.hasData(a) && (h = X.access(a), i = r.extend({}, h), X.set(b, i))
                }
            }
            function Ia(a, b) {
                var c = b.nodeName.toLowerCase();
                "input" === c && ja.test(a.type) ? b.checked = a.checked : "input" !== c && "textarea" !== c || (b.defaultValue = a.defaultValue)
            }
            function Ja(a, b, c, d) {
                b = g.apply([], b);
                var e, f, h, i, j, k, l = 0, m = a.length, n = m - 1, q = b[0], s = r.isFunction(q);
                if (s || m > 1 && "string" == typeof q && !o.checkClone && Ba.test(q))return a.each(function (e) {
                    var f = a.eq(e);
                    s && (b[0] = q.call(this, e, f.html())), Ja(f, b, c, d)
                });
                if (m && (e = qa(b, a[0].ownerDocument, !1, a, d), f = e.firstChild, 1 === e.childNodes.length && (e = f), f || d)) {
                    for (h = r.map(na(e, "script"), Fa), i = h.length; l < m; l++)j = e, l !== n && (j = r.clone(j, !0, !0), i && r.merge(h, na(j, "script"))), c.call(a[l], j, l);
                    if (i)for (k = h[h.length - 1].ownerDocument, r.map(h, Ga), l = 0; l < i; l++)j = h[l], la.test(j.type || "") && !W.access(j, "globalEval") && r.contains(k, j) && (j.src ? r._evalUrl && r._evalUrl(j.src) : p(j.textContent.replace(Da, ""), k))
                }
                return a
            }
            function Ka(a, b, c) {
                for (var d, e = b ? r.filter(b, a) : a, f = 0; null != (d = e[f]); f++)c || 1 !== d.nodeType || r.cleanData(na(d)), d.parentNode && (c && r.contains(d.ownerDocument, d) && oa(na(d, "script")), d.parentNode.removeChild(d));
                return a
            }
            r.extend({
                htmlPrefilter: function (a) {
                    return a.replace(za, "<$1></$2>")
                }, clone: function (a, b, c) {
                    var d, e, f, g, h = a.cloneNode(!0), i = r.contains(a.ownerDocument, a);
                    if (!(o.noCloneChecked || 1 !== a.nodeType && 11 !== a.nodeType || r.isXMLDoc(a)))for (g = na(h), f = na(a), d = 0, e = f.length; d < e; d++)Ia(f[d], g[d]);
                    if (b)if (c)for (f = f || na(a), g = g || na(h), d = 0, e = f.length; d < e; d++)Ha(f[d], g[d]); else Ha(a, h);
                    return g = na(h, "script"), g.length > 0 && oa(g, !i && na(a, "script")), h
                }, cleanData: function (a) {
                    for (var b, c, d, e = r.event.special, f = 0; void 0 !== (c = a[f]); f++)if (U(c)) {
                        if (b = c[W.expando]) {
                            if (b.events)for (d in b.events)e[d] ? r.event.remove(c, d) : r.removeEvent(c, d, b.handle);
                            c[W.expando] = void 0
                        }
                        c[X.expando] && (c[X.expando] = void 0)
                    }
                }
            }), r.fn.extend({
                detach: function (a) {
                    return Ka(this, a, !0)
                }, remove: function (a) {
                    return Ka(this, a)
                }, text: function (a) {
                    return T(this, function (a) {
                        return void 0 === a ? r.text(this) : this.empty().each(function () {
                            1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = a)
                        })
                    }, null, a, arguments.length)
                }, append: function () {
                    return Ja(this, arguments, function (a) {
                        if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                            var b = Ea(this, a);
                            b.appendChild(a)
                        }
                    })
                }, prepend: function () {
                    return Ja(this, arguments, function (a) {
                        if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                            var b = Ea(this, a);
                            b.insertBefore(a, b.firstChild)
                        }
                    })
                }, before: function () {
                    return Ja(this, arguments, function (a) {
                        this.parentNode && this.parentNode.insertBefore(a, this)
                    })
                }, after: function () {
                    return Ja(this, arguments, function (a) {
                        this.parentNode && this.parentNode.insertBefore(a, this.nextSibling)
                    })
                }, empty: function () {
                    for (var a, b = 0; null != (a = this[b]); b++)1 === a.nodeType && (r.cleanData(na(a, !1)), a.textContent = "");
                    return this
                }, clone: function (a, b) {
                    return a = null != a && a, b = null == b ? a : b, this.map(function () {
                        return r.clone(this, a, b)
                    })
                }, html: function (a) {
                    return T(this, function (a) {
                        var b = this[0] || {}, c = 0, d = this.length;
                        if (void 0 === a && 1 === b.nodeType)return b.innerHTML;
                        if ("string" == typeof a && !Aa.test(a) && !ma[(ka.exec(a) || ["", ""])[1].toLowerCase()]) {
                            a = r.htmlPrefilter(a);
                            try {
                                for (; c < d; c++)b = this[c] || {}, 1 === b.nodeType && (r.cleanData(na(b, !1)), b.innerHTML = a);
                                b = 0
                            } catch (e) {
                            }
                        }
                        b && this.empty().append(a)
                    }, null, a, arguments.length)
                }, replaceWith: function () {
                    var a = [];
                    return Ja(this, arguments, function (b) {
                        var c = this.parentNode;
                        r.inArray(this, a) < 0 && (r.cleanData(na(this)), c && c.replaceChild(b, this))
                    }, a)
                }
            }), r.each({appendTo: "append", prependTo: "prepend", insertBefore: "before", insertAfter: "after", replaceAll: "replaceWith"}, function (a, b) {
                r.fn[a] = function (a) {
                    for (var c, d = [], e = r(a), f = e.length - 1, g = 0; g <= f; g++)c = g === f ? this : this.clone(!0), r(e[g])[b](c), h.apply(d, c.get());
                    return this.pushStack(d)
                }
            });
            var La = /^margin/, Ma = new RegExp("^(" + aa + ")(?!px)[a-z%]+$", "i"), Na = function (b) {
                var c = b.ownerDocument.defaultView;
                return c && c.opener || (c = a), c.getComputedStyle(b)
            };
            !function () {
                function b() {
                    if (i) {
                        i.style.cssText = "box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%", i.innerHTML = "", ra.appendChild(h);
                        var b = a.getComputedStyle(i);
                        c = "1%" !== b.top, g = "2px" === b.marginLeft, e = "4px" === b.width, i.style.marginRight = "50%", f = "4px" === b.marginRight, ra.removeChild(h), i = null
                    }
                }
                var c, e, f, g, h = d.createElement("div"), i = d.createElement("div");
                i.style && (i.style.backgroundClip = "content-box", i.cloneNode(!0).style.backgroundClip = "", o.clearCloneStyle = "content-box" === i.style.backgroundClip, h.style.cssText = "border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute", h.appendChild(i), r.extend(o, {
                    pixelPosition: function () {
                        return b(), c
                    }, boxSizingReliable: function () {
                        return b(), e
                    }, pixelMarginRight: function () {
                        return b(), f
                    }, reliableMarginLeft: function () {
                        return b(), g
                    }
                }))
            }();
            function Oa(a, b, c) {
                var d, e, f, g, h = a.style;
                return c = c || Na(a), c && (g = c.getPropertyValue(b) || c[b], "" !== g || r.contains(a.ownerDocument, a) || (g = r.style(a, b)), !o.pixelMarginRight() && Ma.test(g) && La.test(b) && (d = h.width, e = h.minWidth, f = h.maxWidth, h.minWidth = h.maxWidth = h.width = g, g = c.width, h.width = d, h.minWidth = e, h.maxWidth = f)), void 0 !== g ? g + "" : g
            }
            function Pa(a, b) {
                return {
                    get: function () {
                        return a() ? void delete this.get : (this.get = b).apply(this, arguments)
                    }
                }
            }
            var Qa = /^(none|table(?!-c[ea]).+)/, Ra = /^--/, Sa = {position: "absolute", visibility: "hidden", display: "block"}, Ta = {letterSpacing: "0", fontWeight: "400"},
                Ua = ["Webkit", "Moz", "ms"], Va = d.createElement("div").style;
            function Wa(a) {
                if (a in Va)return a;
                var b = a[0].toUpperCase() + a.slice(1), c = Ua.length;
                while (c--)if (a = Ua[c] + b, a in Va)return a
            }
            function Xa(a) {
                var b = r.cssProps[a];
                return b || (b = r.cssProps[a] = Wa(a) || a), b
            }
            function Ya(a, b, c) {
                var d = ba.exec(b);
                return d ? Math.max(0, d[2] - (c || 0)) + (d[3] || "px") : b
            }
            function Za(a, b, c, d, e) {
                var f, g = 0;
                for (f = c === (d ? "border" : "content") ? 4 : "width" === b ? 1 : 0; f < 4; f += 2)"margin" === c && (g += r.css(a, c + ca[f], !0, e)), d ? ("content" === c && (g -= r.css(a, "padding" + ca[f], !0, e)), "margin" !== c && (g -= r.css(a, "border" + ca[f] + "Width", !0, e))) : (g += r.css(a, "padding" + ca[f], !0, e), "padding" !== c && (g += r.css(a, "border" + ca[f] + "Width", !0, e)));
                return g
            }
            function $a(a, b, c) {
                var d, e = Na(a), f = Oa(a, b, e), g = "border-box" === r.css(a, "boxSizing", !1, e);
                return Ma.test(f) ? f : (d = g && (o.boxSizingReliable() || f === a.style[b]), "auto" === f && (f = a["offset" + b[0].toUpperCase() + b.slice(1)]), f = parseFloat(f) || 0, f + Za(a, b, c || (g ? "border" : "content"), d, e) + "px")
            }
            r.extend({
                cssHooks: {
                    opacity: {
                        get: function (a, b) {
                            if (b) {
                                var c = Oa(a, "opacity");
                                return "" === c ? "1" : c
                            }
                        }
                    }
                },
                cssNumber: {
                    animationIterationCount: !0,
                    columnCount: !0,
                    fillOpacity: !0,
                    flexGrow: !0,
                    flexShrink: !0,
                    fontWeight: !0,
                    lineHeight: !0,
                    opacity: !0,
                    order: !0,
                    orphans: !0,
                    widows: !0,
                    zIndex: !0,
                    zoom: !0
                },
                cssProps: {"float": "cssFloat"},
                style: function (a, b, c, d) {
                    if (a && 3 !== a.nodeType && 8 !== a.nodeType && a.style) {
                        var e, f, g, h = r.camelCase(b), i = Ra.test(b), j = a.style;
                        return i || (b = Xa(h)), g = r.cssHooks[b] || r.cssHooks[h], void 0 === c ? g && "get" in g && void 0 !== (e = g.get(a, !1, d)) ? e : j[b] : (f = typeof c, "string" === f && (e = ba.exec(c)) && e[1] && (c = fa(a, b, e), f = "number"), null != c && c === c && ("number" === f && (c += e && e[3] || (r.cssNumber[h] ? "" : "px")), o.clearCloneStyle || "" !== c || 0 !== b.indexOf("background") || (j[b] = "inherit"), g && "set" in g && void 0 === (c = g.set(a, c, d)) || (i ? j.setProperty(b, c) : j[b] = c)), void 0)
                    }
                },
                css: function (a, b, c, d) {
                    var e, f, g, h = r.camelCase(b), i = Ra.test(b);
                    return i || (b = Xa(h)), g = r.cssHooks[b] || r.cssHooks[h], g && "get" in g && (e = g.get(a, !0, c)), void 0 === e && (e = Oa(a, b, d)), "normal" === e && b in Ta && (e = Ta[b]), "" === c || c ? (f = parseFloat(e), c === !0 || isFinite(f) ? f || 0 : e) : e
                }
            }), r.each(["height", "width"], function (a, b) {
                r.cssHooks[b] = {
                    get: function (a, c, d) {
                        if (c)return !Qa.test(r.css(a, "display")) || a.getClientRects().length && a.getBoundingClientRect().width ? $a(a, b, d) : ea(a, Sa, function () {
                            return $a(a, b, d)
                        })
                    }, set: function (a, c, d) {
                        var e, f = d && Na(a), g = d && Za(a, b, d, "border-box" === r.css(a, "boxSizing", !1, f), f);
                        return g && (e = ba.exec(c)) && "px" !== (e[3] || "px") && (a.style[b] = c, c = r.css(a, b)), Ya(a, c, g)
                    }
                }
            }), r.cssHooks.marginLeft = Pa(o.reliableMarginLeft, function (a, b) {
                if (b)return (parseFloat(Oa(a, "marginLeft")) || a.getBoundingClientRect().left - ea(a, {marginLeft: 0}, function () {
                        return a.getBoundingClientRect().left
                    })) + "px"
            }), r.each({margin: "", padding: "", border: "Width"}, function (a, b) {
                r.cssHooks[a + b] = {
                    expand: function (c) {
                        for (var d = 0, e = {}, f = "string" == typeof c ? c.split(" ") : [c]; d < 4; d++)e[a + ca[d] + b] = f[d] || f[d - 2] || f[0];
                        return e
                    }
                }, La.test(a) || (r.cssHooks[a + b].set = Ya)
            }), r.fn.extend({
                css: function (a, b) {
                    return T(this, function (a, b, c) {
                        var d, e, f = {}, g = 0;
                        if (Array.isArray(b)) {
                            for (d = Na(a), e = b.length; g < e; g++)f[b[g]] = r.css(a, b[g], !1, d);
                            return f
                        }
                        return void 0 !== c ? r.style(a, b, c) : r.css(a, b)
                    }, a, b, arguments.length > 1)
                }
            });
            function _a(a, b, c, d, e) {
                return new _a.prototype.init(a, b, c, d, e)
            }
            r.Tween = _a, _a.prototype = {
                constructor: _a, init: function (a, b, c, d, e, f) {
                    this.elem = a, this.prop = c, this.easing = e || r.easing._default, this.options = b, this.start = this.now = this.cur(), this.end = d, this.unit = f || (r.cssNumber[c] ? "" : "px")
                }, cur: function () {
                    var a = _a.propHooks[this.prop];
                    return a && a.get ? a.get(this) : _a.propHooks._default.get(this)
                }, run: function (a) {
                    var b, c = _a.propHooks[this.prop];
                    return this.options.duration ? this.pos = b = r.easing[this.easing](a, this.options.duration * a, 0, 1, this.options.duration) : this.pos = b = a, this.now = (this.end - this.start) * b + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), c && c.set ? c.set(this) : _a.propHooks._default.set(this), this
                }
            }, _a.prototype.init.prototype = _a.prototype, _a.propHooks = {
                _default: {
                    get: function (a) {
                        var b;
                        return 1 !== a.elem.nodeType || null != a.elem[a.prop] && null == a.elem.style[a.prop] ? a.elem[a.prop] : (b = r.css(a.elem, a.prop, ""), b && "auto" !== b ? b : 0)
                    }, set: function (a) {
                        r.fx.step[a.prop] ? r.fx.step[a.prop](a) : 1 !== a.elem.nodeType || null == a.elem.style[r.cssProps[a.prop]] && !r.cssHooks[a.prop] ? a.elem[a.prop] = a.now : r.style(a.elem, a.prop, a.now + a.unit)
                    }
                }
            }, _a.propHooks.scrollTop = _a.propHooks.scrollLeft = {
                set: function (a) {
                    a.elem.nodeType && a.elem.parentNode && (a.elem[a.prop] = a.now)
                }
            }, r.easing = {
                linear: function (a) {
                    return a
                }, swing: function (a) {
                    return .5 - Math.cos(a * Math.PI) / 2
                }, _default: "swing"
            }, r.fx = _a.prototype.init, r.fx.step = {};
            var ab, bb, cb = /^(?:toggle|show|hide)$/, db = /queueHooks$/;
            function eb() {
                bb && (d.hidden === !1 && a.requestAnimationFrame ? a.requestAnimationFrame(eb) : a.setTimeout(eb, r.fx.interval), r.fx.tick())
            }
            function fb() {
                return a.setTimeout(function () {
                    ab = void 0
                }), ab = r.now()
            }
            function gb(a, b) {
                var c, d = 0, e = {height: a};
                for (b = b ? 1 : 0; d < 4; d += 2 - b)c = ca[d], e["margin" + c] = e["padding" + c] = a;
                return b && (e.opacity = e.width = a), e
            }
            function hb(a, b, c) {
                for (var d, e = (kb.tweeners[b] || []).concat(kb.tweeners["*"]), f = 0, g = e.length; f < g; f++)if (d = e[f].call(c, b, a))return d
            }
            function ib(a, b, c) {
                var d, e, f, g, h, i, j, k, l = "width" in b || "height" in b, m = this, n = {}, o = a.style, p = a.nodeType && da(a), q = W.get(a, "fxshow");
                c.queue || (g = r._queueHooks(a, "fx"), null == g.unqueued && (g.unqueued = 0, h = g.empty.fire, g.empty.fire = function () {
                    g.unqueued || h()
                }), g.unqueued++, m.always(function () {
                    m.always(function () {
                        g.unqueued--, r.queue(a, "fx").length || g.empty.fire()
                    })
                }));
                for (d in b)if (e = b[d], cb.test(e)) {
                    if (delete b[d], f = f || "toggle" === e, e === (p ? "hide" : "show")) {
                        if ("show" !== e || !q || void 0 === q[d])continue;
                        p = !0
                    }
                    n[d] = q && q[d] || r.style(a, d)
                }
                if (i = !r.isEmptyObject(b), i || !r.isEmptyObject(n)) {
                    l && 1 === a.nodeType && (c.overflow = [o.overflow, o.overflowX, o.overflowY], j = q && q.display, null == j && (j = W.get(a, "display")), k = r.css(a, "display"), "none" === k && (j ? k = j : (ia([a], !0), j = a.style.display || j, k = r.css(a, "display"), ia([a]))), ("inline" === k || "inline-block" === k && null != j) && "none" === r.css(a, "float") && (i || (m.done(function () {
                        o.display = j
                    }), null == j && (k = o.display, j = "none" === k ? "" : k)), o.display = "inline-block")), c.overflow && (o.overflow = "hidden", m.always(function () {
                        o.overflow = c.overflow[0], o.overflowX = c.overflow[1], o.overflowY = c.overflow[2]
                    })), i = !1;
                    for (d in n)i || (q ? "hidden" in q && (p = q.hidden) : q = W.access(a, "fxshow", {display: j}), f && (q.hidden = !p), p && ia([a], !0), m.done(function () {
                        p || ia([a]), W.remove(a, "fxshow");
                        for (d in n)r.style(a, d, n[d])
                    })), i = hb(p ? q[d] : 0, d, m), d in q || (q[d] = i.start, p && (i.end = i.start, i.start = 0))
                }
            }
            function jb(a, b) {
                var c, d, e, f, g;
                for (c in a)if (d = r.camelCase(c), e = b[d], f = a[c], Array.isArray(f) && (e = f[1], f = a[c] = f[0]), c !== d && (a[d] = f, delete a[c]), g = r.cssHooks[d], g && "expand" in g) {
                    f = g.expand(f), delete a[d];
                    for (c in f)c in a || (a[c] = f[c], b[c] = e)
                } else b[d] = e
            }
            function kb(a, b, c) {
                var d, e, f = 0, g = kb.prefilters.length, h = r.Deferred().always(function () {
                    delete i.elem
                }), i = function () {
                    if (e)return !1;
                    for (var b = ab || fb(), c = Math.max(0, j.startTime + j.duration - b), d = c / j.duration || 0, f = 1 - d, g = 0, i = j.tweens.length; g < i; g++)j.tweens[g].run(f);
                    return h.notifyWith(a, [j, f, c]), f < 1 && i ? c : (i || h.notifyWith(a, [j, 1, 0]), h.resolveWith(a, [j]), !1)
                }, j = h.promise({
                    elem: a,
                    props: r.extend({}, b),
                    opts: r.extend(!0, {specialEasing: {}, easing: r.easing._default}, c),
                    originalProperties: b,
                    originalOptions: c,
                    startTime: ab || fb(),
                    duration: c.duration,
                    tweens: [],
                    createTween: function (b, c) {
                        var d = r.Tween(a, j.opts, b, c, j.opts.specialEasing[b] || j.opts.easing);
                        return j.tweens.push(d), d
                    },
                    stop: function (b) {
                        var c = 0, d = b ? j.tweens.length : 0;
                        if (e)return this;
                        for (e = !0; c < d; c++)j.tweens[c].run(1);
                        return b ? (h.notifyWith(a, [j, 1, 0]), h.resolveWith(a, [j, b])) : h.rejectWith(a, [j, b]), this
                    }
                }), k = j.props;
                for (jb(k, j.opts.specialEasing); f < g; f++)if (d = kb.prefilters[f].call(j, a, k, j.opts))return r.isFunction(d.stop) && (r._queueHooks(j.elem, j.opts.queue).stop = r.proxy(d.stop, d)), d;
                return r.map(k, hb, j), r.isFunction(j.opts.start) && j.opts.start.call(a, j), j.progress(j.opts.progress).done(j.opts.done, j.opts.complete).fail(j.opts.fail).always(j.opts.always), r.fx.timer(r.extend(i, {
                    elem: a,
                    anim: j,
                    queue: j.opts.queue
                })), j
            }
            r.Animation = r.extend(kb, {
                tweeners: {
                    "*": [function (a, b) {
                        var c = this.createTween(a, b);
                        return fa(c.elem, a, ba.exec(b), c), c
                    }]
                }, tweener: function (a, b) {
                    r.isFunction(a) ? (b = a, a = ["*"]) : a = a.match(L);
                    for (var c, d = 0, e = a.length; d < e; d++)c = a[d], kb.tweeners[c] = kb.tweeners[c] || [], kb.tweeners[c].unshift(b)
                }, prefilters: [ib], prefilter: function (a, b) {
                    b ? kb.prefilters.unshift(a) : kb.prefilters.push(a)
                }
            }), r.speed = function (a, b, c) {
                var d = a && "object" == typeof a ? r.extend({}, a) : {complete: c || !c && b || r.isFunction(a) && a, duration: a, easing: c && b || b && !r.isFunction(b) && b};
                return r.fx.off ? d.duration = 0 : "number" != typeof d.duration && (d.duration in r.fx.speeds ? d.duration = r.fx.speeds[d.duration] : d.duration = r.fx.speeds._default), null != d.queue && d.queue !== !0 || (d.queue = "fx"), d.old = d.complete, d.complete = function () {
                    r.isFunction(d.old) && d.old.call(this), d.queue && r.dequeue(this, d.queue)
                }, d
            }, r.fn.extend({
                fadeTo: function (a, b, c, d) {
                    return this.filter(da).css("opacity", 0).show().end().animate({opacity: b}, a, c, d)
                }, animate: function (a, b, c, d) {
                    var e = r.isEmptyObject(a), f = r.speed(b, c, d), g = function () {
                        var b = kb(this, r.extend({}, a), f);
                        (e || W.get(this, "finish")) && b.stop(!0)
                    };
                    return g.finish = g, e || f.queue === !1 ? this.each(g) : this.queue(f.queue, g)
                }, stop: function (a, b, c) {
                    var d = function (a) {
                        var b = a.stop;
                        delete a.stop, b(c)
                    };
                    return "string" != typeof a && (c = b, b = a, a = void 0), b && a !== !1 && this.queue(a || "fx", []), this.each(function () {
                        var b = !0, e = null != a && a + "queueHooks", f = r.timers, g = W.get(this);
                        if (e) g[e] && g[e].stop && d(g[e]); else for (e in g)g[e] && g[e].stop && db.test(e) && d(g[e]);
                        for (e = f.length; e--;)f[e].elem !== this || null != a && f[e].queue !== a || (f[e].anim.stop(c), b = !1, f.splice(e, 1));
                        !b && c || r.dequeue(this, a)
                    })
                }, finish: function (a) {
                    return a !== !1 && (a = a || "fx"), this.each(function () {
                        var b, c = W.get(this), d = c[a + "queue"], e = c[a + "queueHooks"], f = r.timers, g = d ? d.length : 0;
                        for (c.finish = !0, r.queue(this, a, []), e && e.stop && e.stop.call(this, !0), b = f.length; b--;)f[b].elem === this && f[b].queue === a && (f[b].anim.stop(!0), f.splice(b, 1));
                        for (b = 0; b < g; b++)d[b] && d[b].finish && d[b].finish.call(this);
                        delete c.finish
                    })
                }
            }), r.each(["toggle", "show", "hide"], function (a, b) {
                var c = r.fn[b];
                r.fn[b] = function (a, d, e) {
                    return null == a || "boolean" == typeof a ? c.apply(this, arguments) : this.animate(gb(b, !0), a, d, e)
                }
            }), r.each({
                slideDown: gb("show"),
                slideUp: gb("hide"),
                slideToggle: gb("toggle"),
                fadeIn: {opacity: "show"},
                fadeOut: {opacity: "hide"},
                fadeToggle: {opacity: "toggle"}
            }, function (a, b) {
                r.fn[a] = function (a, c, d) {
                    return this.animate(b, a, c, d)
                }
            }), r.timers = [], r.fx.tick = function () {
                var a, b = 0, c = r.timers;
                for (ab = r.now(); b < c.length; b++)a = c[b], a() || c[b] !== a || c.splice(b--, 1);
                c.length || r.fx.stop(), ab = void 0
            }, r.fx.timer = function (a) {
                r.timers.push(a), r.fx.start()
            }, r.fx.interval = 13, r.fx.start = function () {
                bb || (bb = !0, eb())
            }, r.fx.stop = function () {
                bb = null
            }, r.fx.speeds = {slow: 600, fast: 200, _default: 400}, r.fn.delay = function (b, c) {
                return b = r.fx ? r.fx.speeds[b] || b : b, c = c || "fx", this.queue(c, function (c, d) {
                    var e = a.setTimeout(c, b);
                    d.stop = function () {
                        a.clearTimeout(e)
                    }
                })
            }, function () {
                var a = d.createElement("input"), b = d.createElement("select"), c = b.appendChild(d.createElement("option"));
                a.type = "checkbox", o.checkOn = "" !== a.value, o.optSelected = c.selected, a = d.createElement("input"), a.value = "t", a.type = "radio", o.radioValue = "t" === a.value
            }();
            var lb, mb = r.expr.attrHandle;
            r.fn.extend({
                attr: function (a, b) {
                    return T(this, r.attr, a, b, arguments.length > 1)
                }, removeAttr: function (a) {
                    return this.each(function () {
                        r.removeAttr(this, a)
                    })
                }
            }), r.extend({
                attr: function (a, b, c) {
                    var d, e, f = a.nodeType;
                    if (3 !== f && 8 !== f && 2 !== f)return "undefined" == typeof a.getAttribute ? r.prop(a, b, c) : (1 === f && r.isXMLDoc(a) || (e = r.attrHooks[b.toLowerCase()] || (r.expr.match.bool.test(b) ? lb : void 0)), void 0 !== c ? null === c ? void r.removeAttr(a, b) : e && "set" in e && void 0 !== (d = e.set(a, c, b)) ? d : (a.setAttribute(b, c + ""), c) : e && "get" in e && null !== (d = e.get(a, b)) ? d : (d = r.find.attr(a, b),
                        null == d ? void 0 : d))
                }, attrHooks: {
                    type: {
                        set: function (a, b) {
                            if (!o.radioValue && "radio" === b && B(a, "input")) {
                                var c = a.value;
                                return a.setAttribute("type", b), c && (a.value = c), b
                            }
                        }
                    }
                }, removeAttr: function (a, b) {
                    var c, d = 0, e = b && b.match(L);
                    if (e && 1 === a.nodeType)while (c = e[d++])a.removeAttribute(c)
                }
            }), lb = {
                set: function (a, b, c) {
                    return b === !1 ? r.removeAttr(a, c) : a.setAttribute(c, c), c
                }
            }, r.each(r.expr.match.bool.source.match(/\w+/g), function (a, b) {
                var c = mb[b] || r.find.attr;
                mb[b] = function (a, b, d) {
                    var e, f, g = b.toLowerCase();
                    return d || (f = mb[g], mb[g] = e, e = null != c(a, b, d) ? g : null, mb[g] = f), e
                }
            });
            var nb = /^(?:input|select|textarea|button)$/i, ob = /^(?:a|area)$/i;
            r.fn.extend({
                prop: function (a, b) {
                    return T(this, r.prop, a, b, arguments.length > 1)
                }, removeProp: function (a) {
                    return this.each(function () {
                        delete this[r.propFix[a] || a]
                    })
                }
            }), r.extend({
                prop: function (a, b, c) {
                    var d, e, f = a.nodeType;
                    if (3 !== f && 8 !== f && 2 !== f)return 1 === f && r.isXMLDoc(a) || (b = r.propFix[b] || b, e = r.propHooks[b]), void 0 !== c ? e && "set" in e && void 0 !== (d = e.set(a, c, b)) ? d : a[b] = c : e && "get" in e && null !== (d = e.get(a, b)) ? d : a[b]
                }, propHooks: {
                    tabIndex: {
                        get: function (a) {
                            var b = r.find.attr(a, "tabindex");
                            return b ? parseInt(b, 10) : nb.test(a.nodeName) || ob.test(a.nodeName) && a.href ? 0 : -1
                        }
                    }
                }, propFix: {"for": "htmlFor", "class": "className"}
            }), o.optSelected || (r.propHooks.selected = {
                get: function (a) {
                    var b = a.parentNode;
                    return b && b.parentNode && b.parentNode.selectedIndex, null
                }, set: function (a) {
                    var b = a.parentNode;
                    b && (b.selectedIndex, b.parentNode && b.parentNode.selectedIndex)
                }
            }), r.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function () {
                r.propFix[this.toLowerCase()] = this
            });
            function pb(a) {
                var b = a.match(L) || [];
                return b.join(" ")
            }
            function qb(a) {
                return a.getAttribute && a.getAttribute("class") || ""
            }
            r.fn.extend({
                addClass: function (a) {
                    var b, c, d, e, f, g, h, i = 0;
                    if (r.isFunction(a))return this.each(function (b) {
                        r(this).addClass(a.call(this, b, qb(this)))
                    });
                    if ("string" == typeof a && a) {
                        b = a.match(L) || [];
                        while (c = this[i++])if (e = qb(c), d = 1 === c.nodeType && " " + pb(e) + " ") {
                            g = 0;
                            while (f = b[g++])d.indexOf(" " + f + " ") < 0 && (d += f + " ");
                            h = pb(d), e !== h && c.setAttribute("class", h)
                        }
                    }
                    return this
                }, removeClass: function (a) {
                    var b, c, d, e, f, g, h, i = 0;
                    if (r.isFunction(a))return this.each(function (b) {
                        r(this).removeClass(a.call(this, b, qb(this)))
                    });
                    if (!arguments.length)return this.attr("class", "");
                    if ("string" == typeof a && a) {
                        b = a.match(L) || [];
                        while (c = this[i++])if (e = qb(c), d = 1 === c.nodeType && " " + pb(e) + " ") {
                            g = 0;
                            while (f = b[g++])while (d.indexOf(" " + f + " ") > -1)d = d.replace(" " + f + " ", " ");
                            h = pb(d), e !== h && c.setAttribute("class", h)
                        }
                    }
                    return this
                }, toggleClass: function (a, b) {
                    var c = typeof a;
                    return "boolean" == typeof b && "string" === c ? b ? this.addClass(a) : this.removeClass(a) : r.isFunction(a) ? this.each(function (c) {
                        r(this).toggleClass(a.call(this, c, qb(this), b), b)
                    }) : this.each(function () {
                        var b, d, e, f;
                        if ("string" === c) {
                            d = 0, e = r(this), f = a.match(L) || [];
                            while (b = f[d++])e.hasClass(b) ? e.removeClass(b) : e.addClass(b)
                        } else void 0 !== a && "boolean" !== c || (b = qb(this), b && W.set(this, "__className__", b), this.setAttribute && this.setAttribute("class", b || a === !1 ? "" : W.get(this, "__className__") || ""))
                    })
                }, hasClass: function (a) {
                    var b, c, d = 0;
                    b = " " + a + " ";
                    while (c = this[d++])if (1 === c.nodeType && (" " + pb(qb(c)) + " ").indexOf(b) > -1)return !0;
                    return !1
                }
            });
            var rb = /\r/g;
            r.fn.extend({
                val: function (a) {
                    var b, c, d, e = this[0];
                    {
                        if (arguments.length)return d = r.isFunction(a), this.each(function (c) {
                            var e;
                            1 === this.nodeType && (e = d ? a.call(this, c, r(this).val()) : a, null == e ? e = "" : "number" == typeof e ? e += "" : Array.isArray(e) && (e = r.map(e, function (a) {
                                    return null == a ? "" : a + ""
                                })), b = r.valHooks[this.type] || r.valHooks[this.nodeName.toLowerCase()], b && "set" in b && void 0 !== b.set(this, e, "value") || (this.value = e))
                        });
                        if (e)return b = r.valHooks[e.type] || r.valHooks[e.nodeName.toLowerCase()], b && "get" in b && void 0 !== (c = b.get(e, "value")) ? c : (c = e.value, "string" == typeof c ? c.replace(rb, "") : null == c ? "" : c)
                    }
                }
            }), r.extend({
                valHooks: {
                    option: {
                        get: function (a) {
                            var b = r.find.attr(a, "value");
                            return null != b ? b : pb(r.text(a))
                        }
                    }, select: {
                        get: function (a) {
                            var b, c, d, e = a.options, f = a.selectedIndex, g = "select-one" === a.type, h = g ? null : [], i = g ? f + 1 : e.length;
                            for (d = f < 0 ? i : g ? f : 0; d < i; d++)if (c = e[d], (c.selected || d === f) && !c.disabled && (!c.parentNode.disabled || !B(c.parentNode, "optgroup"))) {
                                if (b = r(c).val(), g)return b;
                                h.push(b)
                            }
                            return h
                        }, set: function (a, b) {
                            var c, d, e = a.options, f = r.makeArray(b), g = e.length;
                            while (g--)d = e[g], (d.selected = r.inArray(r.valHooks.option.get(d), f) > -1) && (c = !0);
                            return c || (a.selectedIndex = -1), f
                        }
                    }
                }
            }), r.each(["radio", "checkbox"], function () {
                r.valHooks[this] = {
                    set: function (a, b) {
                        if (Array.isArray(b))return a.checked = r.inArray(r(a).val(), b) > -1
                    }
                }, o.checkOn || (r.valHooks[this].get = function (a) {
                    return null === a.getAttribute("value") ? "on" : a.value
                })
            });
            var sb = /^(?:focusinfocus|focusoutblur)$/;
            r.extend(r.event, {
                trigger: function (b, c, e, f) {
                    var g, h, i, j, k, m, n, o = [e || d], p = l.call(b, "type") ? b.type : b, q = l.call(b, "namespace") ? b.namespace.split(".") : [];
                    if (h = i = e = e || d, 3 !== e.nodeType && 8 !== e.nodeType && !sb.test(p + r.event.triggered) && (p.indexOf(".") > -1 && (q = p.split("."), p = q.shift(), q.sort()), k = p.indexOf(":") < 0 && "on" + p, b = b[r.expando] ? b : new r.Event(p, "object" == typeof b && b), b.isTrigger = f ? 2 : 3, b.namespace = q.join("."), b.rnamespace = b.namespace ? new RegExp("(^|\\.)" + q.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, b.result = void 0, b.target || (b.target = e), c = null == c ? [b] : r.makeArray(c, [b]), n = r.event.special[p] || {}, f || !n.trigger || n.trigger.apply(e, c) !== !1)) {
                        if (!f && !n.noBubble && !r.isWindow(e)) {
                            for (j = n.delegateType || p, sb.test(j + p) || (h = h.parentNode); h; h = h.parentNode)o.push(h), i = h;
                            i === (e.ownerDocument || d) && o.push(i.defaultView || i.parentWindow || a)
                        }
                        g = 0;
                        while ((h = o[g++]) && !b.isPropagationStopped())b.type = g > 1 ? j : n.bindType || p, m = (W.get(h, "events") || {})[b.type] && W.get(h, "handle"), m && m.apply(h, c), m = k && h[k], m && m.apply && U(h) && (b.result = m.apply(h, c), b.result === !1 && b.preventDefault());
                        return b.type = p, f || b.isDefaultPrevented() || n._default && n._default.apply(o.pop(), c) !== !1 || !U(e) || k && r.isFunction(e[p]) && !r.isWindow(e) && (i = e[k], i && (e[k] = null), r.event.triggered = p, e[p](), r.event.triggered = void 0, i && (e[k] = i)), b.result
                    }
                }, simulate: function (a, b, c) {
                    var d = r.extend(new r.Event, c, {type: a, isSimulated: !0});
                    r.event.trigger(d, null, b)
                }
            }), r.fn.extend({
                trigger: function (a, b) {
                    return this.each(function () {
                        r.event.trigger(a, b, this)
                    })
                }, triggerHandler: function (a, b) {
                    var c = this[0];
                    if (c)return r.event.trigger(a, b, c, !0)
                }
            }), r.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function (a, b) {
                r.fn[b] = function (a, c) {
                    return arguments.length > 0 ? this.on(b, null, a, c) : this.trigger(b)
                }
            }), r.fn.extend({
                hover: function (a, b) {
                    return this.mouseenter(a).mouseleave(b || a)
                }
            }), o.focusin = "onfocusin" in a, o.focusin || r.each({focus: "focusin", blur: "focusout"}, function (a, b) {
                var c = function (a) {
                    r.event.simulate(b, a.target, r.event.fix(a))
                };
                r.event.special[b] = {
                    setup: function () {
                        var d = this.ownerDocument || this, e = W.access(d, b);
                        e || d.addEventListener(a, c, !0), W.access(d, b, (e || 0) + 1)
                    }, teardown: function () {
                        var d = this.ownerDocument || this, e = W.access(d, b) - 1;
                        e ? W.access(d, b, e) : (d.removeEventListener(a, c, !0), W.remove(d, b))
                    }
                }
            });
            var tb = a.location, ub = r.now(), vb = /\?/;
            r.parseXML = function (b) {
                var c;
                if (!b || "string" != typeof b)return null;
                try {
                    c = (new a.DOMParser).parseFromString(b, "text/xml")
                } catch (d) {
                    c = void 0
                }
                return c && !c.getElementsByTagName("parsererror").length || r.error("Invalid XML: " + b), c
            };
            var wb = /\[\]$/, xb = /\r?\n/g, yb = /^(?:submit|button|image|reset|file)$/i, zb = /^(?:input|select|textarea|keygen)/i;
            function Ab(a, b, c, d) {
                var e;
                if (Array.isArray(b)) r.each(b, function (b, e) {
                    c || wb.test(a) ? d(a, e) : Ab(a + "[" + ("object" == typeof e && null != e ? b : "") + "]", e, c, d)
                }); else if (c || "object" !== r.type(b)) d(a, b); else for (e in b)Ab(a + "[" + e + "]", b[e], c, d)
            }
            r.param = function (a, b) {
                var c, d = [], e = function (a, b) {
                    var c = r.isFunction(b) ? b() : b;
                    d[d.length] = encodeURIComponent(a) + "=" + encodeURIComponent(null == c ? "" : c)
                };
                if (Array.isArray(a) || a.jquery && !r.isPlainObject(a)) r.each(a, function () {
                    e(this.name, this.value)
                }); else for (c in a)Ab(c, a[c], b, e);
                return d.join("&")
            }, r.fn.extend({
                serialize: function () {
                    return r.param(this.serializeArray())
                }, serializeArray: function () {
                    return this.map(function () {
                        var a = r.prop(this, "elements");
                        return a ? r.makeArray(a) : this
                    }).filter(function () {
                        var a = this.type;
                        return this.name && !r(this).is(":disabled") && zb.test(this.nodeName) && !yb.test(a) && (this.checked || !ja.test(a))
                    }).map(function (a, b) {
                        var c = r(this).val();
                        return null == c ? null : Array.isArray(c) ? r.map(c, function (a) {
                            return {name: b.name, value: a.replace(xb, "\r\n")}
                        }) : {name: b.name, value: c.replace(xb, "\r\n")}
                    }).get()
                }
            });
            var Bb = /%20/g, Cb = /#.*$/, Db = /([?&])_=[^&]*/, Eb = /^(.*?):[ \t]*([^\r\n]*)$/gm, Fb = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
                Gb = /^(?:GET|HEAD)$/, Hb = /^\/\//, Ib = {}, Jb = {}, Kb = "*/".concat("*"), Lb = d.createElement("a");
            Lb.href = tb.href;
            function Mb(a) {
                return function (b, c) {
                    "string" != typeof b && (c = b, b = "*");
                    var d, e = 0, f = b.toLowerCase().match(L) || [];
                    if (r.isFunction(c))while (d = f[e++])"+" === d[0] ? (d = d.slice(1) || "*", (a[d] = a[d] || []).unshift(c)) : (a[d] = a[d] || []).push(c)
                }
            }
            function Nb(a, b, c, d) {
                var e = {}, f = a === Jb;
                function g(h) {
                    var i;
                    return e[h] = !0, r.each(a[h] || [], function (a, h) {
                        var j = h(b, c, d);
                        return "string" != typeof j || f || e[j] ? f ? !(i = j) : void 0 : (b.dataTypes.unshift(j), g(j), !1)
                    }), i
                }
                return g(b.dataTypes[0]) || !e["*"] && g("*")
            }
            function Ob(a, b) {
                var c, d, e = r.ajaxSettings.flatOptions || {};
                for (c in b)void 0 !== b[c] && ((e[c] ? a : d || (d = {}))[c] = b[c]);
                return d && r.extend(!0, a, d), a
            }
            function Pb(a, b, c) {
                var d, e, f, g, h = a.contents, i = a.dataTypes;
                while ("*" === i[0])i.shift(), void 0 === d && (d = a.mimeType || b.getResponseHeader("Content-Type"));
                if (d)for (e in h)if (h[e] && h[e].test(d)) {
                    i.unshift(e);
                    break
                }
                if (i[0] in c) f = i[0]; else {
                    for (e in c) {
                        if (!i[0] || a.converters[e + " " + i[0]]) {
                            f = e;
                            break
                        }
                        g || (g = e)
                    }
                    f = f || g
                }
                if (f)return f !== i[0] && i.unshift(f), c[f]
            }
            function Qb(a, b, c, d) {
                var e, f, g, h, i, j = {}, k = a.dataTypes.slice();
                if (k[1])for (g in a.converters)j[g.toLowerCase()] = a.converters[g];
                f = k.shift();
                while (f)if (a.responseFields[f] && (c[a.responseFields[f]] = b), !i && d && a.dataFilter && (b = a.dataFilter(b, a.dataType)), i = f, f = k.shift())if ("*" === f) f = i; else if ("*" !== i && i !== f) {
                    if (g = j[i + " " + f] || j["* " + f], !g)for (e in j)if (h = e.split(" "), h[1] === f && (g = j[i + " " + h[0]] || j["* " + h[0]])) {
                        g === !0 ? g = j[e] : j[e] !== !0 && (f = h[0], k.unshift(h[1]));
                        break
                    }
                    if (g !== !0)if (g && a["throws"]) b = g(b); else try {
                        b = g(b)
                    } catch (l) {
                        return {state: "parsererror", error: g ? l : "No conversion from " + i + " to " + f}
                    }
                }
                return {state: "success", data: b}
            }
            r.extend({
                active: 0,
                lastModified: {},
                etag: {},
                ajaxSettings: {
                    url: tb.href,
                    type: "GET",
                    isLocal: Fb.test(tb.protocol),
                    global: !0,
                    processData: !0,
                    async: !0,
                    contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                    accepts: {"*": Kb, text: "text/plain", html: "text/html", xml: "application/xml, text/xml", json: "application/json, text/javascript"},
                    contents: {xml: /\bxml\b/, html: /\bhtml/, json: /\bjson\b/},
                    responseFields: {xml: "responseXML", text: "responseText", json: "responseJSON"},
                    converters: {"* text": String, "text html": !0, "text json": JSON.parse, "text xml": r.parseXML},
                    flatOptions: {url: !0, context: !0}
                },
                ajaxSetup: function (a, b) {
                    return b ? Ob(Ob(a, r.ajaxSettings), b) : Ob(r.ajaxSettings, a)
                },
                ajaxPrefilter: Mb(Ib),
                ajaxTransport: Mb(Jb),
                ajax: function (b, c) {
                    "object" == typeof b && (c = b, b = void 0), c = c || {};
                    var e, f, g, h, i, j, k, l, m, n, o = r.ajaxSetup({}, c), p = o.context || o, q = o.context && (p.nodeType || p.jquery) ? r(p) : r.event, s = r.Deferred(),
                        t = r.Callbacks("once memory"), u = o.statusCode || {}, v = {}, w = {}, x = "canceled", y = {
                            readyState: 0, getResponseHeader: function (a) {
                                var b;
                                if (k) {
                                    if (!h) {
                                        h = {};
                                        while (b = Eb.exec(g))h[b[1].toLowerCase()] = b[2]
                                    }
                                    b = h[a.toLowerCase()]
                                }
                                return null == b ? null : b
                            }, getAllResponseHeaders: function () {
                                return k ? g : null
                            }, setRequestHeader: function (a, b) {
                                return null == k && (a = w[a.toLowerCase()] = w[a.toLowerCase()] || a, v[a] = b), this
                            }, overrideMimeType: function (a) {
                                return null == k && (o.mimeType = a), this
                            }, statusCode: function (a) {
                                var b;
                                if (a)if (k) y.always(a[y.status]); else for (b in a)u[b] = [u[b], a[b]];
                                return this
                            }, abort: function (a) {
                                var b = a || x;
                                return e && e.abort(b), A(0, b), this
                            }
                        };
                    if (s.promise(y), o.url = ((b || o.url || tb.href) + "").replace(Hb, tb.protocol + "//"), o.type = c.method || c.type || o.method || o.type, o.dataTypes = (o.dataType || "*").toLowerCase().match(L) || [""], null == o.crossDomain) {
                        j = d.createElement("a");
                        try {
                            j.href = o.url, j.href = j.href, o.crossDomain = Lb.protocol + "//" + Lb.host != j.protocol + "//" + j.host
                        } catch (z) {
                            o.crossDomain = !0
                        }
                    }
                    if (o.data && o.processData && "string" != typeof o.data && (o.data = r.param(o.data, o.traditional)), Nb(Ib, o, c, y), k)return y;
                    l = r.event && o.global, l && 0 === r.active++ && r.event.trigger("ajaxStart"), o.type = o.type.toUpperCase(), o.hasContent = !Gb.test(o.type), f = o.url.replace(Cb, ""), o.hasContent ? o.data && o.processData && 0 === (o.contentType || "").indexOf("application/x-www-form-urlencoded") && (o.data = o.data.replace(Bb, "+")) : (n = o.url.slice(f.length), o.data && (f += (vb.test(f) ? "&" : "?") + o.data, delete o.data), o.cache === !1 && (f = f.replace(Db, "$1"), n = (vb.test(f) ? "&" : "?") + "_=" + ub++ + n), o.url = f + n), o.ifModified && (r.lastModified[f] && y.setRequestHeader("If-Modified-Since", r.lastModified[f]), r.etag[f] && y.setRequestHeader("If-None-Match", r.etag[f])), (o.data && o.hasContent && o.contentType !== !1 || c.contentType) && y.setRequestHeader("Content-Type", o.contentType), y.setRequestHeader("Accept", o.dataTypes[0] && o.accepts[o.dataTypes[0]] ? o.accepts[o.dataTypes[0]] + ("*" !== o.dataTypes[0] ? ", " + Kb + "; q=0.01" : "") : o.accepts["*"]);
                    for (m in o.headers)y.setRequestHeader(m, o.headers[m]);
                    if (o.beforeSend && (o.beforeSend.call(p, y, o) === !1 || k))return y.abort();
                    if (x = "abort", t.add(o.complete), y.done(o.success), y.fail(o.error), e = Nb(Jb, o, c, y)) {
                        if (y.readyState = 1, l && q.trigger("ajaxSend", [y, o]), k)return y;
                        o.async && o.timeout > 0 && (i = a.setTimeout(function () {
                            y.abort("timeout")
                        }, o.timeout));
                        try {
                            k = !1, e.send(v, A)
                        } catch (z) {
                            if (k)throw z;
                            A(-1, z)
                        }
                    } else A(-1, "No Transport");
                    function A(b, c, d, h) {
                        var j, m, n, v, w, x = c;
                        k || (k = !0, i && a.clearTimeout(i), e = void 0, g = h || "", y.readyState = b > 0 ? 4 : 0, j = b >= 200 && b < 300 || 304 === b, d && (v = Pb(o, y, d)), v = Qb(o, v, y, j), j ? (o.ifModified && (w = y.getResponseHeader("Last-Modified"), w && (r.lastModified[f] = w), w = y.getResponseHeader("etag"), w && (r.etag[f] = w)), 204 === b || "HEAD" === o.type ? x = "nocontent" : 304 === b ? x = "notmodified" : (x = v.state, m = v.data, n = v.error, j = !n)) : (n = x, !b && x || (x = "error", b < 0 && (b = 0))), y.status = b, y.statusText = (c || x) + "", j ? s.resolveWith(p, [m, x, y]) : s.rejectWith(p, [y, x, n]), y.statusCode(u), u = void 0, l && q.trigger(j ? "ajaxSuccess" : "ajaxError", [y, o, j ? m : n]), t.fireWith(p, [y, x]), l && (q.trigger("ajaxComplete", [y, o]), --r.active || r.event.trigger("ajaxStop")))
                    }
                    return y
                },
                getJSON: function (a, b, c) {
                    return r.get(a, b, c, "json")
                },
                getScript: function (a, b) {
                    return r.get(a, void 0, b, "script")
                }
            }), r.each(["get", "post"], function (a, b) {
                r[b] = function (a, c, d, e) {
                    return r.isFunction(c) && (e = e || d, d = c, c = void 0), r.ajax(r.extend({url: a, type: b, dataType: e, data: c, success: d}, r.isPlainObject(a) && a))
                }
            }), r._evalUrl = function (a) {
                return r.ajax({url: a, type: "GET", dataType: "script", cache: !0, async: !1, global: !1, "throws": !0})
            }, r.fn.extend({
                wrapAll: function (a) {
                    var b;
                    return this[0] && (r.isFunction(a) && (a = a.call(this[0])), b = r(a, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && b.insertBefore(this[0]), b.map(function () {
                        var a = this;
                        while (a.firstElementChild)a = a.firstElementChild;
                        return a
                    }).append(this)), this
                }, wrapInner: function (a) {
                    return r.isFunction(a) ? this.each(function (b) {
                        r(this).wrapInner(a.call(this, b))
                    }) : this.each(function () {
                        var b = r(this), c = b.contents();
                        c.length ? c.wrapAll(a) : b.append(a)
                    })
                }, wrap: function (a) {
                    var b = r.isFunction(a);
                    return this.each(function (c) {
                        r(this).wrapAll(b ? a.call(this, c) : a)
                    })
                }, unwrap: function (a) {
                    return this.parent(a).not("body").each(function () {
                        r(this).replaceWith(this.childNodes)
                    }), this
                }
            }), r.expr.pseudos.hidden = function (a) {
                return !r.expr.pseudos.visible(a)
            }, r.expr.pseudos.visible = function (a) {
                return !!(a.offsetWidth || a.offsetHeight || a.getClientRects().length)
            }, r.ajaxSettings.xhr = function () {
                try {
                    return new a.XMLHttpRequest
                } catch (b) {
                }
            };
            var Rb = {0: 200, 1223: 204}, Sb = r.ajaxSettings.xhr();
            o.cors = !!Sb && "withCredentials" in Sb, o.ajax = Sb = !!Sb, r.ajaxTransport(function (b) {
                var c, d;
                if (o.cors || Sb && !b.crossDomain)return {
                    send: function (e, f) {
                        var g, h = b.xhr();
                        if (h.open(b.type, b.url, b.async, b.username, b.password), b.xhrFields)for (g in b.xhrFields)h[g] = b.xhrFields[g];
                        b.mimeType && h.overrideMimeType && h.overrideMimeType(b.mimeType), b.crossDomain || e["X-Requested-With"] || (e["X-Requested-With"] = "XMLHttpRequest");
                        for (g in e)h.setRequestHeader(g, e[g]);
                        c = function (a) {
                            return function () {
                                c && (c = d = h.onload = h.onerror = h.onabort = h.onreadystatechange = null, "abort" === a ? h.abort() : "error" === a ? "number" != typeof h.status ? f(0, "error") : f(h.status, h.statusText) : f(Rb[h.status] || h.status, h.statusText, "text" !== (h.responseType || "text") || "string" != typeof h.responseText ? {binary: h.response} : {text: h.responseText}, h.getAllResponseHeaders()))
                            }
                        }, h.onload = c(), d = h.onerror = c("error"), void 0 !== h.onabort ? h.onabort = d : h.onreadystatechange = function () {
                            4 === h.readyState && a.setTimeout(function () {
                                c && d()
                            })
                        }, c = c("abort");
                        try {
                            h.send(b.hasContent && b.data || null)
                        } catch (i) {
                            if (c)throw i
                        }
                    }, abort: function () {
                        c && c()
                    }
                }
            }), r.ajaxPrefilter(function (a) {
                a.crossDomain && (a.contents.script = !1)
            }), r.ajaxSetup({
                accepts: {script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},
                contents: {script: /\b(?:java|ecma)script\b/},
                converters: {
                    "text script": function (a) {
                        return r.globalEval(a), a
                    }
                }
            }), r.ajaxPrefilter("script", function (a) {
                void 0 === a.cache && (a.cache = !1), a.crossDomain && (a.type = "GET")
            }), r.ajaxTransport("script", function (a) {
                if (a.crossDomain) {
                    var b, c;
                    return {
                        send: function (e, f) {
                            b = r("<script>").prop({charset: a.scriptCharset, src: a.url}).on("load error", c = function (a) {
                                b.remove(), c = null, a && f("error" === a.type ? 404 : 200, a.type)
                            }), d.head.appendChild(b[0])
                        }, abort: function () {
                            c && c()
                        }
                    }
                }
            });
            var Tb = [], Ub = /(=)\?(?=&|$)|\?\?/;
            r.ajaxSetup({
                jsonp: "callback", jsonpCallback: function () {
                    var a = Tb.pop() || r.expando + "_" + ub++;
                    return this[a] = !0, a
                }
            }), r.ajaxPrefilter("json jsonp", function (b, c, d) {
                var e, f, g,
                    h = b.jsonp !== !1 && (Ub.test(b.url) ? "url" : "string" == typeof b.data && 0 === (b.contentType || "").indexOf("application/x-www-form-urlencoded") && Ub.test(b.data) && "data");
                if (h || "jsonp" === b.dataTypes[0])return e = b.jsonpCallback = r.isFunction(b.jsonpCallback) ? b.jsonpCallback() : b.jsonpCallback, h ? b[h] = b[h].replace(Ub, "$1" + e) : b.jsonp !== !1 && (b.url += (vb.test(b.url) ? "&" : "?") + b.jsonp + "=" + e), b.converters["script json"] = function () {
                    return g || r.error(e + " was not called"), g[0]
                }, b.dataTypes[0] = "json", f = a[e], a[e] = function () {
                    g = arguments
                }, d.always(function () {
                    void 0 === f ? r(a).removeProp(e) : a[e] = f, b[e] && (b.jsonpCallback = c.jsonpCallback, Tb.push(e)), g && r.isFunction(f) && f(g[0]), g = f = void 0
                }), "script"
            }), o.createHTMLDocument = function () {
                var a = d.implementation.createHTMLDocument("").body;
                return a.innerHTML = "<form></form><form></form>", 2 === a.childNodes.length
            }(), r.parseHTML = function (a, b, c) {
                if ("string" != typeof a)return [];
                "boolean" == typeof b && (c = b, b = !1);
                var e, f, g;
                return b || (o.createHTMLDocument ? (b = d.implementation.createHTMLDocument(""), e = b.createElement("base"), e.href = d.location.href, b.head.appendChild(e)) : b = d), f = C.exec(a), g = !c && [], f ? [b.createElement(f[1])] : (f = qa([a], b, g), g && g.length && r(g).remove(), r.merge([], f.childNodes))
            }, r.fn.load = function (a, b, c) {
                var d, e, f, g = this, h = a.indexOf(" ");
                return h > -1 && (d = pb(a.slice(h)), a = a.slice(0, h)), r.isFunction(b) ? (c = b, b = void 0) : b && "object" == typeof b && (e = "POST"), g.length > 0 && r.ajax({
                    url: a,
                    type: e || "GET",
                    dataType: "html",
                    data: b
                }).done(function (a) {
                    f = arguments, g.html(d ? r("<div>").append(r.parseHTML(a)).find(d) : a)
                }).always(c && function (a, b) {
                        g.each(function () {
                            c.apply(this, f || [a.responseText, b, a])
                        })
                    }), this
            }, r.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function (a, b) {
                r.fn[b] = function (a) {
                    return this.on(b, a)
                }
            }), r.expr.pseudos.animated = function (a) {
                return r.grep(r.timers, function (b) {
                    return a === b.elem
                }).length
            }, r.offset = {
                setOffset: function (a, b, c) {
                    var d, e, f, g, h, i, j, k = r.css(a, "position"), l = r(a), m = {};
                    "static" === k && (a.style.position = "relative"), h = l.offset(), f = r.css(a, "top"), i = r.css(a, "left"), j = ("absolute" === k || "fixed" === k) && (f + i).indexOf("auto") > -1, j ? (d = l.position(), g = d.top, e = d.left) : (g = parseFloat(f) || 0, e = parseFloat(i) || 0), r.isFunction(b) && (b = b.call(a, c, r.extend({}, h))), null != b.top && (m.top = b.top - h.top + g), null != b.left && (m.left = b.left - h.left + e), "using" in b ? b.using.call(a, m) : l.css(m)
                }
            }, r.fn.extend({
                offset: function (a) {
                    if (arguments.length)return void 0 === a ? this : this.each(function (b) {
                        r.offset.setOffset(this, a, b)
                    });
                    var b, c, d, e, f = this[0];
                    if (f)return f.getClientRects().length ? (d = f.getBoundingClientRect(), b = f.ownerDocument, c = b.documentElement, e = b.defaultView, {
                        top: d.top + e.pageYOffset - c.clientTop,
                        left: d.left + e.pageXOffset - c.clientLeft
                    }) : {top: 0, left: 0}
                }, position: function () {
                    if (this[0]) {
                        var a, b, c = this[0], d = {top: 0, left: 0};
                        return "fixed" === r.css(c, "position") ? b = c.getBoundingClientRect() : (a = this.offsetParent(), b = this.offset(), B(a[0], "html") || (d = a.offset()), d = {
                            top: d.top + r.css(a[0], "borderTopWidth", !0),
                            left: d.left + r.css(a[0], "borderLeftWidth", !0)
                        }), {top: b.top - d.top - r.css(c, "marginTop", !0), left: b.left - d.left - r.css(c, "marginLeft", !0)}
                    }
                }, offsetParent: function () {
                    return this.map(function () {
                        var a = this.offsetParent;
                        while (a && "static" === r.css(a, "position"))a = a.offsetParent;
                        return a || ra
                    })
                }
            }), r.each({scrollLeft: "pageXOffset", scrollTop: "pageYOffset"}, function (a, b) {
                var c = "pageYOffset" === b;
                r.fn[a] = function (d) {
                    return T(this, function (a, d, e) {
                        var f;
                        return r.isWindow(a) ? f = a : 9 === a.nodeType && (f = a.defaultView), void 0 === e ? f ? f[b] : a[d] : void(f ? f.scrollTo(c ? f.pageXOffset : e, c ? e : f.pageYOffset) : a[d] = e)
                    }, a, d, arguments.length)
                }
            }), r.each(["top", "left"], function (a, b) {
                r.cssHooks[b] = Pa(o.pixelPosition, function (a, c) {
                    if (c)return c = Oa(a, b), Ma.test(c) ? r(a).position()[b] + "px" : c
                })
            }), r.each({Height: "height", Width: "width"}, function (a, b) {
                r.each({padding: "inner" + a, content: b, "": "outer" + a}, function (c, d) {
                    r.fn[d] = function (e, f) {
                        var g = arguments.length && (c || "boolean" != typeof e), h = c || (e === !0 || f === !0 ? "margin" : "border");
                        return T(this, function (b, c, e) {
                            var f;
                            return r.isWindow(b) ? 0 === d.indexOf("outer") ? b["inner" + a] : b.document.documentElement["client" + a] : 9 === b.nodeType ? (f = b.documentElement, Math.max(b.body["scroll" + a], f["scroll" + a], b.body["offset" + a], f["offset" + a], f["client" + a])) : void 0 === e ? r.css(b, c, h) : r.style(b, c, e, h)
                        }, b, g ? e : void 0, g)
                    }
                })
            }), r.fn.extend({
                bind: function (a, b, c) {
                    return this.on(a, null, b, c)
                }, unbind: function (a, b) {
                    return this.off(a, null, b)
                }, delegate: function (a, b, c, d) {
                    return this.on(b, a, c, d)
                }, undelegate: function (a, b, c) {
                    return 1 === arguments.length ? this.off(a, "**") : this.off(b, a || "**", c)
                }
            }), r.holdReady = function (a) {
                a ? r.readyWait++ : r.ready(!0)
            }, r.isArray = Array.isArray, r.parseJSON = JSON.parse, r.nodeName = B, "function" == typeof define && define.amd && define("jquery", [], function () {
                return r
            });
            var Vb = a.jQuery, Wb = a.$;
            return r.noConflict = function (b) {
                return a.$ === r && (a.$ = Wb), b && a.jQuery === r && (a.jQuery = Vb), r
            }, b || (a.jQuery = a.$ = r), r
        });
        var KalturaAccessControlProfileService = {
            add: function (accessControlProfile) {
                var kparams = new Object();
                kparams.accessControlProfile = accessControlProfile;
                return new KalturaRequestBuilder("accesscontrolprofile", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("accesscontrolprofile", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("accesscontrolprofile", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("accesscontrolprofile", "list", kparams);
            },
            update: function (id, accessControlProfile) {
                var kparams = new Object();
                kparams.id = id;
                kparams.accessControlProfile = accessControlProfile;
                return new KalturaRequestBuilder("accesscontrolprofile", "update", kparams);
            }
        }
        var KalturaAccessControlService = {
            add: function (accessControl) {
                var kparams = new Object();
                kparams.accessControl = accessControl;
                return new KalturaRequestBuilder("accesscontrol", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("accesscontrol", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("accesscontrol", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("accesscontrol", "list", kparams);
            },
            update: function (id, accessControl) {
                var kparams = new Object();
                kparams.id = id;
                kparams.accessControl = accessControl;
                return new KalturaRequestBuilder("accesscontrol", "update", kparams);
            }
        }
        var KalturaAdminUserService = {
            login: function (email, password, partnerId) {
                if (!partnerId)
                    partnerId = null;
                var kparams = new Object();
                kparams.email = email;
                kparams.password = password;
                kparams.partnerId = partnerId;
                return new KalturaRequestBuilder("adminuser", "login", kparams);
            },
            resetPassword: function (email) {
                var kparams = new Object();
                kparams.email = email;
                return new KalturaRequestBuilder("adminuser", "resetPassword", kparams);
            },
            setInitialPassword: function (hashKey, newPassword) {
                var kparams = new Object();
                kparams.hashKey = hashKey;
                kparams.newPassword = newPassword;
                return new KalturaRequestBuilder("adminuser", "setInitialPassword", kparams);
            },
            updatePassword: function (email, password, newEmail, newPassword) {
                if (!newEmail)
                    newEmail = "";
                if (!newPassword)
                    newPassword = "";
                var kparams = new Object();
                kparams.email = email;
                kparams.password = password;
                kparams.newEmail = newEmail;
                kparams.newPassword = newPassword;
                return new KalturaRequestBuilder("adminuser", "updatePassword", kparams);
            }
        }
        var KalturaAnalyticsService = {
            query: function (filter, pager) {
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("analytics", "query", kparams);
            }
        }
        var KalturaAppTokenService = {
            add: function (appToken) {
                var kparams = new Object();
                kparams.appToken = appToken;
                return new KalturaRequestBuilder("apptoken", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("apptoken", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("apptoken", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("apptoken", "list", kparams);
            },
            startSession: function (id, tokenHash, userId, type, expiry) {
                if (!userId)
                    userId = null;
                if (!type)
                    type = null;
                if (!expiry)
                    expiry = null;
                var kparams = new Object();
                kparams.id = id;
                kparams.tokenHash = tokenHash;
                kparams.userId = userId;
                kparams.type = type;
                kparams.expiry = expiry;
                return new KalturaRequestBuilder("apptoken", "startSession", kparams);
            },
            update: function (id, appToken) {
                var kparams = new Object();
                kparams.id = id;
                kparams.appToken = appToken;
                return new KalturaRequestBuilder("apptoken", "update", kparams);
            }
        }
        var KalturaBaseEntryService = {
            add: function (entry, type) {
                if (!type)
                    type = null;
                var kparams = new Object();
                kparams.entry = entry;
                kparams.type = type;
                return new KalturaRequestBuilder("baseentry", "add", kparams);
            },
            addContent: function (entryId, resource) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.resource = resource;
                return new KalturaRequestBuilder("baseentry", "addContent", kparams);
            },
            addFromUploadedFile: function (entry, uploadTokenId, type) {
                if (!type)
                    type = null;
                var kparams = new Object();
                kparams.entry = entry;
                kparams.uploadTokenId = uploadTokenId;
                kparams.type = type;
                return new KalturaRequestBuilder("baseentry", "addFromUploadedFile", kparams);
            },
            anonymousRank: function (entryId, rank) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.rank = rank;
                return new KalturaRequestBuilder("baseentry", "anonymousRank", kparams);
            },
            approve: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("baseentry", "approve", kparams);
            },
            cloneAction: function (entryId, cloneOptions) {
                if (!cloneOptions)
                    cloneOptions = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.cloneOptions = cloneOptions;
                return new KalturaRequestBuilder("baseentry", "clone", kparams);
            },
            count: function (filter) {
                if (!filter)
                    filter = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                return new KalturaRequestBuilder("baseentry", "count", kparams);
            },
            deleteAction: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("baseentry", "delete", kparams);
            },
            exportAction: function (entryId, storageProfileId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.storageProfileId = storageProfileId;
                return new KalturaRequestBuilder("baseentry", "export", kparams);
            },
            flag: function (moderationFlag) {
                var kparams = new Object();
                kparams.moderationFlag = moderationFlag;
                return new KalturaRequestBuilder("baseentry", "flag", kparams);
            },
            get: function (entryId, version) {
                if (!version)
                    version = -1;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.version = version;
                return new KalturaRequestBuilder("baseentry", "get", kparams);
            },
            getByIds: function (entryIds) {
                var kparams = new Object();
                kparams.entryIds = entryIds;
                return new KalturaRequestBuilder("baseentry", "getByIds", kparams);
            },
            getContextData: function (entryId, contextDataParams) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.contextDataParams = contextDataParams;
                return new KalturaRequestBuilder("baseentry", "getContextData", kparams);
            },
            getPlaybackContext: function (entryId, contextDataParams) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.contextDataParams = contextDataParams;
                return new KalturaRequestBuilder("baseentry", "getPlaybackContext", kparams);
            },
            getRemotePaths: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("baseentry", "getRemotePaths", kparams);
            },
            index: function (id, shouldUpdate) {
                if (!shouldUpdate)
                    shouldUpdate = true;
                var kparams = new Object();
                kparams.id = id;
                kparams.shouldUpdate = shouldUpdate;
                return new KalturaRequestBuilder("baseentry", "index", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("baseentry", "list", kparams);
            },
            listByReferenceId: function (refId, pager) {
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.refId = refId;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("baseentry", "listByReferenceId", kparams);
            },
            listFlags: function (entryId, pager) {
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("baseentry", "listFlags", kparams);
            },
            reject: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("baseentry", "reject", kparams);
            },
            update: function (entryId, baseEntry) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.baseEntry = baseEntry;
                return new KalturaRequestBuilder("baseentry", "update", kparams);
            },
            updateContent: function (entryId, resource, conversionProfileId, advancedOptions) {
                if (!conversionProfileId)
                    conversionProfileId = null;
                if (!advancedOptions)
                    advancedOptions = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.resource = resource;
                kparams.conversionProfileId = conversionProfileId;
                if (advancedOptions != null)
                    kparams.advancedOptions = advancedOptions;
                return new KalturaRequestBuilder("baseentry", "updateContent", kparams);
            },
            updateThumbnailFromSourceEntry: function (entryId, sourceEntryId, timeOffset) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.sourceEntryId = sourceEntryId;
                kparams.timeOffset = timeOffset;
                return new KalturaRequestBuilder("baseentry", "updateThumbnailFromSourceEntry", kparams);
            },
            updateThumbnailFromUrl: function (entryId, url) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.url = url;
                return new KalturaRequestBuilder("baseentry", "updateThumbnailFromUrl", kparams);
            }
        }
        var KalturaBulkUploadService = {
            abort: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("bulkupload", "abort", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("bulkupload", "get", kparams);
            },
            listAction: function (pager) {
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("bulkupload", "list", kparams);
            }
        }
        var KalturaCategoryEntryService = {
            activate: function (entryId, categoryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.categoryId = categoryId;
                return new KalturaRequestBuilder("categoryentry", "activate", kparams);
            },
            add: function (categoryEntry) {
                var kparams = new Object();
                kparams.categoryEntry = categoryEntry;
                return new KalturaRequestBuilder("categoryentry", "add", kparams);
            },
            addFromBulkUpload: function (bulkUploadData, bulkUploadCategoryEntryData) {
                if (!bulkUploadCategoryEntryData)
                    bulkUploadCategoryEntryData = null;
                var kparams = new Object();
                kparams.bulkUploadData = bulkUploadData;
                if (bulkUploadCategoryEntryData != null)
                    kparams.bulkUploadCategoryEntryData = bulkUploadCategoryEntryData;
                return new KalturaRequestBuilder("categoryentry", "addFromBulkUpload", kparams);
            },
            deleteAction: function (entryId, categoryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.categoryId = categoryId;
                return new KalturaRequestBuilder("categoryentry", "delete", kparams);
            },
            index: function (entryId, categoryId, shouldUpdate) {
                if (!shouldUpdate)
                    shouldUpdate = true;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.categoryId = categoryId;
                kparams.shouldUpdate = shouldUpdate;
                return new KalturaRequestBuilder("categoryentry", "index", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("categoryentry", "list", kparams);
            },
            reject: function (entryId, categoryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.categoryId = categoryId;
                return new KalturaRequestBuilder("categoryentry", "reject", kparams);
            },
            syncPrivacyContext: function (entryId, categoryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.categoryId = categoryId;
                return new KalturaRequestBuilder("categoryentry", "syncPrivacyContext", kparams);
            }
        }
        var KalturaCategoryService = {
            add: function (category) {
                var kparams = new Object();
                kparams.category = category;
                return new KalturaRequestBuilder("category", "add", kparams);
            },
            deleteAction: function (id, moveEntriesToParentCategory) {
                if (!moveEntriesToParentCategory)
                    moveEntriesToParentCategory = 1;
                var kparams = new Object();
                kparams.id = id;
                kparams.moveEntriesToParentCategory = moveEntriesToParentCategory;
                return new KalturaRequestBuilder("category", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("category", "get", kparams);
            },
            index: function (id, shouldUpdate) {
                if (!shouldUpdate)
                    shouldUpdate = true;
                var kparams = new Object();
                kparams.id = id;
                kparams.shouldUpdate = shouldUpdate;
                return new KalturaRequestBuilder("category", "index", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("category", "list", kparams);
            },
            move: function (categoryIds, targetCategoryParentId) {
                var kparams = new Object();
                kparams.categoryIds = categoryIds;
                kparams.targetCategoryParentId = targetCategoryParentId;
                return new KalturaRequestBuilder("category", "move", kparams);
            },
            unlockCategories: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("category", "unlockCategories", kparams);
            },
            update: function (id, category) {
                var kparams = new Object();
                kparams.id = id;
                kparams.category = category;
                return new KalturaRequestBuilder("category", "update", kparams);
            }
        }
        var KalturaCategoryUserService = {
            activate: function (categoryId, userId) {
                var kparams = new Object();
                kparams.categoryId = categoryId;
                kparams.userId = userId;
                return new KalturaRequestBuilder("categoryuser", "activate", kparams);
            },
            add: function (categoryUser) {
                var kparams = new Object();
                kparams.categoryUser = categoryUser;
                return new KalturaRequestBuilder("categoryuser", "add", kparams);
            },
            copyFromCategory: function (categoryId) {
                var kparams = new Object();
                kparams.categoryId = categoryId;
                return new KalturaRequestBuilder("categoryuser", "copyFromCategory", kparams);
            },
            deactivate: function (categoryId, userId) {
                var kparams = new Object();
                kparams.categoryId = categoryId;
                kparams.userId = userId;
                return new KalturaRequestBuilder("categoryuser", "deactivate", kparams);
            },
            deleteAction: function (categoryId, userId) {
                var kparams = new Object();
                kparams.categoryId = categoryId;
                kparams.userId = userId;
                return new KalturaRequestBuilder("categoryuser", "delete", kparams);
            },
            get: function (categoryId, userId) {
                var kparams = new Object();
                kparams.categoryId = categoryId;
                kparams.userId = userId;
                return new KalturaRequestBuilder("categoryuser", "get", kparams);
            },
            index: function (userId, categoryId, shouldUpdate) {
                if (!shouldUpdate)
                    shouldUpdate = true;
                var kparams = new Object();
                kparams.userId = userId;
                kparams.categoryId = categoryId;
                kparams.shouldUpdate = shouldUpdate;
                return new KalturaRequestBuilder("categoryuser", "index", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("categoryuser", "list", kparams);
            },
            update: function (categoryId, userId, categoryUser, override) {
                if (!override)
                    override = false;
                var kparams = new Object();
                kparams.categoryId = categoryId;
                kparams.userId = userId;
                kparams.categoryUser = categoryUser;
                kparams.override = override;
                return new KalturaRequestBuilder("categoryuser", "update", kparams);
            }
        }
        var KalturaConversionProfileAssetParamsService = {
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("conversionprofileassetparams", "list", kparams);
            },
            update: function (conversionProfileId, assetParamsId, conversionProfileAssetParams) {
                var kparams = new Object();
                kparams.conversionProfileId = conversionProfileId;
                kparams.assetParamsId = assetParamsId;
                kparams.conversionProfileAssetParams = conversionProfileAssetParams;
                return new KalturaRequestBuilder("conversionprofileassetparams", "update", kparams);
            }
        }
        var KalturaConversionProfileService = {
            add: function (conversionProfile) {
                var kparams = new Object();
                kparams.conversionProfile = conversionProfile;
                return new KalturaRequestBuilder("conversionprofile", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("conversionprofile", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("conversionprofile", "get", kparams);
            },
            getDefault: function (type) {
                if (!type)
                    type = null;
                var kparams = new Object();
                kparams.type = type;
                return new KalturaRequestBuilder("conversionprofile", "getDefault", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("conversionprofile", "list", kparams);
            },
            setAsDefault: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("conversionprofile", "setAsDefault", kparams);
            },
            update: function (id, conversionProfile) {
                var kparams = new Object();
                kparams.id = id;
                kparams.conversionProfile = conversionProfile;
                return new KalturaRequestBuilder("conversionprofile", "update", kparams);
            }
        }
        var KalturaDataService = {
            add: function (dataEntry) {
                var kparams = new Object();
                kparams.dataEntry = dataEntry;
                return new KalturaRequestBuilder("data", "add", kparams);
            },
            deleteAction: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("data", "delete", kparams);
            },
            get: function (entryId, version) {
                if (!version)
                    version = -1;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.version = version;
                return new KalturaRequestBuilder("data", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("data", "list", kparams);
            },
            update: function (entryId, documentEntry) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.documentEntry = documentEntry;
                return new KalturaRequestBuilder("data", "update", kparams);
            }
        }
        var KalturaDeliveryProfileService = {
            add: function (delivery) {
                var kparams = new Object();
                kparams.delivery = delivery;
                return new KalturaRequestBuilder("deliveryprofile", "add", kparams);
            },
            cloneAction: function (deliveryId) {
                var kparams = new Object();
                kparams.deliveryId = deliveryId;
                return new KalturaRequestBuilder("deliveryprofile", "clone", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("deliveryprofile", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("deliveryprofile", "list", kparams);
            },
            update: function (id, delivery) {
                var kparams = new Object();
                kparams.id = id;
                kparams.delivery = delivery;
                return new KalturaRequestBuilder("deliveryprofile", "update", kparams);
            }
        }
        var KalturaEmailIngestionProfileService = {
            add: function (EmailIP) {
                var kparams = new Object();
                kparams.EmailIP = EmailIP;
                return new KalturaRequestBuilder("emailingestionprofile", "add", kparams);
            },
            addMediaEntry: function (mediaEntry, uploadTokenId, emailProfId, fromAddress, emailMsgId) {
                var kparams = new Object();
                kparams.mediaEntry = mediaEntry;
                kparams.uploadTokenId = uploadTokenId;
                kparams.emailProfId = emailProfId;
                kparams.fromAddress = fromAddress;
                kparams.emailMsgId = emailMsgId;
                return new KalturaRequestBuilder("emailingestionprofile", "addMediaEntry", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("emailingestionprofile", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("emailingestionprofile", "get", kparams);
            },
            getByEmailAddress: function (emailAddress) {
                var kparams = new Object();
                kparams.emailAddress = emailAddress;
                return new KalturaRequestBuilder("emailingestionprofile", "getByEmailAddress", kparams);
            },
            update: function (id, EmailIP) {
                var kparams = new Object();
                kparams.id = id;
                kparams.EmailIP = EmailIP;
                return new KalturaRequestBuilder("emailingestionprofile", "update", kparams);
            }
        }
        var KalturaEntryServerNodeService = {
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("entryservernode", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("entryservernode", "list", kparams);
            },
            update: function (id, entryServerNode) {
                var kparams = new Object();
                kparams.id = id;
                kparams.entryServerNode = entryServerNode;
                return new KalturaRequestBuilder("entryservernode", "update", kparams);
            },
            validateRegisteredEntryServerNode: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("entryservernode", "validateRegisteredEntryServerNode", kparams);
            }
        }
        var KalturaFileAssetService = {
            add: function (fileAsset) {
                var kparams = new Object();
                kparams.fileAsset = fileAsset;
                return new KalturaRequestBuilder("fileasset", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("fileasset", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("fileasset", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("fileasset", "list", kparams);
            },
            setContent: function (id, contentResource) {
                var kparams = new Object();
                kparams.id = id;
                kparams.contentResource = contentResource;
                return new KalturaRequestBuilder("fileasset", "setContent", kparams);
            },
            update: function (id, fileAsset) {
                var kparams = new Object();
                kparams.id = id;
                kparams.fileAsset = fileAsset;
                return new KalturaRequestBuilder("fileasset", "update", kparams);
            }
        }
        var KalturaFlavorAssetService = {
            add: function (entryId, flavorAsset) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.flavorAsset = flavorAsset;
                return new KalturaRequestBuilder("flavorasset", "add", kparams);
            },
            convert: function (entryId, flavorParamsId, priority) {
                if (!priority)
                    priority = 0;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.flavorParamsId = flavorParamsId;
                kparams.priority = priority;
                return new KalturaRequestBuilder("flavorasset", "convert", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("flavorasset", "delete", kparams);
            },
            deleteLocalContent: function (assetId) {
                var kparams = new Object();
                kparams.assetId = assetId;
                return new KalturaRequestBuilder("flavorasset", "deleteLocalContent", kparams);
            },
            exportAction: function (assetId, storageProfileId) {
                var kparams = new Object();
                kparams.assetId = assetId;
                kparams.storageProfileId = storageProfileId;
                return new KalturaRequestBuilder("flavorasset", "export", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("flavorasset", "get", kparams);
            },
            getByEntryId: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("flavorasset", "getByEntryId", kparams);
            },
            getDownloadUrl: function (id, useCdn) {
                if (!useCdn)
                    useCdn = false;
                var kparams = new Object();
                kparams.id = id;
                kparams.useCdn = useCdn;
                return new KalturaRequestBuilder("flavorasset", "getDownloadUrl", kparams);
            },
            getFlavorAssetsWithParams: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("flavorasset", "getFlavorAssetsWithParams", kparams);
            },
            getRemotePaths: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("flavorasset", "getRemotePaths", kparams);
            },
            getUrl: function (id, storageId, forceProxy, options) {
                if (!storageId)
                    storageId = null;
                if (!forceProxy)
                    forceProxy = false;
                if (!options)
                    options = null;
                var kparams = new Object();
                kparams.id = id;
                kparams.storageId = storageId;
                kparams.forceProxy = forceProxy;
                if (options != null)
                    kparams.options = options;
                return new KalturaRequestBuilder("flavorasset", "getUrl", kparams);
            },
            getWebPlayableByEntryId: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("flavorasset", "getWebPlayableByEntryId", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("flavorasset", "list", kparams);
            },
            reconvert: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("flavorasset", "reconvert", kparams);
            },
            serveAdStitchCmd: function (assetId, ffprobeJson, duration) {
                if (!ffprobeJson)
                    ffprobeJson = null;
                if (!duration)
                    duration = null;
                var kparams = new Object();
                kparams.assetId = assetId;
                kparams.ffprobeJson = ffprobeJson;
                kparams.duration = duration;
                return new KalturaRequestBuilder("flavorasset", "serveAdStitchCmd", kparams);
            },
            setAsSource: function (assetId) {
                var kparams = new Object();
                kparams.assetId = assetId;
                return new KalturaRequestBuilder("flavorasset", "setAsSource", kparams);
            },
            setContent: function (id, contentResource) {
                var kparams = new Object();
                kparams.id = id;
                kparams.contentResource = contentResource;
                return new KalturaRequestBuilder("flavorasset", "setContent", kparams);
            },
            update: function (id, flavorAsset) {
                var kparams = new Object();
                kparams.id = id;
                kparams.flavorAsset = flavorAsset;
                return new KalturaRequestBuilder("flavorasset", "update", kparams);
            }
        }
        var KalturaFlavorParamsOutputService = {
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("flavorparamsoutput", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("flavorparamsoutput", "list", kparams);
            }
        }
        var KalturaFlavorParamsService = {
            add: function (flavorParams) {
                var kparams = new Object();
                kparams.flavorParams = flavorParams;
                return new KalturaRequestBuilder("flavorparams", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("flavorparams", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("flavorparams", "get", kparams);
            },
            getByConversionProfileId: function (conversionProfileId) {
                var kparams = new Object();
                kparams.conversionProfileId = conversionProfileId;
                return new KalturaRequestBuilder("flavorparams", "getByConversionProfileId", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("flavorparams", "list", kparams);
            },
            update: function (id, flavorParams) {
                var kparams = new Object();
                kparams.id = id;
                kparams.flavorParams = flavorParams;
                return new KalturaRequestBuilder("flavorparams", "update", kparams);
            }
        }
        var KalturaGroupUserService = {
            add: function (groupUser) {
                var kparams = new Object();
                kparams.groupUser = groupUser;
                return new KalturaRequestBuilder("groupuser", "add", kparams);
            },
            deleteAction: function (userId, groupId) {
                var kparams = new Object();
                kparams.userId = userId;
                kparams.groupId = groupId;
                return new KalturaRequestBuilder("groupuser", "delete", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("groupuser", "list", kparams);
            }
        }
        var KalturaLiveChannelSegmentService = {
            add: function (liveChannelSegment) {
                var kparams = new Object();
                kparams.liveChannelSegment = liveChannelSegment;
                return new KalturaRequestBuilder("livechannelsegment", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("livechannelsegment", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("livechannelsegment", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("livechannelsegment", "list", kparams);
            },
            update: function (id, liveChannelSegment) {
                var kparams = new Object();
                kparams.id = id;
                kparams.liveChannelSegment = liveChannelSegment;
                return new KalturaRequestBuilder("livechannelsegment", "update", kparams);
            }
        }
        var KalturaLiveChannelService = {
            add: function (liveChannel) {
                var kparams = new Object();
                kparams.liveChannel = liveChannel;
                return new KalturaRequestBuilder("livechannel", "add", kparams);
            },
            appendRecording: function (entryId, assetId, mediaServerIndex, resource, duration, isLastChunk) {
                if (!isLastChunk)
                    isLastChunk = false;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.assetId = assetId;
                kparams.mediaServerIndex = mediaServerIndex;
                kparams.resource = resource;
                kparams.duration = duration;
                kparams.isLastChunk = isLastChunk;
                return new KalturaRequestBuilder("livechannel", "appendRecording", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("livechannel", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("livechannel", "get", kparams);
            },
            isLive: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("livechannel", "isLive", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("livechannel", "list", kparams);
            },
            registerMediaServer: function (entryId, hostname, mediaServerIndex, applicationName, liveEntryStatus) {
                if (!applicationName)
                    applicationName = null;
                if (!liveEntryStatus)
                    liveEntryStatus = 1;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.hostname = hostname;
                kparams.mediaServerIndex = mediaServerIndex;
                kparams.applicationName = applicationName;
                kparams.liveEntryStatus = liveEntryStatus;
                return new KalturaRequestBuilder("livechannel", "registerMediaServer", kparams);
            },
            setRecordedContent: function (entryId, mediaServerIndex, resource, duration, recordedEntryId) {
                if (!recordedEntryId)
                    recordedEntryId = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.mediaServerIndex = mediaServerIndex;
                kparams.resource = resource;
                kparams.duration = duration;
                kparams.recordedEntryId = recordedEntryId;
                return new KalturaRequestBuilder("livechannel", "setRecordedContent", kparams);
            },
            unregisterMediaServer: function (entryId, hostname, mediaServerIndex) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.hostname = hostname;
                kparams.mediaServerIndex = mediaServerIndex;
                return new KalturaRequestBuilder("livechannel", "unregisterMediaServer", kparams);
            },
            update: function (id, liveChannel) {
                var kparams = new Object();
                kparams.id = id;
                kparams.liveChannel = liveChannel;
                return new KalturaRequestBuilder("livechannel", "update", kparams);
            },
            validateRegisteredMediaServers: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("livechannel", "validateRegisteredMediaServers", kparams);
            }
        }
        var KalturaLiveReportsService = {
            exportToCsv: function (reportType, params) {
                var kparams = new Object();
                kparams.reportType = reportType;
                kparams.params = params;
                return new KalturaRequestBuilder("livereports", "exportToCsv", kparams);
            },
            getEvents: function (reportType, filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.reportType = reportType;
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("livereports", "getEvents", kparams);
            },
            getReport: function (reportType, filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.reportType = reportType;
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("livereports", "getReport", kparams);
            },
            serveReport: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("livereports", "serveReport", kparams);
            }
        }
        var KalturaLiveStatsService = {
            collect: function (event) {
                var kparams = new Object();
                kparams.event = event;
                return new KalturaRequestBuilder("livestats", "collect", kparams);
            }
        }
        var KalturaLiveStreamService = {
            add: function (liveStreamEntry, sourceType) {
                if (!sourceType)
                    sourceType = null;
                var kparams = new Object();
                kparams.liveStreamEntry = liveStreamEntry;
                kparams.sourceType = sourceType;
                return new KalturaRequestBuilder("livestream", "add", kparams);
            },
            addLiveStreamPushPublishConfiguration: function (entryId, protocol, url, liveStreamConfiguration) {
                if (!url)
                    url = null;
                if (!liveStreamConfiguration)
                    liveStreamConfiguration = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.protocol = protocol;
                kparams.url = url;
                if (liveStreamConfiguration != null)
                    kparams.liveStreamConfiguration = liveStreamConfiguration;
                return new KalturaRequestBuilder("livestream", "addLiveStreamPushPublishConfiguration", kparams);
            },
            appendRecording: function (entryId, assetId, mediaServerIndex, resource, duration, isLastChunk) {
                if (!isLastChunk)
                    isLastChunk = false;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.assetId = assetId;
                kparams.mediaServerIndex = mediaServerIndex;
                kparams.resource = resource;
                kparams.duration = duration;
                kparams.isLastChunk = isLastChunk;
                return new KalturaRequestBuilder("livestream", "appendRecording", kparams);
            },
            authenticate: function (entryId, token, hostname, mediaServerIndex, applicationName) {
                if (!hostname)
                    hostname = null;
                if (!mediaServerIndex)
                    mediaServerIndex = null;
                if (!applicationName)
                    applicationName = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.token = token;
                kparams.hostname = hostname;
                kparams.mediaServerIndex = mediaServerIndex;
                kparams.applicationName = applicationName;
                return new KalturaRequestBuilder("livestream", "authenticate", kparams);
            },
            createPeriodicSyncPoints: function (entryId, interval, duration) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.interval = interval;
                kparams.duration = duration;
                return new KalturaRequestBuilder("livestream", "createPeriodicSyncPoints", kparams);
            },
            deleteAction: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("livestream", "delete", kparams);
            },
            get: function (entryId, version) {
                if (!version)
                    version = -1;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.version = version;
                return new KalturaRequestBuilder("livestream", "get", kparams);
            },
            isLive: function (id, protocol) {
                var kparams = new Object();
                kparams.id = id;
                kparams.protocol = protocol;
                return new KalturaRequestBuilder("livestream", "isLive", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("livestream", "list", kparams);
            },
            regenerateStreamToken: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("livestream", "regenerateStreamToken", kparams);
            },
            registerMediaServer: function (entryId, hostname, mediaServerIndex, applicationName, liveEntryStatus) {
                if (!applicationName)
                    applicationName = null;
                if (!liveEntryStatus)
                    liveEntryStatus = 1;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.hostname = hostname;
                kparams.mediaServerIndex = mediaServerIndex;
                kparams.applicationName = applicationName;
                kparams.liveEntryStatus = liveEntryStatus;
                return new KalturaRequestBuilder("livestream", "registerMediaServer", kparams);
            },
            removeLiveStreamPushPublishConfiguration: function (entryId, protocol) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.protocol = protocol;
                return new KalturaRequestBuilder("livestream", "removeLiveStreamPushPublishConfiguration", kparams);
            },
            setRecordedContent: function (entryId, mediaServerIndex, resource, duration, recordedEntryId) {
                if (!recordedEntryId)
                    recordedEntryId = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.mediaServerIndex = mediaServerIndex;
                kparams.resource = resource;
                kparams.duration = duration;
                kparams.recordedEntryId = recordedEntryId;
                return new KalturaRequestBuilder("livestream", "setRecordedContent", kparams);
            },
            unregisterMediaServer: function (entryId, hostname, mediaServerIndex) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.hostname = hostname;
                kparams.mediaServerIndex = mediaServerIndex;
                return new KalturaRequestBuilder("livestream", "unregisterMediaServer", kparams);
            },
            update: function (entryId, liveStreamEntry) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.liveStreamEntry = liveStreamEntry;
                return new KalturaRequestBuilder("livestream", "update", kparams);
            },
            updateOfflineThumbnailFromUrl: function (entryId, url) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.url = url;
                return new KalturaRequestBuilder("livestream", "updateOfflineThumbnailFromUrl", kparams);
            },
            validateRegisteredMediaServers: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("livestream", "validateRegisteredMediaServers", kparams);
            }
        }
        var KalturaMediaInfoService = {
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("mediainfo", "list", kparams);
            }
        }
        var KalturaMediaService = {
            add: function (entry) {
                var kparams = new Object();
                kparams.entry = entry;
                return new KalturaRequestBuilder("media", "add", kparams);
            },
            addContent: function (entryId, resource) {
                if (!resource)
                    resource = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                if (resource != null)
                    kparams.resource = resource;
                return new KalturaRequestBuilder("media", "addContent", kparams);
            },
            addFromBulk: function (mediaEntry, url, bulkUploadId) {
                var kparams = new Object();
                kparams.mediaEntry = mediaEntry;
                kparams.url = url;
                kparams.bulkUploadId = bulkUploadId;
                return new KalturaRequestBuilder("media", "addFromBulk", kparams);
            },
            addFromEntry: function (sourceEntryId, mediaEntry, sourceFlavorParamsId) {
                if (!mediaEntry)
                    mediaEntry = null;
                if (!sourceFlavorParamsId)
                    sourceFlavorParamsId = null;
                var kparams = new Object();
                kparams.sourceEntryId = sourceEntryId;
                if (mediaEntry != null)
                    kparams.mediaEntry = mediaEntry;
                kparams.sourceFlavorParamsId = sourceFlavorParamsId;
                return new KalturaRequestBuilder("media", "addFromEntry", kparams);
            },
            addFromFlavorAsset: function (sourceFlavorAssetId, mediaEntry) {
                if (!mediaEntry)
                    mediaEntry = null;
                var kparams = new Object();
                kparams.sourceFlavorAssetId = sourceFlavorAssetId;
                if (mediaEntry != null)
                    kparams.mediaEntry = mediaEntry;
                return new KalturaRequestBuilder("media", "addFromFlavorAsset", kparams);
            },
            addFromRecordedWebcam: function (mediaEntry, webcamTokenId) {
                var kparams = new Object();
                kparams.mediaEntry = mediaEntry;
                kparams.webcamTokenId = webcamTokenId;
                return new KalturaRequestBuilder("media", "addFromRecordedWebcam", kparams);
            },
            addFromSearchResult: function (mediaEntry, searchResult) {
                if (!mediaEntry)
                    mediaEntry = null;
                if (!searchResult)
                    searchResult = null;
                var kparams = new Object();
                if (mediaEntry != null)
                    kparams.mediaEntry = mediaEntry;
                if (searchResult != null)
                    kparams.searchResult = searchResult;
                return new KalturaRequestBuilder("media", "addFromSearchResult", kparams);
            },
            addFromUploadedFile: function (mediaEntry, uploadTokenId) {
                var kparams = new Object();
                kparams.mediaEntry = mediaEntry;
                kparams.uploadTokenId = uploadTokenId;
                return new KalturaRequestBuilder("media", "addFromUploadedFile", kparams);
            },
            addFromUrl: function (mediaEntry, url) {
                var kparams = new Object();
                kparams.mediaEntry = mediaEntry;
                kparams.url = url;
                return new KalturaRequestBuilder("media", "addFromUrl", kparams);
            },
            anonymousRank: function (entryId, rank) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.rank = rank;
                return new KalturaRequestBuilder("media", "anonymousRank", kparams);
            },
            approve: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("media", "approve", kparams);
            },
            approveReplace: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("media", "approveReplace", kparams);
            },
            cancelReplace: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("media", "cancelReplace", kparams);
            },
            convert: function (entryId, conversionProfileId, dynamicConversionAttributes) {
                if (!conversionProfileId)
                    conversionProfileId = null;
                if (!dynamicConversionAttributes)
                    dynamicConversionAttributes = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.conversionProfileId = conversionProfileId;
                kparams.dynamicConversionAttributes = dynamicConversionAttributes;
                return new KalturaRequestBuilder("media", "convert", kparams);
            },
            count: function (filter) {
                if (!filter)
                    filter = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                return new KalturaRequestBuilder("media", "count", kparams);
            },
            deleteAction: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("media", "delete", kparams);
            },
            flag: function (moderationFlag) {
                var kparams = new Object();
                kparams.moderationFlag = moderationFlag;
                return new KalturaRequestBuilder("media", "flag", kparams);
            },
            get: function (entryId, version) {
                if (!version)
                    version = -1;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.version = version;
                return new KalturaRequestBuilder("media", "get", kparams);
            },
            getMrss: function (entryId, extendingItemsArray, features) {
                if (!extendingItemsArray)
                    extendingItemsArray = null;
                if (!features)
                    features = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.extendingItemsArray = extendingItemsArray;
                kparams.features = features;
                return new KalturaRequestBuilder("media", "getMrss", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("media", "list", kparams);
            },
            listFlags: function (entryId, pager) {
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("media", "listFlags", kparams);
            },
            reject: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("media", "reject", kparams);
            },
            requestConversion: function (entryId, fileFormat) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.fileFormat = fileFormat;
                return new KalturaRequestBuilder("media", "requestConversion", kparams);
            },
            update: function (entryId, mediaEntry) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.mediaEntry = mediaEntry;
                return new KalturaRequestBuilder("media", "update", kparams);
            },
            updateContent: function (entryId, resource, conversionProfileId, advancedOptions) {
                if (!conversionProfileId)
                    conversionProfileId = null;
                if (!advancedOptions)
                    advancedOptions = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.resource = resource;
                kparams.conversionProfileId = conversionProfileId;
                if (advancedOptions != null)
                    kparams.advancedOptions = advancedOptions;
                return new KalturaRequestBuilder("media", "updateContent", kparams);
            },
            updateThumbnail: function (entryId, timeOffset, flavorParamsId) {
                if (!flavorParamsId)
                    flavorParamsId = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.timeOffset = timeOffset;
                kparams.flavorParamsId = flavorParamsId;
                return new KalturaRequestBuilder("media", "updateThumbnail", kparams);
            },
            updateThumbnailFromSourceEntry: function (entryId, sourceEntryId, timeOffset, flavorParamsId) {
                if (!flavorParamsId)
                    flavorParamsId = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.sourceEntryId = sourceEntryId;
                kparams.timeOffset = timeOffset;
                kparams.flavorParamsId = flavorParamsId;
                return new KalturaRequestBuilder("media", "updateThumbnailFromSourceEntry", kparams);
            },
            updateThumbnailFromUrl: function (entryId, url) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.url = url;
                return new KalturaRequestBuilder("media", "updateThumbnailFromUrl", kparams);
            }
        }
        var KalturaMixingService = {
            add: function (mixEntry) {
                var kparams = new Object();
                kparams.mixEntry = mixEntry;
                return new KalturaRequestBuilder("mixing", "add", kparams);
            },
            anonymousRank: function (entryId, rank) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.rank = rank;
                return new KalturaRequestBuilder("mixing", "anonymousRank", kparams);
            },
            appendMediaEntry: function (mixEntryId, mediaEntryId) {
                var kparams = new Object();
                kparams.mixEntryId = mixEntryId;
                kparams.mediaEntryId = mediaEntryId;
                return new KalturaRequestBuilder("mixing", "appendMediaEntry", kparams);
            },
            cloneAction: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("mixing", "clone", kparams);
            },
            count: function (filter) {
                if (!filter)
                    filter = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                return new KalturaRequestBuilder("mixing", "count", kparams);
            },
            deleteAction: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("mixing", "delete", kparams);
            },
            get: function (entryId, version) {
                if (!version)
                    version = -1;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.version = version;
                return new KalturaRequestBuilder("mixing", "get", kparams);
            },
            getMixesByMediaId: function (mediaEntryId) {
                var kparams = new Object();
                kparams.mediaEntryId = mediaEntryId;
                return new KalturaRequestBuilder("mixing", "getMixesByMediaId", kparams);
            },
            getReadyMediaEntries: function (mixId, version) {
                if (!version)
                    version = -1;
                var kparams = new Object();
                kparams.mixId = mixId;
                kparams.version = version;
                return new KalturaRequestBuilder("mixing", "getReadyMediaEntries", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("mixing", "list", kparams);
            },
            update: function (entryId, mixEntry) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.mixEntry = mixEntry;
                return new KalturaRequestBuilder("mixing", "update", kparams);
            }
        }
        var KalturaNotificationService = {
            getClientNotification: function (entryId, type) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.type = type;
                return new KalturaRequestBuilder("notification", "getClientNotification", kparams);
            }
        }
        var KalturaPartnerService = {
            count: function (filter) {
                if (!filter)
                    filter = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                return new KalturaRequestBuilder("partner", "count", kparams);
            },
            get: function (id) {
                if (!id)
                    id = null;
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("partner", "get", kparams);
            },
            getInfo: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("partner", "getInfo", kparams);
            },
            getSecrets: function (partnerId, adminEmail, cmsPassword) {
                var kparams = new Object();
                kparams.partnerId = partnerId;
                kparams.adminEmail = adminEmail;
                kparams.cmsPassword = cmsPassword;
                return new KalturaRequestBuilder("partner", "getSecrets", kparams);
            },
            getStatistics: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("partner", "getStatistics", kparams);
            },
            getUsage: function (year, month, resolution) {
                if (!year)
                    year = "";
                if (!month)
                    month = 1;
                if (!resolution)
                    resolution = null;
                var kparams = new Object();
                kparams.year = year;
                kparams.month = month;
                kparams.resolution = resolution;
                return new KalturaRequestBuilder("partner", "getUsage", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("partner", "list", kparams);
            },
            listFeatureStatus: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("partner", "listFeatureStatus", kparams);
            },
            listPartnersForUser: function (partnerFilter, pager) {
                if (!partnerFilter)
                    partnerFilter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (partnerFilter != null)
                    kparams.partnerFilter = partnerFilter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("partner", "listPartnersForUser", kparams);
            },
            register: function (partner, cmsPassword, templatePartnerId, silent) {
                if (!cmsPassword)
                    cmsPassword = "";
                if (!templatePartnerId)
                    templatePartnerId = null;
                if (!silent)
                    silent = false;
                var kparams = new Object();
                kparams.partner = partner;
                kparams.cmsPassword = cmsPassword;
                kparams.templatePartnerId = templatePartnerId;
                kparams.silent = silent;
                return new KalturaRequestBuilder("partner", "register", kparams);
            },
            update: function (partner, allowEmpty) {
                if (!allowEmpty)
                    allowEmpty = false;
                var kparams = new Object();
                kparams.partner = partner;
                kparams.allowEmpty = allowEmpty;
                return new KalturaRequestBuilder("partner", "update", kparams);
            }
        }
        var KalturaPermissionItemService = {
            add: function (permissionItem) {
                var kparams = new Object();
                kparams.permissionItem = permissionItem;
                return new KalturaRequestBuilder("permissionitem", "add", kparams);
            },
            deleteAction: function (permissionItemId) {
                var kparams = new Object();
                kparams.permissionItemId = permissionItemId;
                return new KalturaRequestBuilder("permissionitem", "delete", kparams);
            },
            get: function (permissionItemId) {
                var kparams = new Object();
                kparams.permissionItemId = permissionItemId;
                return new KalturaRequestBuilder("permissionitem", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("permissionitem", "list", kparams);
            },
            update: function (permissionItemId, permissionItem) {
                var kparams = new Object();
                kparams.permissionItemId = permissionItemId;
                kparams.permissionItem = permissionItem;
                return new KalturaRequestBuilder("permissionitem", "update", kparams);
            }
        }
        var KalturaPermissionService = {
            add: function (permission) {
                var kparams = new Object();
                kparams.permission = permission;
                return new KalturaRequestBuilder("permission", "add", kparams);
            },
            deleteAction: function (permissionName) {
                var kparams = new Object();
                kparams.permissionName = permissionName;
                return new KalturaRequestBuilder("permission", "delete", kparams);
            },
            get: function (permissionName) {
                var kparams = new Object();
                kparams.permissionName = permissionName;
                return new KalturaRequestBuilder("permission", "get", kparams);
            },
            getCurrentPermissions: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("permission", "getCurrentPermissions", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("permission", "list", kparams);
            },
            update: function (permissionName, permission) {
                var kparams = new Object();
                kparams.permissionName = permissionName;
                kparams.permission = permission;
                return new KalturaRequestBuilder("permission", "update", kparams);
            }
        }
        var KalturaPlaylistService = {
            add: function (playlist, updateStats) {
                if (!updateStats)
                    updateStats = false;
                var kparams = new Object();
                kparams.playlist = playlist;
                kparams.updateStats = updateStats;
                return new KalturaRequestBuilder("playlist", "add", kparams);
            },
            cloneAction: function (id, newPlaylist) {
                if (!newPlaylist)
                    newPlaylist = null;
                var kparams = new Object();
                kparams.id = id;
                if (newPlaylist != null)
                    kparams.newPlaylist = newPlaylist;
                return new KalturaRequestBuilder("playlist", "clone", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("playlist", "delete", kparams);
            },
            execute: function (id, detailed, playlistContext, filter, pager) {
                if (!detailed)
                    detailed = "";
                if (!playlistContext)
                    playlistContext = null;
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.id = id;
                kparams.detailed = detailed;
                if (playlistContext != null)
                    kparams.playlistContext = playlistContext;
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("playlist", "execute", kparams);
            },
            executeFromContent: function (playlistType, playlistContent, detailed, pager) {
                if (!detailed)
                    detailed = "";
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.playlistType = playlistType;
                kparams.playlistContent = playlistContent;
                kparams.detailed = detailed;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("playlist", "executeFromContent", kparams);
            },
            executeFromFilters: function (filters, totalResults, detailed, pager) {
                if (!detailed)
                    detailed = 1;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.filters = filters;
                kparams.totalResults = totalResults;
                kparams.detailed = detailed;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("playlist", "executeFromFilters", kparams);
            },
            get: function (id, version) {
                if (!version)
                    version = -1;
                var kparams = new Object();
                kparams.id = id;
                kparams.version = version;
                return new KalturaRequestBuilder("playlist", "get", kparams);
            },
            getStatsFromContent: function (playlistType, playlistContent) {
                var kparams = new Object();
                kparams.playlistType = playlistType;
                kparams.playlistContent = playlistContent;
                return new KalturaRequestBuilder("playlist", "getStatsFromContent", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("playlist", "list", kparams);
            },
            update: function (id, playlist, updateStats) {
                if (!updateStats)
                    updateStats = false;
                var kparams = new Object();
                kparams.id = id;
                kparams.playlist = playlist;
                kparams.updateStats = updateStats;
                return new KalturaRequestBuilder("playlist", "update", kparams);
            }
        }
        var KalturaReportService = {
            execute: function (id, params) {
                if (!params)
                    params = null;
                var kparams = new Object();
                kparams.id = id;
                kparams.params = params;
                return new KalturaRequestBuilder("report", "execute", kparams);
            },
            getBaseTotal: function (reportType, reportInputFilter, objectIds) {
                if (!objectIds)
                    objectIds = null;
                var kparams = new Object();
                kparams.reportType = reportType;
                kparams.reportInputFilter = reportInputFilter;
                kparams.objectIds = objectIds;
                return new KalturaRequestBuilder("report", "getBaseTotal", kparams);
            },
            getGraphs: function (reportType, reportInputFilter, dimension, objectIds) {
                if (!dimension)
                    dimension = null;
                if (!objectIds)
                    objectIds = null;
                var kparams = new Object();
                kparams.reportType = reportType;
                kparams.reportInputFilter = reportInputFilter;
                kparams.dimension = dimension;
                kparams.objectIds = objectIds;
                return new KalturaRequestBuilder("report", "getGraphs", kparams);
            },
            getTable: function (reportType, reportInputFilter, pager, order, objectIds) {
                if (!order)
                    order = null;
                if (!objectIds)
                    objectIds = null;
                var kparams = new Object();
                kparams.reportType = reportType;
                kparams.reportInputFilter = reportInputFilter;
                kparams.pager = pager;
                kparams.order = order;
                kparams.objectIds = objectIds;
                return new KalturaRequestBuilder("report", "getTable", kparams);
            },
            getTotal: function (reportType, reportInputFilter, objectIds) {
                if (!objectIds)
                    objectIds = null;
                var kparams = new Object();
                kparams.reportType = reportType;
                kparams.reportInputFilter = reportInputFilter;
                kparams.objectIds = objectIds;
                return new KalturaRequestBuilder("report", "getTotal", kparams);
            },
            getUrlForReportAsCsv: function (reportTitle, reportText, headers, reportType, reportInputFilter, dimension, pager, order, objectIds) {
                if (!dimension)
                    dimension = null;
                if (!pager)
                    pager = null;
                if (!order)
                    order = null;
                if (!objectIds)
                    objectIds = null;
                var kparams = new Object();
                kparams.reportTitle = reportTitle;
                kparams.reportText = reportText;
                kparams.headers = headers;
                kparams.reportType = reportType;
                kparams.reportInputFilter = reportInputFilter;
                kparams.dimension = dimension;
                if (pager != null)
                    kparams.pager = pager;
                kparams.order = order;
                kparams.objectIds = objectIds;
                return new KalturaRequestBuilder("report", "getUrlForReportAsCsv", kparams);
            },
            serve: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("report", "serve", kparams);
            }
        }
        var KalturaResponseProfileService = {
            add: function (addResponseProfile) {
                var kparams = new Object();
                kparams.addResponseProfile = addResponseProfile;
                return new KalturaRequestBuilder("responseprofile", "add", kparams);
            },
            cloneAction: function (id, profile) {
                var kparams = new Object();
                kparams.id = id;
                kparams.profile = profile;
                return new KalturaRequestBuilder("responseprofile", "clone", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("responseprofile", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("responseprofile", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("responseprofile", "list", kparams);
            },
            recalculate: function (options) {
                var kparams = new Object();
                kparams.options = options;
                return new KalturaRequestBuilder("responseprofile", "recalculate", kparams);
            },
            update: function (id, updateResponseProfile) {
                var kparams = new Object();
                kparams.id = id;
                kparams.updateResponseProfile = updateResponseProfile;
                return new KalturaRequestBuilder("responseprofile", "update", kparams);
            },
            updateStatus: function (id, status) {
                var kparams = new Object();
                kparams.id = id;
                kparams.status = status;
                return new KalturaRequestBuilder("responseprofile", "updateStatus", kparams);
            }
        }
        var KalturaSchemaService = {}
        var KalturaSearchService = {
            externalLogin: function (searchSource, userName, password) {
                var kparams = new Object();
                kparams.searchSource = searchSource;
                kparams.userName = userName;
                kparams.password = password;
                return new KalturaRequestBuilder("search", "externalLogin", kparams);
            },
            getMediaInfo: function (searchResult) {
                var kparams = new Object();
                kparams.searchResult = searchResult;
                return new KalturaRequestBuilder("search", "getMediaInfo", kparams);
            },
            search: function (search, pager) {
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.search = search;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("search", "search", kparams);
            },
            searchUrl: function (mediaType, url) {
                var kparams = new Object();
                kparams.mediaType = mediaType;
                kparams.url = url;
                return new KalturaRequestBuilder("search", "searchUrl", kparams);
            }
        }
        var KalturaServerNodeService = {
            add: function (serverNode) {
                var kparams = new Object();
                kparams.serverNode = serverNode;
                return new KalturaRequestBuilder("servernode", "add", kparams);
            },
            deleteAction: function (serverNodeId) {
                var kparams = new Object();
                kparams.serverNodeId = serverNodeId;
                return new KalturaRequestBuilder("servernode", "delete", kparams);
            },
            disable: function (serverNodeId) {
                var kparams = new Object();
                kparams.serverNodeId = serverNodeId;
                return new KalturaRequestBuilder("servernode", "disable", kparams);
            },
            enable: function (serverNodeId) {
                var kparams = new Object();
                kparams.serverNodeId = serverNodeId;
                return new KalturaRequestBuilder("servernode", "enable", kparams);
            },
            get: function (serverNodeId) {
                var kparams = new Object();
                kparams.serverNodeId = serverNodeId;
                return new KalturaRequestBuilder("servernode", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("servernode", "list", kparams);
            },
            reportStatus: function (hostName, serverNode) {
                if (!serverNode)
                    serverNode = null;
                var kparams = new Object();
                kparams.hostName = hostName;
                if (serverNode != null)
                    kparams.serverNode = serverNode;
                return new KalturaRequestBuilder("servernode", "reportStatus", kparams);
            },
            update: function (serverNodeId, serverNode) {
                var kparams = new Object();
                kparams.serverNodeId = serverNodeId;
                kparams.serverNode = serverNode;
                return new KalturaRequestBuilder("servernode", "update", kparams);
            }
        }
        var KalturaSessionService = {
            end: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("session", "end", kparams);
            },
            get: function (session) {
                if (!session)
                    session = null;
                var kparams = new Object();
                kparams.session = session;
                return new KalturaRequestBuilder("session", "get", kparams);
            },
            impersonate: function (secret, impersonatedPartnerId, userId, type, partnerId, expiry, privileges) {
                if (!userId)
                    userId = "";
                if (!type)
                    type = 0;
                if (!partnerId)
                    partnerId = null;
                if (!expiry)
                    expiry = 86400;
                if (!privileges)
                    privileges = null;
                var kparams = new Object();
                kparams.secret = secret;
                kparams.impersonatedPartnerId = impersonatedPartnerId;
                kparams.userId = userId;
                kparams.type = type;
                kparams.partnerId = partnerId;
                kparams.expiry = expiry;
                kparams.privileges = privileges;
                return new KalturaRequestBuilder("session", "impersonate", kparams);
            },
            impersonateByKs: function (session, type, expiry, privileges) {
                if (!type)
                    type = null;
                if (!expiry)
                    expiry = null;
                if (!privileges)
                    privileges = null;
                var kparams = new Object();
                kparams.session = session;
                kparams.type = type;
                kparams.expiry = expiry;
                kparams.privileges = privileges;
                return new KalturaRequestBuilder("session", "impersonateByKs", kparams);
            },
            start: function (secret, userId, type, partnerId, expiry, privileges) {
                if (!userId)
                    userId = "";
                if (!type)
                    type = 0;
                if (!partnerId)
                    partnerId = null;
                if (!expiry)
                    expiry = 86400;
                if (!privileges)
                    privileges = null;
                var kparams = new Object();
                kparams.secret = secret;
                kparams.userId = userId;
                kparams.type = type;
                kparams.partnerId = partnerId;
                kparams.expiry = expiry;
                kparams.privileges = privileges;
                return new KalturaRequestBuilder("session", "start", kparams);
            },
            startWidgetSession: function (widgetId, expiry) {
                if (!expiry)
                    expiry = 86400;
                var kparams = new Object();
                kparams.widgetId = widgetId;
                kparams.expiry = expiry;
                return new KalturaRequestBuilder("session", "startWidgetSession", kparams);
            }
        }
        var KalturaStatsService = {
            collect: function (event) {
                var kparams = new Object();
                kparams.event = event;
                return new KalturaRequestBuilder("stats", "collect", kparams);
            },
            kmcCollect: function (kmcEvent) {
                var kparams = new Object();
                kparams.kmcEvent = kmcEvent;
                return new KalturaRequestBuilder("stats", "kmcCollect", kparams);
            },
            reportError: function (errorCode, errorMessage) {
                var kparams = new Object();
                kparams.errorCode = errorCode;
                kparams.errorMessage = errorMessage;
                return new KalturaRequestBuilder("stats", "reportError", kparams);
            },
            reportKceError: function (kalturaCEError) {
                var kparams = new Object();
                kparams.kalturaCEError = kalturaCEError;
                return new KalturaRequestBuilder("stats", "reportKceError", kparams);
            }
        }
        var KalturaStorageProfileService = {
            add: function (storageProfile) {
                var kparams = new Object();
                kparams.storageProfile = storageProfile;
                return new KalturaRequestBuilder("storageprofile", "add", kparams);
            },
            get: function (storageProfileId) {
                var kparams = new Object();
                kparams.storageProfileId = storageProfileId;
                return new KalturaRequestBuilder("storageprofile", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("storageprofile", "list", kparams);
            },
            update: function (storageProfileId, storageProfile) {
                var kparams = new Object();
                kparams.storageProfileId = storageProfileId;
                kparams.storageProfile = storageProfile;
                return new KalturaRequestBuilder("storageprofile", "update", kparams);
            },
            updateStatus: function (storageId, status) {
                var kparams = new Object();
                kparams.storageId = storageId;
                kparams.status = status;
                return new KalturaRequestBuilder("storageprofile", "updateStatus", kparams);
            }
        }
        var KalturaSyndicationFeedService = {
            add: function (syndicationFeed) {
                var kparams = new Object();
                kparams.syndicationFeed = syndicationFeed;
                return new KalturaRequestBuilder("syndicationfeed", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("syndicationfeed", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("syndicationfeed", "get", kparams);
            },
            getEntryCount: function (feedId) {
                var kparams = new Object();
                kparams.feedId = feedId;
                return new KalturaRequestBuilder("syndicationfeed", "getEntryCount", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("syndicationfeed", "list", kparams);
            },
            requestConversion: function (feedId) {
                var kparams = new Object();
                kparams.feedId = feedId;
                return new KalturaRequestBuilder("syndicationfeed", "requestConversion", kparams);
            },
            update: function (id, syndicationFeed) {
                var kparams = new Object();
                kparams.id = id;
                kparams.syndicationFeed = syndicationFeed;
                return new KalturaRequestBuilder("syndicationfeed", "update", kparams);
            }
        }
        var KalturaSystemService = {
            getTime: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("system", "getTime", kparams);
            },
            getVersion: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("system", "getVersion", kparams);
            },
            ping: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("system", "ping", kparams);
            },
            pingDatabase: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("system", "pingDatabase", kparams);
            }
        }
        var KalturaThumbAssetService = {
            add: function (entryId, thumbAsset) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.thumbAsset = thumbAsset;
                return new KalturaRequestBuilder("thumbasset", "add", kparams);
            },
            addFromUrl: function (entryId, url) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.url = url;
                return new KalturaRequestBuilder("thumbasset", "addFromUrl", kparams);
            },
            deleteAction: function (thumbAssetId) {
                var kparams = new Object();
                kparams.thumbAssetId = thumbAssetId;
                return new KalturaRequestBuilder("thumbasset", "delete", kparams);
            },
            exportAction: function (assetId, storageProfileId) {
                var kparams = new Object();
                kparams.assetId = assetId;
                kparams.storageProfileId = storageProfileId;
                return new KalturaRequestBuilder("thumbasset", "export", kparams);
            },
            generate: function (entryId, thumbParams, sourceAssetId) {
                if (!sourceAssetId)
                    sourceAssetId = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.thumbParams = thumbParams;
                kparams.sourceAssetId = sourceAssetId;
                return new KalturaRequestBuilder("thumbasset", "generate", kparams);
            },
            generateByEntryId: function (entryId, destThumbParamsId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.destThumbParamsId = destThumbParamsId;
                return new KalturaRequestBuilder("thumbasset", "generateByEntryId", kparams);
            },
            get: function (thumbAssetId) {
                var kparams = new Object();
                kparams.thumbAssetId = thumbAssetId;
                return new KalturaRequestBuilder("thumbasset", "get", kparams);
            },
            getByEntryId: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("thumbasset", "getByEntryId", kparams);
            },
            getRemotePaths: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("thumbasset", "getRemotePaths", kparams);
            },
            getUrl: function (id, storageId, thumbParams) {
                if (!storageId)
                    storageId = null;
                if (!thumbParams)
                    thumbParams = null;
                var kparams = new Object();
                kparams.id = id;
                kparams.storageId = storageId;
                if (thumbParams != null)
                    kparams.thumbParams = thumbParams;
                return new KalturaRequestBuilder("thumbasset", "getUrl", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("thumbasset", "list", kparams);
            },
            regenerate: function (thumbAssetId) {
                var kparams = new Object();
                kparams.thumbAssetId = thumbAssetId;
                return new KalturaRequestBuilder("thumbasset", "regenerate", kparams);
            },
            setAsDefault: function (thumbAssetId) {
                var kparams = new Object();
                kparams.thumbAssetId = thumbAssetId;
                return new KalturaRequestBuilder("thumbasset", "setAsDefault", kparams);
            },
            setContent: function (id, contentResource) {
                var kparams = new Object();
                kparams.id = id;
                kparams.contentResource = contentResource;
                return new KalturaRequestBuilder("thumbasset", "setContent", kparams);
            },
            update: function (id, thumbAsset) {
                var kparams = new Object();
                kparams.id = id;
                kparams.thumbAsset = thumbAsset;
                return new KalturaRequestBuilder("thumbasset", "update", kparams);
            }
        }
        var KalturaThumbParamsOutputService = {
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("thumbparamsoutput", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("thumbparamsoutput", "list", kparams);
            }
        }
        var KalturaThumbParamsService = {
            add: function (thumbParams) {
                var kparams = new Object();
                kparams.thumbParams = thumbParams;
                return new KalturaRequestBuilder("thumbparams", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("thumbparams", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("thumbparams", "get", kparams);
            },
            getByConversionProfileId: function (conversionProfileId) {
                var kparams = new Object();
                kparams.conversionProfileId = conversionProfileId;
                return new KalturaRequestBuilder("thumbparams", "getByConversionProfileId", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("thumbparams", "list", kparams);
            },
            update: function (id, thumbParams) {
                var kparams = new Object();
                kparams.id = id;
                kparams.thumbParams = thumbParams;
                return new KalturaRequestBuilder("thumbparams", "update", kparams);
            }
        }
        var KalturaUiConfService = {
            add: function (uiConf) {
                var kparams = new Object();
                kparams.uiConf = uiConf;
                return new KalturaRequestBuilder("uiconf", "add", kparams);
            },
            cloneAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("uiconf", "clone", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("uiconf", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("uiconf", "get", kparams);
            },
            getAvailableTypes: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("uiconf", "getAvailableTypes", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("uiconf", "list", kparams);
            },
            listTemplates: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("uiconf", "listTemplates", kparams);
            },
            update: function (id, uiConf) {
                var kparams = new Object();
                kparams.id = id;
                kparams.uiConf = uiConf;
                return new KalturaRequestBuilder("uiconf", "update", kparams);
            }
        }
        var KalturaUploadService = {
            getUploadedFileTokenByFileName: function (fileName) {
                var kparams = new Object();
                kparams.fileName = fileName;
                return new KalturaRequestBuilder("upload", "getUploadedFileTokenByFileName", kparams);
            }
        }
        var KalturaUploadTokenService = {
            add: function (uploadToken) {
                if (!uploadToken)
                    uploadToken = null;
                var kparams = new Object();
                if (uploadToken != null)
                    kparams.uploadToken = uploadToken;
                return new KalturaRequestBuilder("uploadtoken", "add", kparams);
            },
            deleteAction: function (uploadTokenId) {
                var kparams = new Object();
                kparams.uploadTokenId = uploadTokenId;
                return new KalturaRequestBuilder("uploadtoken", "delete", kparams);
            },
            get: function (uploadTokenId) {
                var kparams = new Object();
                kparams.uploadTokenId = uploadTokenId;
                return new KalturaRequestBuilder("uploadtoken", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("uploadtoken", "list", kparams);
            }
        }
        var KalturaUserEntryService = {
            add: function (userEntry) {
                var kparams = new Object();
                kparams.userEntry = userEntry;
                return new KalturaRequestBuilder("userentry", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("userentry", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("userentry", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("userentry", "list", kparams);
            },
            submitQuiz: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("userentry", "submitQuiz", kparams);
            },
            update: function (id, userEntry) {
                var kparams = new Object();
                kparams.id = id;
                kparams.userEntry = userEntry;
                return new KalturaRequestBuilder("userentry", "update", kparams);
            }
        }
        var KalturaUserRoleService = {
            add: function (userRole) {
                var kparams = new Object();
                kparams.userRole = userRole;
                return new KalturaRequestBuilder("userrole", "add", kparams);
            },
            cloneAction: function (userRoleId) {
                var kparams = new Object();
                kparams.userRoleId = userRoleId;
                return new KalturaRequestBuilder("userrole", "clone", kparams);
            },
            deleteAction: function (userRoleId) {
                var kparams = new Object();
                kparams.userRoleId = userRoleId;
                return new KalturaRequestBuilder("userrole", "delete", kparams);
            },
            get: function (userRoleId) {
                var kparams = new Object();
                kparams.userRoleId = userRoleId;
                return new KalturaRequestBuilder("userrole", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("userrole", "list", kparams);
            },
            update: function (userRoleId, userRole) {
                var kparams = new Object();
                kparams.userRoleId = userRoleId;
                kparams.userRole = userRole;
                return new KalturaRequestBuilder("userrole", "update", kparams);
            }
        }
        var KalturaUserService = {
            add: function (user) {
                var kparams = new Object();
                kparams.user = user;
                return new KalturaRequestBuilder("user", "add", kparams);
            },
            checkLoginDataExists: function (filter) {
                var kparams = new Object();
                kparams.filter = filter;
                return new KalturaRequestBuilder("user", "checkLoginDataExists", kparams);
            },
            deleteAction: function (userId) {
                var kparams = new Object();
                kparams.userId = userId;
                return new KalturaRequestBuilder("user", "delete", kparams);
            },
            disableLogin: function (userId, loginId) {
                if (!userId)
                    userId = null;
                if (!loginId)
                    loginId = null;
                var kparams = new Object();
                kparams.userId = userId;
                kparams.loginId = loginId;
                return new KalturaRequestBuilder("user", "disableLogin", kparams);
            },
            enableLogin: function (userId, loginId, password) {
                if (!password)
                    password = null;
                var kparams = new Object();
                kparams.userId = userId;
                kparams.loginId = loginId;
                kparams.password = password;
                return new KalturaRequestBuilder("user", "enableLogin", kparams);
            },
            get: function (userId) {
                if (!userId)
                    userId = null;
                var kparams = new Object();
                kparams.userId = userId;
                return new KalturaRequestBuilder("user", "get", kparams);
            },
            getByLoginId: function (loginId) {
                var kparams = new Object();
                kparams.loginId = loginId;
                return new KalturaRequestBuilder("user", "getByLoginId", kparams);
            },
            index: function (id, shouldUpdate) {
                if (!shouldUpdate)
                    shouldUpdate = true;
                var kparams = new Object();
                kparams.id = id;
                kparams.shouldUpdate = shouldUpdate;
                return new KalturaRequestBuilder("user", "index", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("user", "list", kparams);
            },
            login: function (partnerId, userId, password, expiry, privileges) {
                if (!expiry)
                    expiry = 86400;
                if (!privileges)
                    privileges = "*";
                var kparams = new Object();
                kparams.partnerId = partnerId;
                kparams.userId = userId;
                kparams.password = password;
                kparams.expiry = expiry;
                kparams.privileges = privileges;
                return new KalturaRequestBuilder("user", "login", kparams);
            },
            loginByLoginId: function (loginId, password, partnerId, expiry, privileges, otp) {
                if (!partnerId)
                    partnerId = null;
                if (!expiry)
                    expiry = 86400;
                if (!privileges)
                    privileges = "*";
                if (!otp)
                    otp = null;
                var kparams = new Object();
                kparams.loginId = loginId;
                kparams.password = password;
                kparams.partnerId = partnerId;
                kparams.expiry = expiry;
                kparams.privileges = privileges;
                kparams.otp = otp;
                return new KalturaRequestBuilder("user", "loginByLoginId", kparams);
            },
            notifyBan: function (userId) {
                var kparams = new Object();
                kparams.userId = userId;
                return new KalturaRequestBuilder("user", "notifyBan", kparams);
            },
            resetPassword: function (email) {
                var kparams = new Object();
                kparams.email = email;
                return new KalturaRequestBuilder("user", "resetPassword", kparams);
            },
            setInitialPassword: function (hashKey, newPassword) {
                var kparams = new Object();
                kparams.hashKey = hashKey;
                kparams.newPassword = newPassword;
                return new KalturaRequestBuilder("user", "setInitialPassword", kparams);
            },
            update: function (userId, user) {
                var kparams = new Object();
                kparams.userId = userId;
                kparams.user = user;
                return new KalturaRequestBuilder("user", "update", kparams);
            },
            updateLoginData: function (oldLoginId, password, newLoginId, newPassword, newFirstName, newLastName) {
                if (!newLoginId)
                    newLoginId = "";
                if (!newPassword)
                    newPassword = "";
                if (!newFirstName)
                    newFirstName = null;
                if (!newLastName)
                    newLastName = null;
                var kparams = new Object();
                kparams.oldLoginId = oldLoginId;
                kparams.password = password;
                kparams.newLoginId = newLoginId;
                kparams.newPassword = newPassword;
                kparams.newFirstName = newFirstName;
                kparams.newLastName = newLastName;
                return new KalturaRequestBuilder("user", "updateLoginData", kparams);
            }
        }
        var KalturaWidgetService = {
            add: function (widget) {
                var kparams = new Object();
                kparams.widget = widget;
                return new KalturaRequestBuilder("widget", "add", kparams);
            },
            cloneAction: function (widget) {
                var kparams = new Object();
                kparams.widget = widget;
                return new KalturaRequestBuilder("widget", "clone", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("widget", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("widget", "list", kparams);
            },
            update: function (id, widget) {
                var kparams = new Object();
                kparams.id = id;
                kparams.widget = widget;
                return new KalturaRequestBuilder("widget", "update", kparams);
            }
        }
        var KalturaMetadataService = {
            add: function (metadataProfileId, objectType, objectId, xmlData) {
                var kparams = new Object();
                kparams.metadataProfileId = metadataProfileId;
                kparams.objectType = objectType;
                kparams.objectId = objectId;
                kparams.xmlData = xmlData;
                return new KalturaRequestBuilder("metadata_metadata", "add", kparams);
            },
            addFromBulk: function (metadataProfileId, objectType, objectId, url) {
                var kparams = new Object();
                kparams.metadataProfileId = metadataProfileId;
                kparams.objectType = objectType;
                kparams.objectId = objectId;
                kparams.url = url;
                return new KalturaRequestBuilder("metadata_metadata", "addFromBulk", kparams);
            },
            addFromUrl: function (metadataProfileId, objectType, objectId, url) {
                var kparams = new Object();
                kparams.metadataProfileId = metadataProfileId;
                kparams.objectType = objectType;
                kparams.objectId = objectId;
                kparams.url = url;
                return new KalturaRequestBuilder("metadata_metadata", "addFromUrl", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("metadata_metadata", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("metadata_metadata", "get", kparams);
            },
            index: function (id, shouldUpdate) {
                var kparams = new Object();
                kparams.id = id;
                kparams.shouldUpdate = shouldUpdate;
                return new KalturaRequestBuilder("metadata_metadata", "index", kparams);
            },
            invalidate: function (id, version) {
                if (!version)
                    version = null;
                var kparams = new Object();
                kparams.id = id;
                kparams.version = version;
                return new KalturaRequestBuilder("metadata_metadata", "invalidate", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("metadata_metadata", "list", kparams);
            },
            update: function (id, xmlData, version) {
                if (!xmlData)
                    xmlData = null;
                if (!version)
                    version = null;
                var kparams = new Object();
                kparams.id = id;
                kparams.xmlData = xmlData;
                kparams.version = version;
                return new KalturaRequestBuilder("metadata_metadata", "update", kparams);
            }
        }
        var KalturaMetadataProfileService = {
            add: function (metadataProfile, xsdData, viewsData) {
                if (!viewsData)
                    viewsData = null;
                var kparams = new Object();
                kparams.metadataProfile = metadataProfile;
                kparams.xsdData = xsdData;
                kparams.viewsData = viewsData;
                return new KalturaRequestBuilder("metadata_metadataprofile", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("metadata_metadataprofile", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("metadata_metadataprofile", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("metadata_metadataprofile", "list", kparams);
            },
            listFields: function (metadataProfileId) {
                var kparams = new Object();
                kparams.metadataProfileId = metadataProfileId;
                return new KalturaRequestBuilder("metadata_metadataprofile", "listFields", kparams);
            },
            revert: function (id, toVersion) {
                var kparams = new Object();
                kparams.id = id;
                kparams.toVersion = toVersion;
                return new KalturaRequestBuilder("metadata_metadataprofile", "revert", kparams);
            },
            update: function (id, metadataProfile, xsdData, viewsData) {
                if (!xsdData)
                    xsdData = null;
                if (!viewsData)
                    viewsData = null;
                var kparams = new Object();
                kparams.id = id;
                kparams.metadataProfile = metadataProfile;
                kparams.xsdData = xsdData;
                kparams.viewsData = viewsData;
                return new KalturaRequestBuilder("metadata_metadataprofile", "update", kparams);
            }
        }
        var KalturaDocumentsService = {
            addFromEntry: function (sourceEntryId, documentEntry, sourceFlavorParamsId) {
                if (!documentEntry)
                    documentEntry = null;
                if (!sourceFlavorParamsId)
                    sourceFlavorParamsId = null;
                var kparams = new Object();
                kparams.sourceEntryId = sourceEntryId;
                if (documentEntry != null)
                    kparams.documentEntry = documentEntry;
                kparams.sourceFlavorParamsId = sourceFlavorParamsId;
                return new KalturaRequestBuilder("document_documents", "addFromEntry", kparams);
            },
            addFromFlavorAsset: function (sourceFlavorAssetId, documentEntry) {
                if (!documentEntry)
                    documentEntry = null;
                var kparams = new Object();
                kparams.sourceFlavorAssetId = sourceFlavorAssetId;
                if (documentEntry != null)
                    kparams.documentEntry = documentEntry;
                return new KalturaRequestBuilder("document_documents", "addFromFlavorAsset", kparams);
            },
            addFromUploadedFile: function (documentEntry, uploadTokenId) {
                var kparams = new Object();
                kparams.documentEntry = documentEntry;
                kparams.uploadTokenId = uploadTokenId;
                return new KalturaRequestBuilder("document_documents", "addFromUploadedFile", kparams);
            },
            approveReplace: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("document_documents", "approveReplace", kparams);
            },
            cancelReplace: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("document_documents", "cancelReplace", kparams);
            },
            convert: function (entryId, conversionProfileId, dynamicConversionAttributes) {
                if (!conversionProfileId)
                    conversionProfileId = null;
                if (!dynamicConversionAttributes)
                    dynamicConversionAttributes = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.conversionProfileId = conversionProfileId;
                kparams.dynamicConversionAttributes = dynamicConversionAttributes;
                return new KalturaRequestBuilder("document_documents", "convert", kparams);
            },
            convertPptToSwf: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("document_documents", "convertPptToSwf", kparams);
            },
            deleteAction: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("document_documents", "delete", kparams);
            },
            get: function (entryId, version) {
                if (!version)
                    version = -1;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.version = version;
                return new KalturaRequestBuilder("document_documents", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("document_documents", "list", kparams);
            },
            update: function (entryId, documentEntry) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.documentEntry = documentEntry;
                return new KalturaRequestBuilder("document_documents", "update", kparams);
            },
            updateContent: function (entryId, resource, conversionProfileId) {
                if (!conversionProfileId)
                    conversionProfileId = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.resource = resource;
                kparams.conversionProfileId = conversionProfileId;
                return new KalturaRequestBuilder("document_documents", "updateContent", kparams);
            }
        }
        var KalturaAnnotationService = {
            add: function (annotation) {
                var kparams = new Object();
                kparams.annotation = annotation;
                return new KalturaRequestBuilder("annotation_annotation", "add", kparams);
            },
            cloneAction: function (id, entryId) {
                var kparams = new Object();
                kparams.id = id;
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("annotation_annotation", "clone", kparams);
            },
            count: function (filter) {
                if (!filter)
                    filter = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                return new KalturaRequestBuilder("annotation_annotation", "count", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("annotation_annotation", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("annotation_annotation", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("annotation_annotation", "list", kparams);
            },
            update: function (id, annotation) {
                var kparams = new Object();
                kparams.id = id;
                kparams.annotation = annotation;
                return new KalturaRequestBuilder("annotation_annotation", "update", kparams);
            },
            updateStatus: function (id, status) {
                var kparams = new Object();
                kparams.id = id;
                kparams.status = status;
                return new KalturaRequestBuilder("annotation_annotation", "updateStatus", kparams);
            }
        }
        var KalturaAsperaService = {
            getFaspUrl: function (flavorAssetId) {
                var kparams = new Object();
                kparams.flavorAssetId = flavorAssetId;
                return new KalturaRequestBuilder("aspera_aspera", "getFaspUrl", kparams);
            }
        }
        var KalturaAttUverseService = {}
        var KalturaAttachmentAssetService = {
            add: function (entryId, attachmentAsset) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.attachmentAsset = attachmentAsset;
                return new KalturaRequestBuilder("attachment_attachmentasset", "add", kparams);
            },
            deleteAction: function (attachmentAssetId) {
                var kparams = new Object();
                kparams.attachmentAssetId = attachmentAssetId;
                return new KalturaRequestBuilder("attachment_attachmentasset", "delete", kparams);
            },
            get: function (attachmentAssetId) {
                var kparams = new Object();
                kparams.attachmentAssetId = attachmentAssetId;
                return new KalturaRequestBuilder("attachment_attachmentasset", "get", kparams);
            },
            getRemotePaths: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("attachment_attachmentasset", "getRemotePaths", kparams);
            },
            getUrl: function (id, storageId) {
                if (!storageId)
                    storageId = null;
                var kparams = new Object();
                kparams.id = id;
                kparams.storageId = storageId;
                return new KalturaRequestBuilder("attachment_attachmentasset", "getUrl", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("attachment_attachmentasset", "list", kparams);
            },
            setContent: function (id, contentResource) {
                var kparams = new Object();
                kparams.id = id;
                kparams.contentResource = contentResource;
                return new KalturaRequestBuilder("attachment_attachmentasset", "setContent", kparams);
            },
            update: function (id, attachmentAsset) {
                var kparams = new Object();
                kparams.id = id;
                kparams.attachmentAsset = attachmentAsset;
                return new KalturaRequestBuilder("attachment_attachmentasset", "update", kparams);
            }
        }
        var KalturaAuditTrailService = {
            add: function (auditTrail) {
                var kparams = new Object();
                kparams.auditTrail = auditTrail;
                return new KalturaRequestBuilder("audit_audittrail", "add", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("audit_audittrail", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("audit_audittrail", "list", kparams);
            }
        }
        var KalturaBulkService = {
            abort: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("bulkupload_bulk", "abort", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("bulkupload_bulk", "get", kparams);
            },
            listAction: function (bulkUploadFilter, pager) {
                if (!bulkUploadFilter)
                    bulkUploadFilter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (bulkUploadFilter != null)
                    kparams.bulkUploadFilter = bulkUploadFilter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("bulkupload_bulk", "list", kparams);
            }
        }
        var KalturaCaptionAssetService = {
            add: function (entryId, captionAsset) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.captionAsset = captionAsset;
                return new KalturaRequestBuilder("caption_captionasset", "add", kparams);
            },
            deleteAction: function (captionAssetId) {
                var kparams = new Object();
                kparams.captionAssetId = captionAssetId;
                return new KalturaRequestBuilder("caption_captionasset", "delete", kparams);
            },
            get: function (captionAssetId) {
                var kparams = new Object();
                kparams.captionAssetId = captionAssetId;
                return new KalturaRequestBuilder("caption_captionasset", "get", kparams);
            },
            getRemotePaths: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("caption_captionasset", "getRemotePaths", kparams);
            },
            getUrl: function (id, storageId) {
                if (!storageId)
                    storageId = null;
                var kparams = new Object();
                kparams.id = id;
                kparams.storageId = storageId;
                return new KalturaRequestBuilder("caption_captionasset", "getUrl", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("caption_captionasset", "list", kparams);
            },
            setAsDefault: function (captionAssetId) {
                var kparams = new Object();
                kparams.captionAssetId = captionAssetId;
                return new KalturaRequestBuilder("caption_captionasset", "setAsDefault", kparams);
            },
            setContent: function (id, contentResource) {
                var kparams = new Object();
                kparams.id = id;
                kparams.contentResource = contentResource;
                return new KalturaRequestBuilder("caption_captionasset", "setContent", kparams);
            },
            update: function (id, captionAsset) {
                var kparams = new Object();
                kparams.id = id;
                kparams.captionAsset = captionAsset;
                return new KalturaRequestBuilder("caption_captionasset", "update", kparams);
            }
        }
        var KalturaCaptionParamsService = {
            add: function (captionParams) {
                var kparams = new Object();
                kparams.captionParams = captionParams;
                return new KalturaRequestBuilder("caption_captionparams", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("caption_captionparams", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("caption_captionparams", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("caption_captionparams", "list", kparams);
            },
            update: function (id, captionParams) {
                var kparams = new Object();
                kparams.id = id;
                kparams.captionParams = captionParams;
                return new KalturaRequestBuilder("caption_captionparams", "update", kparams);
            }
        }
        var KalturaCaptionAssetItemService = {
            parse: function (captionAssetId) {
                var kparams = new Object();
                kparams.captionAssetId = captionAssetId;
                return new KalturaRequestBuilder("captionsearch_captionassetitem", "parse", kparams);
            },
            search: function (entryFilter, captionAssetItemFilter, captionAssetItemPager) {
                if (!entryFilter)
                    entryFilter = null;
                if (!captionAssetItemFilter)
                    captionAssetItemFilter = null;
                if (!captionAssetItemPager)
                    captionAssetItemPager = null;
                var kparams = new Object();
                if (entryFilter != null)
                    kparams.entryFilter = entryFilter;
                if (captionAssetItemFilter != null)
                    kparams.captionAssetItemFilter = captionAssetItemFilter;
                if (captionAssetItemPager != null)
                    kparams.captionAssetItemPager = captionAssetItemPager;
                return new KalturaRequestBuilder("captionsearch_captionassetitem", "search", kparams);
            },
            searchEntries: function (entryFilter, captionAssetItemFilter, captionAssetItemPager) {
                if (!entryFilter)
                    entryFilter = null;
                if (!captionAssetItemFilter)
                    captionAssetItemFilter = null;
                if (!captionAssetItemPager)
                    captionAssetItemPager = null;
                var kparams = new Object();
                if (entryFilter != null)
                    kparams.entryFilter = entryFilter;
                if (captionAssetItemFilter != null)
                    kparams.captionAssetItemFilter = captionAssetItemFilter;
                if (captionAssetItemPager != null)
                    kparams.captionAssetItemPager = captionAssetItemPager;
                return new KalturaRequestBuilder("captionsearch_captionassetitem", "searchEntries", kparams);
            }
        }
        var KalturaDistributionProfileService = {
            add: function (distributionProfile) {
                var kparams = new Object();
                kparams.distributionProfile = distributionProfile;
                return new KalturaRequestBuilder("contentdistribution_distributionprofile", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_distributionprofile", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_distributionprofile", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("contentdistribution_distributionprofile", "list", kparams);
            },
            listByPartner: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("contentdistribution_distributionprofile", "listByPartner", kparams);
            },
            update: function (id, distributionProfile) {
                var kparams = new Object();
                kparams.id = id;
                kparams.distributionProfile = distributionProfile;
                return new KalturaRequestBuilder("contentdistribution_distributionprofile", "update", kparams);
            },
            updateStatus: function (id, status) {
                var kparams = new Object();
                kparams.id = id;
                kparams.status = status;
                return new KalturaRequestBuilder("contentdistribution_distributionprofile", "updateStatus", kparams);
            }
        }
        var KalturaEntryDistributionService = {
            add: function (entryDistribution) {
                var kparams = new Object();
                kparams.entryDistribution = entryDistribution;
                return new KalturaRequestBuilder("contentdistribution_entrydistribution", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_entrydistribution", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_entrydistribution", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("contentdistribution_entrydistribution", "list", kparams);
            },
            retrySubmit: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_entrydistribution", "retrySubmit", kparams);
            },
            submitAdd: function (id, submitWhenReady) {
                if (!submitWhenReady)
                    submitWhenReady = false;
                var kparams = new Object();
                kparams.id = id;
                kparams.submitWhenReady = submitWhenReady;
                return new KalturaRequestBuilder("contentdistribution_entrydistribution", "submitAdd", kparams);
            },
            submitDelete: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_entrydistribution", "submitDelete", kparams);
            },
            submitFetchReport: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_entrydistribution", "submitFetchReport", kparams);
            },
            submitUpdate: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_entrydistribution", "submitUpdate", kparams);
            },
            update: function (id, entryDistribution) {
                var kparams = new Object();
                kparams.id = id;
                kparams.entryDistribution = entryDistribution;
                return new KalturaRequestBuilder("contentdistribution_entrydistribution", "update", kparams);
            },
            validate: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_entrydistribution", "validate", kparams);
            }
        }
        var KalturaDistributionProviderService = {
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("contentdistribution_distributionprovider", "list", kparams);
            }
        }
        var KalturaGenericDistributionProviderService = {
            add: function (genericDistributionProvider) {
                var kparams = new Object();
                kparams.genericDistributionProvider = genericDistributionProvider;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovider", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovider", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovider", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovider", "list", kparams);
            },
            update: function (id, genericDistributionProvider) {
                var kparams = new Object();
                kparams.id = id;
                kparams.genericDistributionProvider = genericDistributionProvider;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovider", "update", kparams);
            }
        }
        var KalturaGenericDistributionProviderActionService = {
            add: function (genericDistributionProviderAction) {
                var kparams = new Object();
                kparams.genericDistributionProviderAction = genericDistributionProviderAction;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovideraction", "add", kparams);
            },
            addMrssTransform: function (id, xslData) {
                var kparams = new Object();
                kparams.id = id;
                kparams.xslData = xslData;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovideraction", "addMrssTransform", kparams);
            },
            addMrssValidate: function (id, xsdData) {
                var kparams = new Object();
                kparams.id = id;
                kparams.xsdData = xsdData;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovideraction", "addMrssValidate", kparams);
            },
            addResultsTransform: function (id, transformData) {
                var kparams = new Object();
                kparams.id = id;
                kparams.transformData = transformData;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovideraction", "addResultsTransform", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovideraction", "delete", kparams);
            },
            deleteByProviderId: function (genericDistributionProviderId, actionType) {
                var kparams = new Object();
                kparams.genericDistributionProviderId = genericDistributionProviderId;
                kparams.actionType = actionType;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovideraction", "deleteByProviderId", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovideraction", "get", kparams);
            },
            getByProviderId: function (genericDistributionProviderId, actionType) {
                var kparams = new Object();
                kparams.genericDistributionProviderId = genericDistributionProviderId;
                kparams.actionType = actionType;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovideraction", "getByProviderId", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovideraction", "list", kparams);
            },
            update: function (id, genericDistributionProviderAction) {
                var kparams = new Object();
                kparams.id = id;
                kparams.genericDistributionProviderAction = genericDistributionProviderAction;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovideraction", "update", kparams);
            },
            updateByProviderId: function (genericDistributionProviderId, actionType, genericDistributionProviderAction) {
                var kparams = new Object();
                kparams.genericDistributionProviderId = genericDistributionProviderId;
                kparams.actionType = actionType;
                kparams.genericDistributionProviderAction = genericDistributionProviderAction;
                return new KalturaRequestBuilder("contentdistribution_genericdistributionprovideraction", "updateByProviderId", kparams);
            }
        }
        var KalturaCuePointService = {
            add: function (cuePoint) {
                var kparams = new Object();
                kparams.cuePoint = cuePoint;
                return new KalturaRequestBuilder("cuepoint_cuepoint", "add", kparams);
            },
            cloneAction: function (id, entryId) {
                var kparams = new Object();
                kparams.id = id;
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("cuepoint_cuepoint", "clone", kparams);
            },
            count: function (filter) {
                if (!filter)
                    filter = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                return new KalturaRequestBuilder("cuepoint_cuepoint", "count", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("cuepoint_cuepoint", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("cuepoint_cuepoint", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("cuepoint_cuepoint", "list", kparams);
            },
            update: function (id, cuePoint) {
                var kparams = new Object();
                kparams.id = id;
                kparams.cuePoint = cuePoint;
                return new KalturaRequestBuilder("cuepoint_cuepoint", "update", kparams);
            },
            updateStatus: function (id, status) {
                var kparams = new Object();
                kparams.id = id;
                kparams.status = status;
                return new KalturaRequestBuilder("cuepoint_cuepoint", "updateStatus", kparams);
            }
        }
        var KalturaDropFolderService = {
            add: function (dropFolder) {
                var kparams = new Object();
                kparams.dropFolder = dropFolder;
                return new KalturaRequestBuilder("dropfolder_dropfolder", "add", kparams);
            },
            deleteAction: function (dropFolderId) {
                var kparams = new Object();
                kparams.dropFolderId = dropFolderId;
                return new KalturaRequestBuilder("dropfolder_dropfolder", "delete", kparams);
            },
            freeExclusiveDropFolder: function (dropFolderId, status, errorCode, errorDescription) {
                if (!errorCode)
                    errorCode = null;
                if (!errorDescription)
                    errorDescription = null;
                var kparams = new Object();
                kparams.dropFolderId = dropFolderId;
                kparams.status = status;
                kparams.errorCode = errorCode;
                kparams.errorDescription = errorDescription;
                return new KalturaRequestBuilder("dropfolder_dropfolder", "freeExclusiveDropFolder", kparams);
            },
            get: function (dropFolderId) {
                var kparams = new Object();
                kparams.dropFolderId = dropFolderId;
                return new KalturaRequestBuilder("dropfolder_dropfolder", "get", kparams);
            },
            getExclusiveDropFolder: function (tag, maxTime) {
                var kparams = new Object();
                kparams.tag = tag;
                kparams.maxTime = maxTime;
                return new KalturaRequestBuilder("dropfolder_dropfolder", "getExclusiveDropFolder", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("dropfolder_dropfolder", "list", kparams);
            },
            update: function (dropFolderId, dropFolder) {
                var kparams = new Object();
                kparams.dropFolderId = dropFolderId;
                kparams.dropFolder = dropFolder;
                return new KalturaRequestBuilder("dropfolder_dropfolder", "update", kparams);
            }
        }
        var KalturaDropFolderFileService = {
            add: function (dropFolderFile) {
                var kparams = new Object();
                kparams.dropFolderFile = dropFolderFile;
                return new KalturaRequestBuilder("dropfolder_dropfolderfile", "add", kparams);
            },
            deleteAction: function (dropFolderFileId) {
                var kparams = new Object();
                kparams.dropFolderFileId = dropFolderFileId;
                return new KalturaRequestBuilder("dropfolder_dropfolderfile", "delete", kparams);
            },
            get: function (dropFolderFileId) {
                var kparams = new Object();
                kparams.dropFolderFileId = dropFolderFileId;
                return new KalturaRequestBuilder("dropfolder_dropfolderfile", "get", kparams);
            },
            ignore: function (dropFolderFileId) {
                var kparams = new Object();
                kparams.dropFolderFileId = dropFolderFileId;
                return new KalturaRequestBuilder("dropfolder_dropfolderfile", "ignore", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("dropfolder_dropfolderfile", "list", kparams);
            },
            update: function (dropFolderFileId, dropFolderFile) {
                var kparams = new Object();
                kparams.dropFolderFileId = dropFolderFileId;
                kparams.dropFolderFile = dropFolderFile;
                return new KalturaRequestBuilder("dropfolder_dropfolderfile", "update", kparams);
            },
            updateStatus: function (dropFolderFileId, status) {
                var kparams = new Object();
                kparams.dropFolderFileId = dropFolderFileId;
                kparams.status = status;
                return new KalturaRequestBuilder("dropfolder_dropfolderfile", "updateStatus", kparams);
            }
        }
        var KalturaEventNotificationTemplateService = {
            add: function (eventNotificationTemplate) {
                var kparams = new Object();
                kparams.eventNotificationTemplate = eventNotificationTemplate;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "add", kparams);
            },
            cloneAction: function (id, eventNotificationTemplate) {
                if (!eventNotificationTemplate)
                    eventNotificationTemplate = null;
                var kparams = new Object();
                kparams.id = id;
                if (eventNotificationTemplate != null)
                    kparams.eventNotificationTemplate = eventNotificationTemplate;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "clone", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "delete", kparams);
            },
            dispatch: function (id, scope) {
                var kparams = new Object();
                kparams.id = id;
                kparams.scope = scope;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "dispatch", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "list", kparams);
            },
            listByPartner: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "listByPartner", kparams);
            },
            listTemplates: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "listTemplates", kparams);
            },
            register: function (notificationTemplateSystemName, pushNotificationParams) {
                var kparams = new Object();
                kparams.notificationTemplateSystemName = notificationTemplateSystemName;
                kparams.pushNotificationParams = pushNotificationParams;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "register", kparams);
            },
            sendCommand: function (notificationTemplateSystemName, pushNotificationParams, command) {
                var kparams = new Object();
                kparams.notificationTemplateSystemName = notificationTemplateSystemName;
                kparams.pushNotificationParams = pushNotificationParams;
                kparams.command = command;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "sendCommand", kparams);
            },
            update: function (id, eventNotificationTemplate) {
                var kparams = new Object();
                kparams.id = id;
                kparams.eventNotificationTemplate = eventNotificationTemplate;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "update", kparams);
            },
            updateStatus: function (id, status) {
                var kparams = new Object();
                kparams.id = id;
                kparams.status = status;
                return new KalturaRequestBuilder("eventnotification_eventnotificationtemplate", "updateStatus", kparams);
            }
        }
        var KalturaSharepointExtensionService = {
            isVersionSupported: function (serverMajor, serverMinor, serverBuild) {
                var kparams = new Object();
                kparams.serverMajor = serverMajor;
                kparams.serverMinor = serverMinor;
                kparams.serverBuild = serverBuild;
                return new KalturaRequestBuilder("kalturasharepointextension_sharepointextension", "isVersionSupported", kparams);
            },
            listUiconfs: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("kalturasharepointextension_sharepointextension", "listUiconfs", kparams);
            }
        }
        var KalturaLikeService = {
            checkLikeExists: function (entryId, userId) {
                if (!userId)
                    userId = null;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.userId = userId;
                return new KalturaRequestBuilder("like_like", "checkLikeExists", kparams);
            },
            like: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("like_like", "like", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("like_like", "list", kparams);
            },
            unlike: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("like_like", "unlike", kparams);
            }
        }
        var KalturaNdnService = {}
        var KalturaShortLinkService = {
            add: function (shortLink) {
                var kparams = new Object();
                kparams.shortLink = shortLink;
                return new KalturaRequestBuilder("shortlink_shortlink", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("shortlink_shortlink", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("shortlink_shortlink", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("shortlink_shortlink", "list", kparams);
            },
            update: function (id, shortLink) {
                var kparams = new Object();
                kparams.id = id;
                kparams.shortLink = shortLink;
                return new KalturaRequestBuilder("shortlink_shortlink", "update", kparams);
            }
        }
        var KalturaSynacorHboService = {}
        var KalturaTagService = {
            deletePending: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("tagsearch_tag", "deletePending", kparams);
            },
            indexCategoryEntryTags: function (categoryId, pcToDecrement, pcToIncrement) {
                var kparams = new Object();
                kparams.categoryId = categoryId;
                kparams.pcToDecrement = pcToDecrement;
                kparams.pcToIncrement = pcToIncrement;
                return new KalturaRequestBuilder("tagsearch_tag", "indexCategoryEntryTags", kparams);
            },
            search: function (tagFilter, pager) {
                if (!pager)
                    pager = null;
                var kparams = new Object();
                kparams.tagFilter = tagFilter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("tagsearch_tag", "search", kparams);
            }
        }
        var KalturaTimeWarnerService = {}
        var KalturaUverseClickToOrderService = {}
        var KalturaUverseService = {}
        var KalturaVarConsoleService = {
            getPartnerUsage: function (partnerFilter, usageFilter, pager) {
                if (!partnerFilter)
                    partnerFilter = null;
                if (!usageFilter)
                    usageFilter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (partnerFilter != null)
                    kparams.partnerFilter = partnerFilter;
                if (usageFilter != null)
                    kparams.usageFilter = usageFilter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("varconsole_varconsole", "getPartnerUsage", kparams);
            },
            updateStatus: function (id, status) {
                var kparams = new Object();
                kparams.id = id;
                kparams.status = status;
                return new KalturaRequestBuilder("varconsole_varconsole", "updateStatus", kparams);
            }
        }
        var KalturaVirusScanProfileService = {
            add: function (virusScanProfile) {
                var kparams = new Object();
                kparams.virusScanProfile = virusScanProfile;
                return new KalturaRequestBuilder("virusscan_virusscanprofile", "add", kparams);
            },
            deleteAction: function (virusScanProfileId) {
                var kparams = new Object();
                kparams.virusScanProfileId = virusScanProfileId;
                return new KalturaRequestBuilder("virusscan_virusscanprofile", "delete", kparams);
            },
            get: function (virusScanProfileId) {
                var kparams = new Object();
                kparams.virusScanProfileId = virusScanProfileId;
                return new KalturaRequestBuilder("virusscan_virusscanprofile", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("virusscan_virusscanprofile", "list", kparams);
            },
            scan: function (flavorAssetId, virusScanProfileId) {
                if (!virusScanProfileId)
                    virusScanProfileId = null;
                var kparams = new Object();
                kparams.flavorAssetId = flavorAssetId;
                kparams.virusScanProfileId = virusScanProfileId;
                return new KalturaRequestBuilder("virusscan_virusscanprofile", "scan", kparams);
            },
            update: function (virusScanProfileId, virusScanProfile) {
                var kparams = new Object();
                kparams.virusScanProfileId = virusScanProfileId;
                kparams.virusScanProfile = virusScanProfile;
                return new KalturaRequestBuilder("virusscan_virusscanprofile", "update", kparams);
            }
        }
        var KalturaExternalMediaService = {
            add: function (entry) {
                var kparams = new Object();
                kparams.entry = entry;
                return new KalturaRequestBuilder("externalmedia_externalmedia", "add", kparams);
            },
            count: function (filter) {
                if (!filter)
                    filter = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                return new KalturaRequestBuilder("externalmedia_externalmedia", "count", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("externalmedia_externalmedia", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("externalmedia_externalmedia", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("externalmedia_externalmedia", "list", kparams);
            },
            update: function (id, entry) {
                var kparams = new Object();
                kparams.id = id;
                kparams.entry = entry;
                return new KalturaRequestBuilder("externalmedia_externalmedia", "update", kparams);
            }
        }
        var KalturaDrmPolicyService = {
            add: function (drmPolicy) {
                var kparams = new Object();
                kparams.drmPolicy = drmPolicy;
                return new KalturaRequestBuilder("drm_drmpolicy", "add", kparams);
            },
            deleteAction: function (drmPolicyId) {
                var kparams = new Object();
                kparams.drmPolicyId = drmPolicyId;
                return new KalturaRequestBuilder("drm_drmpolicy", "delete", kparams);
            },
            get: function (drmPolicyId) {
                var kparams = new Object();
                kparams.drmPolicyId = drmPolicyId;
                return new KalturaRequestBuilder("drm_drmpolicy", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("drm_drmpolicy", "list", kparams);
            },
            update: function (drmPolicyId, drmPolicy) {
                var kparams = new Object();
                kparams.drmPolicyId = drmPolicyId;
                kparams.drmPolicy = drmPolicy;
                return new KalturaRequestBuilder("drm_drmpolicy", "update", kparams);
            }
        }
        var KalturaDrmProfileService = {
            add: function (drmProfile) {
                var kparams = new Object();
                kparams.drmProfile = drmProfile;
                return new KalturaRequestBuilder("drm_drmprofile", "add", kparams);
            },
            deleteAction: function (drmProfileId) {
                var kparams = new Object();
                kparams.drmProfileId = drmProfileId;
                return new KalturaRequestBuilder("drm_drmprofile", "delete", kparams);
            },
            get: function (drmProfileId) {
                var kparams = new Object();
                kparams.drmProfileId = drmProfileId;
                return new KalturaRequestBuilder("drm_drmprofile", "get", kparams);
            },
            getByProvider: function (provider) {
                var kparams = new Object();
                kparams.provider = provider;
                return new KalturaRequestBuilder("drm_drmprofile", "getByProvider", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("drm_drmprofile", "list", kparams);
            },
            update: function (drmProfileId, drmProfile) {
                var kparams = new Object();
                kparams.drmProfileId = drmProfileId;
                kparams.drmProfile = drmProfile;
                return new KalturaRequestBuilder("drm_drmprofile", "update", kparams);
            }
        }
        var KalturaDrmLicenseAccessService = {
            getAccess: function (entryId, flavorIds, referrer) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.flavorIds = flavorIds;
                kparams.referrer = referrer;
                return new KalturaRequestBuilder("drm_drmlicenseaccess", "getAccess", kparams);
            }
        }
        var KalturaWidevineDrmService = {
            getLicense: function (flavorAssetId, referrer) {
                if (!referrer)
                    referrer = null;
                var kparams = new Object();
                kparams.flavorAssetId = flavorAssetId;
                kparams.referrer = referrer;
                return new KalturaRequestBuilder("widevine_widevinedrm", "getLicense", kparams);
            }
        }
        var KalturaScheduledTaskProfileService = {
            add: function (scheduledTaskProfile) {
                var kparams = new Object();
                kparams.scheduledTaskProfile = scheduledTaskProfile;
                return new KalturaRequestBuilder("scheduledtask_scheduledtaskprofile", "add", kparams);
            },
            deleteAction: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("scheduledtask_scheduledtaskprofile", "delete", kparams);
            },
            get: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("scheduledtask_scheduledtaskprofile", "get", kparams);
            },
            getDryRunResults: function (requestId) {
                var kparams = new Object();
                kparams.requestId = requestId;
                return new KalturaRequestBuilder("scheduledtask_scheduledtaskprofile", "getDryRunResults", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("scheduledtask_scheduledtaskprofile", "list", kparams);
            },
            requestDryRun: function (scheduledTaskProfileId, maxResults) {
                if (!maxResults)
                    maxResults = 500;
                var kparams = new Object();
                kparams.scheduledTaskProfileId = scheduledTaskProfileId;
                kparams.maxResults = maxResults;
                return new KalturaRequestBuilder("scheduledtask_scheduledtaskprofile", "requestDryRun", kparams);
            },
            update: function (id, scheduledTaskProfile) {
                var kparams = new Object();
                kparams.id = id;
                kparams.scheduledTaskProfile = scheduledTaskProfile;
                return new KalturaRequestBuilder("scheduledtask_scheduledtaskprofile", "update", kparams);
            }
        }
        var KalturaPlayReadyDrmService = {
            generateKey: function () {
                var kparams = new Object();
                return new KalturaRequestBuilder("playready_playreadydrm", "generateKey", kparams);
            },
            getContentKeys: function (keyIds) {
                var kparams = new Object();
                kparams.keyIds = keyIds;
                return new KalturaRequestBuilder("playready_playreadydrm", "getContentKeys", kparams);
            },
            getEntryContentKey: function (entryId, createIfMissing) {
                if (!createIfMissing)
                    createIfMissing = false;
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.createIfMissing = createIfMissing;
                return new KalturaRequestBuilder("playready_playreadydrm", "getEntryContentKey", kparams);
            },
            getLicenseDetails: function (keyId, deviceId, deviceType, entryId, referrer) {
                if (!entryId)
                    entryId = null;
                if (!referrer)
                    referrer = null;
                var kparams = new Object();
                kparams.keyId = keyId;
                kparams.deviceId = deviceId;
                kparams.deviceType = deviceType;
                kparams.entryId = entryId;
                kparams.referrer = referrer;
                return new KalturaRequestBuilder("playready_playreadydrm", "getLicenseDetails", kparams);
            }
        }
        var KalturaUnicornService = {
            notify: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("unicorndistribution_unicorn", "notify", kparams);
            }
        }
        var KalturaIntegrationService = {
            dispatch: function (data, objectType, objectId) {
                var kparams = new Object();
                kparams.data = data;
                kparams.objectType = objectType;
                kparams.objectId = objectId;
                return new KalturaRequestBuilder("integration_integration", "dispatch", kparams);
            },
            notify: function (id) {
                var kparams = new Object();
                kparams.id = id;
                return new KalturaRequestBuilder("integration_integration", "notify", kparams);
            }
        }
        var KalturaBusinessProcessCaseService = {
            abort: function (objectType, objectId, businessProcessStartNotificationTemplateId) {
                var kparams = new Object();
                kparams.objectType = objectType;
                kparams.objectId = objectId;
                kparams.businessProcessStartNotificationTemplateId = businessProcessStartNotificationTemplateId;
                return new KalturaRequestBuilder("businessprocessnotification_businessprocesscase", "abort", kparams);
            },
            listAction: function (objectType, objectId) {
                var kparams = new Object();
                kparams.objectType = objectType;
                kparams.objectId = objectId;
                return new KalturaRequestBuilder("businessprocessnotification_businessprocesscase", "list", kparams);
            }
        }
        var KalturaQuizService = {
            add: function (entryId, quiz) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.quiz = quiz;
                return new KalturaRequestBuilder("quiz_quiz", "add", kparams);
            },
            get: function (entryId) {
                var kparams = new Object();
                kparams.entryId = entryId;
                return new KalturaRequestBuilder("quiz_quiz", "get", kparams);
            },
            getUrl: function (entryId, quizOutputType) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.quizOutputType = quizOutputType;
                return new KalturaRequestBuilder("quiz_quiz", "getUrl", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("quiz_quiz", "list", kparams);
            },
            update: function (entryId, quiz) {
                var kparams = new Object();
                kparams.entryId = entryId;
                kparams.quiz = quiz;
                return new KalturaRequestBuilder("quiz_quiz", "update", kparams);
            }
        }
        var KalturaScheduleEventService = {
            add: function (scheduleEvent) {
                var kparams = new Object();
                kparams.scheduleEvent = scheduleEvent;
                return new KalturaRequestBuilder("schedule_scheduleevent", "add", kparams);
            },
            cancel: function (scheduleEventId) {
                var kparams = new Object();
                kparams.scheduleEventId = scheduleEventId;
                return new KalturaRequestBuilder("schedule_scheduleevent", "cancel", kparams);
            },
            deleteAction: function (scheduleEventId) {
                var kparams = new Object();
                kparams.scheduleEventId = scheduleEventId;
                return new KalturaRequestBuilder("schedule_scheduleevent", "delete", kparams);
            },
            get: function (scheduleEventId) {
                var kparams = new Object();
                kparams.scheduleEventId = scheduleEventId;
                return new KalturaRequestBuilder("schedule_scheduleevent", "get", kparams);
            },
            getConflicts: function (resourceIds, scheduleEvent) {
                var kparams = new Object();
                kparams.resourceIds = resourceIds;
                kparams.scheduleEvent = scheduleEvent;
                return new KalturaRequestBuilder("schedule_scheduleevent", "getConflicts", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("schedule_scheduleevent", "list", kparams);
            },
            update: function (scheduleEventId, scheduleEvent) {
                var kparams = new Object();
                kparams.scheduleEventId = scheduleEventId;
                kparams.scheduleEvent = scheduleEvent;
                return new KalturaRequestBuilder("schedule_scheduleevent", "update", kparams);
            }
        }
        var KalturaScheduleResourceService = {
            add: function (scheduleResource) {
                var kparams = new Object();
                kparams.scheduleResource = scheduleResource;
                return new KalturaRequestBuilder("schedule_scheduleresource", "add", kparams);
            },
            deleteAction: function (scheduleResourceId) {
                var kparams = new Object();
                kparams.scheduleResourceId = scheduleResourceId;
                return new KalturaRequestBuilder("schedule_scheduleresource", "delete", kparams);
            },
            get: function (scheduleResourceId) {
                var kparams = new Object();
                kparams.scheduleResourceId = scheduleResourceId;
                return new KalturaRequestBuilder("schedule_scheduleresource", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("schedule_scheduleresource", "list", kparams);
            },
            update: function (scheduleResourceId, scheduleResource) {
                var kparams = new Object();
                kparams.scheduleResourceId = scheduleResourceId;
                kparams.scheduleResource = scheduleResource;
                return new KalturaRequestBuilder("schedule_scheduleresource", "update", kparams);
            }
        }
        var KalturaScheduleEventResourceService = {
            add: function (scheduleEventResource) {
                var kparams = new Object();
                kparams.scheduleEventResource = scheduleEventResource;
                return new KalturaRequestBuilder("schedule_scheduleeventresource", "add", kparams);
            },
            deleteAction: function (scheduleEventId, scheduleResourceId) {
                var kparams = new Object();
                kparams.scheduleEventId = scheduleEventId;
                kparams.scheduleResourceId = scheduleResourceId;
                return new KalturaRequestBuilder("schedule_scheduleeventresource", "delete", kparams);
            },
            get: function (scheduleEventId, scheduleResourceId) {
                var kparams = new Object();
                kparams.scheduleEventId = scheduleEventId;
                kparams.scheduleResourceId = scheduleResourceId;
                return new KalturaRequestBuilder("schedule_scheduleeventresource", "get", kparams);
            },
            listAction: function (filter, pager) {
                if (!filter)
                    filter = null;
                if (!pager)
                    pager = null;
                var kparams = new Object();
                if (filter != null)
                    kparams.filter = filter;
                if (pager != null)
                    kparams.pager = pager;
                return new KalturaRequestBuilder("schedule_scheduleeventresource", "list", kparams);
            },
            update: function (scheduleEventId, scheduleResourceId, scheduleEventResource) {
                var kparams = new Object();
                kparams.scheduleEventId = scheduleEventId;
                kparams.scheduleResourceId = scheduleResourceId;
                kparams.scheduleEventResource = scheduleEventResource;
                return new KalturaRequestBuilder("schedule_scheduleeventresource", "update", kparams);
            }
        }
        Function.prototype.inheritsFrom = function (parentClassOrObject) {
            if (parentClassOrObject.constructor == Function) {
                this.prototype = new parentClassOrObject;
                this.prototype.constructor = this;
                this.prototype.parentClass = parentClassOrObject.prototype;
            }
            else {
                this.prototype = parentClassOrObject;
                this.prototype.constructor = this;
                this.prototype.parentClass = parentClassOrObject;
            }
            return this;
        }
        function ksort(arr) {
            var sArr = [];
            var tArr = [];
            var n = 0;
            for (i in arr)
                tArr[n++] = i + ' |' + arr[i];
            tArr = tArr.sort();
            for (var i = 0; i < tArr.length; i++) {
                var x = tArr[i].split(' |');
                sArr[x[0]] = x[1];
            }
            return sArr;
        }
        function IKalturaLogger() {
        }
        IKalturaLogger.prototype.log = function (msg) {
            if (console && console.log) {
                console.log(msg);
            }
        };
        function KalturaClientBase() {
        }
        KalturaClientBase.prototype.init = function (config) {
            this.config = config;
            var logger = this.config.getLogger();
            if (logger) {
                this.shouldLog = true;
            }
        };
        KalturaClientBase.prototype.KALTURA_SERVICE_FORMAT_JSON = 1;
        KalturaClientBase.prototype.KALTURA_SERVICE_FORMAT_XML = 2;
        KalturaClientBase.prototype.KALTURA_SERVICE_FORMAT_PHP = 3;
        KalturaClientBase.prototype.KALTURA_SERVICE_FORMAT_JSONP = 9;
        KalturaClientBase.prototype.config = null;
        KalturaClientBase.prototype.requestData = {};
        KalturaClientBase.prototype.shouldLog = false;
        KalturaClientBase.prototype.getConfig = function () {
            return this.config;
        };
        KalturaClientBase.prototype.setConfig = function (config) {
            this.config = config;
            logger = this.config.getLogger();
            if (logger instanceof IKalturaLogger) {
                this.shouldLog = true;
            }
        };
        KalturaClientBase.prototype.startMultiRequest = function () {
            return new KalturaMultiRequestBuilder();
        };
        KalturaClientBase.prototype.log = function (msg) {
            if (this.shouldLog)
                this.config.getLogger().log(msg);
        };
        function KalturaConfiguration() {
        }
        KalturaConfiguration.prototype.logger = null;
        KalturaConfiguration.prototype.serviceUrl = 'http://www.kaltura.com';
        KalturaConfiguration.prototype.serviceBase = '/api_v3/service';
        KalturaConfiguration.prototype.setLogger = function (log) {
            this.logger = log;
        };
        KalturaConfiguration.prototype.getLogger = function () {
            return this.logger;
        };
        function KalturaRequestBuilder(service, action, data, files) {
            if (!service)
                return;
            this.service = service;
            this.action = action;
            this.data = data;
            this.files = files;
            this.requestData = {};
        }
        KalturaRequestBuilder.prototype.callback = null;
        KalturaRequestBuilder.prototype.signature = function (params) {
            params = ksort(params);
            var str = '';
            for (var v in params) {
                var k = params[v];
                if (typeof(k) === 'object' || $.isArray(k))
                    k = this.signature(k);
                str += v + k;
            }
            return MD5(str);
        };
        KalturaRequestBuilder.prototype.doHttpRequest = function (client) {
            var json = this.getData(true);
            var callback = this.callback;
            var url = this.getUrl(client);
            client.log('URL: ' + url);
            client.log('Request JSON: ' + JSON.stringify(json));
            $.ajax({
                type: 'POST',
                url: url,
                crossDomain: true,
                data: JSON.stringify(json),
                contentType: 'application/json',
                dataType: 'json',
                success: function (json, textStatus, jqXHR) {
                    client.log('Response JSON: ' + JSON.stringify(json));
                    if (json && typeof(json) === 'object' && json.code && json.message) {
                        if (callback)
                            callback(false, json);
                        else
                            throw new Error(json.message);
                    }
                    else if (callback)
                        callback(true, json);
                },
                error: function (responseData, textStatus, errorThrown) {
                    if (callback)
                        callback(false, errorThrown);
                    else
                        throw errorThrown;
                }
            });
        };
        KalturaRequestBuilder.prototype.sign = function () {
            var signature = this.signature(this.data);
            this.data.kalsig = signature;
        };
        KalturaRequestBuilder.prototype.getUrl = function (client) {
            var url = client.config.serviceUrl + client.config.serviceBase;
            url += '/' + this.service + '/action/' + this.action;
            return url;
        };
        KalturaRequestBuilder.prototype.getData = function (sign) {
            this.data.format = KalturaClientBase.prototype.KALTURA_SERVICE_FORMAT_JSON;
            $.extend(this.data, this.requestData);
            if (sign)
                this.sign();
            return this.data;
        };
        KalturaRequestBuilder.prototype.execute = function (client, callback) {
            var requestData = $.extend({}, client.requestData); 
            this.requestData = $.extend(requestData, this.requestData); 
            if (callback)
                this.completion(callback);
            this.doHttpRequest(client);
        };
        KalturaRequestBuilder.prototype.completion = function (callback) {
            this.callback = callback;
            return this;
        };
        KalturaRequestBuilder.prototype.add = function (requestBuilder) {
            var multiRequestBuilder = new KalturaMultiRequestBuilder();
            multiRequestBuilder.add(this);
            multiRequestBuilder.add(requestBuilder);
            return multiRequestBuilder;
        };
        function KalturaMultiRequestBuilder() {
            this.requestData = {};
            this.requests = [];
            this.generalCallback = null;
            var This = this;
            This.callback = function (success, results) {
                if (!success)
                    throw new Error(results);
                for (var i = 0; i < This.requests.length; i++) {
                    if (This.requests[i].callback) {
                        if (results[i] && typeof(results[i]) == 'object' && results[i].code && results[i].message)
                            This.requests[i].callback(false, results[i]);
                        else
                            This.requests[i].callback(true, results[i]);
                    }
                }
                if (This.generalCallback) {
                    if (results && typeof(results) == 'object' && results.code && results.message)
                        This.generalCallback(false, results)
                    else
                        This.generalCallback(true, results)
                }
            };
        }
        KalturaMultiRequestBuilder.inheritsFrom(KalturaRequestBuilder);
        KalturaMultiRequestBuilder.prototype.completion = function (callback) {
            this.generalCallback = callback;
            return this;
        };
        KalturaMultiRequestBuilder.prototype.add = function (requestBuilder) {
            this.requests.push(requestBuilder);
            return this;
        };
        KalturaMultiRequestBuilder.prototype.getUrl = function (client) {
            var url = client.config.serviceUrl + client.config.serviceBase;
            url += '/multirequest';
            return url;
        };
        KalturaMultiRequestBuilder.prototype.getData = function () {
            this.data = {
                format: KalturaClientBase.prototype.KALTURA_SERVICE_FORMAT_JSON
            }
            for (var i = 0; i < this.requests.length; i++) {
                this.data[i] = this.requests[i].getData();
                this.data[i].service = this.requests[i].service;
                this.data[i].action = this.requests[i].action;
            }
            $.extend(this.data, this.requestData);
            this.sign();
            return this.data;
        };
        var MD5 = function (string) {
            function RotateLeft(lValue, iShiftBits) {
                return (lValue << iShiftBits) | (lValue >>> (32 - iShiftBits));
            }
            function AddUnsigned(lX, lY) {
                var lX4, lY4, lX8, lY8, lResult;
                lX8 = (lX & 0x80000000);
                lY8 = (lY & 0x80000000);
                lX4 = (lX & 0x40000000);
                lY4 = (lY & 0x40000000);
                lResult = (lX & 0x3FFFFFFF) + (lY & 0x3FFFFFFF);
                if (lX4 & lY4) {
                    return (lResult ^ 0x80000000 ^ lX8 ^ lY8);
                }
                if (lX4 | lY4) {
                    if (lResult & 0x40000000) {
                        return (lResult ^ 0xC0000000 ^ lX8 ^ lY8);
                    } else {
                        return (lResult ^ 0x40000000 ^ lX8 ^ lY8);
                    }
                } else {
                    return (lResult ^ lX8 ^ lY8);
                }
            }
            function F(x, y, z) {
                return (x & y) | ((~x) & z);
            }
            function G(x, y, z) {
                return (x & z) | (y & (~z));
            }
            function H(x, y, z) {
                return (x ^ y ^ z);
            }
            function I(x, y, z) {
                return (y ^ (x | (~z)));
            }
            function FF(a, b, c, d, x, s, ac) {
                a = AddUnsigned(a, AddUnsigned(AddUnsigned(F(b, c, d), x), ac));
                return AddUnsigned(RotateLeft(a, s), b);
            };
            function GG(a, b, c, d, x, s, ac) {
                a = AddUnsigned(a, AddUnsigned(AddUnsigned(G(b, c, d), x), ac));
                return AddUnsigned(RotateLeft(a, s), b);
            };
            function HH(a, b, c, d, x, s, ac) {
                a = AddUnsigned(a, AddUnsigned(AddUnsigned(H(b, c, d), x), ac));
                return AddUnsigned(RotateLeft(a, s), b);
            };
            function II(a, b, c, d, x, s, ac) {
                a = AddUnsigned(a, AddUnsigned(AddUnsigned(I(b, c, d), x), ac));
                return AddUnsigned(RotateLeft(a, s), b);
            };
            function ConvertToWordArray(string) {
                var lWordCount;
                var lMessageLength = string.length;
                var lNumberOfWords_temp1 = lMessageLength + 8;
                var lNumberOfWords_temp2 = (lNumberOfWords_temp1 - (lNumberOfWords_temp1 % 64)) / 64;
                var lNumberOfWords = (lNumberOfWords_temp2 + 1) * 16;
                var lWordArray = Array(lNumberOfWords - 1);
                var lBytePosition = 0;
                var lByteCount = 0;
                while (lByteCount < lMessageLength) {
                    lWordCount = (lByteCount - (lByteCount % 4)) / 4;
                    lBytePosition = (lByteCount % 4) * 8;
                    lWordArray[lWordCount] = (lWordArray[lWordCount] | (string.charCodeAt(lByteCount) << lBytePosition));
                    lByteCount++;
                }
                lWordCount = (lByteCount - (lByteCount % 4)) / 4;
                lBytePosition = (lByteCount % 4) * 8;
                lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80 << lBytePosition);
                lWordArray[lNumberOfWords - 2] = lMessageLength << 3;
                lWordArray[lNumberOfWords - 1] = lMessageLength >>> 29;
                return lWordArray;
            };
            function WordToHex(lValue) {
                var WordToHexValue = "", WordToHexValue_temp = "", lByte, lCount;
                for (lCount = 0; lCount <= 3; lCount++) {
                    lByte = (lValue >>> (lCount * 8)) & 255;
                    WordToHexValue_temp = "0" + lByte.toString(16);
                    WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length - 2, 2);
                }
                return WordToHexValue;
            };
            function Utf8Encode(string) {
                string = string.replace(/\r\n/g, "\n");
                var utftext = "";
                for (var n = 0; n < string.length; n++) {
                    var c = string.charCodeAt(n);
                    if (c < 128) {
                        utftext += String.fromCharCode(c);
                    }
                    else if ((c > 127) && (c < 2048)) {
                        utftext += String.fromCharCode((c >> 6) | 192);
                        utftext += String.fromCharCode((c & 63) | 128);
                    }
                    else {
                        utftext += String.fromCharCode((c >> 12) | 224);
                        utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                        utftext += String.fromCharCode((c & 63) | 128);
                    }
                }
                return utftext;
            };
            var x = Array();
            var k, AA, BB, CC, DD, a, b, c, d;
            var S11 = 7, S12 = 12, S13 = 17, S14 = 22;
            var S21 = 5, S22 = 9, S23 = 14, S24 = 20;
            var S31 = 4, S32 = 11, S33 = 16, S34 = 23;
            var S41 = 6, S42 = 10, S43 = 15, S44 = 21;
            string = Utf8Encode(string);
            x = ConvertToWordArray(string);
            a = 0x67452301;
            b = 0xEFCDAB89;
            c = 0x98BADCFE;
            d = 0x10325476;
            for (k = 0; k < x.length; k += 16) {
                AA = a;
                BB = b;
                CC = c;
                DD = d;
                a = FF(a, b, c, d, x[k + 0], S11, 0xD76AA478);
                d = FF(d, a, b, c, x[k + 1], S12, 0xE8C7B756);
                c = FF(c, d, a, b, x[k + 2], S13, 0x242070DB);
                b = FF(b, c, d, a, x[k + 3], S14, 0xC1BDCEEE);
                a = FF(a, b, c, d, x[k + 4], S11, 0xF57C0FAF);
                d = FF(d, a, b, c, x[k + 5], S12, 0x4787C62A);
                c = FF(c, d, a, b, x[k + 6], S13, 0xA8304613);
                b = FF(b, c, d, a, x[k + 7], S14, 0xFD469501);
                a = FF(a, b, c, d, x[k + 8], S11, 0x698098D8);
                d = FF(d, a, b, c, x[k + 9], S12, 0x8B44F7AF);
                c = FF(c, d, a, b, x[k + 10], S13, 0xFFFF5BB1);
                b = FF(b, c, d, a, x[k + 11], S14, 0x895CD7BE);
                a = FF(a, b, c, d, x[k + 12], S11, 0x6B901122);
                d = FF(d, a, b, c, x[k + 13], S12, 0xFD987193);
                c = FF(c, d, a, b, x[k + 14], S13, 0xA679438E);
                b = FF(b, c, d, a, x[k + 15], S14, 0x49B40821);
                a = GG(a, b, c, d, x[k + 1], S21, 0xF61E2562);
                d = GG(d, a, b, c, x[k + 6], S22, 0xC040B340);
                c = GG(c, d, a, b, x[k + 11], S23, 0x265E5A51);
                b = GG(b, c, d, a, x[k + 0], S24, 0xE9B6C7AA);
                a = GG(a, b, c, d, x[k + 5], S21, 0xD62F105D);
                d = GG(d, a, b, c, x[k + 10], S22, 0x2441453);
                c = GG(c, d, a, b, x[k + 15], S23, 0xD8A1E681);
                b = GG(b, c, d, a, x[k + 4], S24, 0xE7D3FBC8);
                a = GG(a, b, c, d, x[k + 9], S21, 0x21E1CDE6);
                d = GG(d, a, b, c, x[k + 14], S22, 0xC33707D6);
                c = GG(c, d, a, b, x[k + 3], S23, 0xF4D50D87);
                b = GG(b, c, d, a, x[k + 8], S24, 0x455A14ED);
                a = GG(a, b, c, d, x[k + 13], S21, 0xA9E3E905);
                d = GG(d, a, b, c, x[k + 2], S22, 0xFCEFA3F8);
                c = GG(c, d, a, b, x[k + 7], S23, 0x676F02D9);
                b = GG(b, c, d, a, x[k + 12], S24, 0x8D2A4C8A);
                a = HH(a, b, c, d, x[k + 5], S31, 0xFFFA3942);
                d = HH(d, a, b, c, x[k + 8], S32, 0x8771F681);
                c = HH(c, d, a, b, x[k + 11], S33, 0x6D9D6122);
                b = HH(b, c, d, a, x[k + 14], S34, 0xFDE5380C);
                a = HH(a, b, c, d, x[k + 1], S31, 0xA4BEEA44);
                d = HH(d, a, b, c, x[k + 4], S32, 0x4BDECFA9);
                c = HH(c, d, a, b, x[k + 7], S33, 0xF6BB4B60);
                b = HH(b, c, d, a, x[k + 10], S34, 0xBEBFBC70);
                a = HH(a, b, c, d, x[k + 13], S31, 0x289B7EC6);
                d = HH(d, a, b, c, x[k + 0], S32, 0xEAA127FA);
                c = HH(c, d, a, b, x[k + 3], S33, 0xD4EF3085);
                b = HH(b, c, d, a, x[k + 6], S34, 0x4881D05);
                a = HH(a, b, c, d, x[k + 9], S31, 0xD9D4D039);
                d = HH(d, a, b, c, x[k + 12], S32, 0xE6DB99E5);
                c = HH(c, d, a, b, x[k + 15], S33, 0x1FA27CF8);
                b = HH(b, c, d, a, x[k + 2], S34, 0xC4AC5665);
                a = II(a, b, c, d, x[k + 0], S41, 0xF4292244);
                d = II(d, a, b, c, x[k + 7], S42, 0x432AFF97);
                c = II(c, d, a, b, x[k + 14], S43, 0xAB9423A7);
                b = II(b, c, d, a, x[k + 5], S44, 0xFC93A039);
                a = II(a, b, c, d, x[k + 12], S41, 0x655B59C3);
                d = II(d, a, b, c, x[k + 3], S42, 0x8F0CCC92);
                c = II(c, d, a, b, x[k + 10], S43, 0xFFEFF47D);
                b = II(b, c, d, a, x[k + 1], S44, 0x85845DD1);
                a = II(a, b, c, d, x[k + 8], S41, 0x6FA87E4F);
                d = II(d, a, b, c, x[k + 15], S42, 0xFE2CE6E0);
                c = II(c, d, a, b, x[k + 6], S43, 0xA3014314);
                b = II(b, c, d, a, x[k + 13], S44, 0x4E0811A1);
                a = II(a, b, c, d, x[k + 4], S41, 0xF7537E82);
                d = II(d, a, b, c, x[k + 11], S42, 0xBD3AF235);
                c = II(c, d, a, b, x[k + 2], S43, 0x2AD7D2BB);
                b = II(b, c, d, a, x[k + 9], S44, 0xEB86D391);
                a = AddUnsigned(a, AA);
                b = AddUnsigned(b, BB);
                c = AddUnsigned(c, CC);
                d = AddUnsigned(d, DD);
            }
            var temp = WordToHex(a) + WordToHex(b) + WordToHex(c) + WordToHex(d);
            return temp.toLowerCase();
        }
        function KalturaClient(config) {
            this.init(config);
            this.setClientTag('ajax:17-03-22');
            this.setApiVersion('3.3.0');
        }
        KalturaClient.inheritsFrom(KalturaClientBase);
        KalturaClient.prototype.init = function (config) {
            KalturaClientBase.prototype.init.apply(this, arguments);
        };
        KalturaClient.prototype.setClientTag = function (clientTag) {
            this.requestData.clientTag = clientTag;
        };
        KalturaClient.prototype.getClientTag = function () {
            return this.requestData.clientTag;
        };
        KalturaClient.prototype.setApiVersion = function (apiVersion) {
            this.requestData.apiVersion = apiVersion;
        };
        KalturaClient.prototype.getApiVersion = function () {
            return this.requestData.apiVersion;
        };
        KalturaClient.prototype.setPartnerId = function (partnerId) {
            this.requestData.partnerId = partnerId;
        };
        KalturaClient.prototype.getPartnerId = function () {
            return this.requestData.partnerId;
        };
        KalturaClient.prototype.setKs = function (ks) {
            this.requestData.ks = ks;
        };
        KalturaClient.prototype.getKs = function () {
            return this.requestData.ks;
        };
        KalturaClient.prototype.setSessionId = function (sessionId) {
            this.requestData.ks = sessionId;
        };
        KalturaClient.prototype.getSessionId = function () {
            return this.requestData.ks;
        };
        KalturaRequestBuilder.prototype.setClientTag = function (clientTag) {
            this.requestData.clientTag = clientTag;
        };
        KalturaRequestBuilder.prototype.getClientTag = function () {
            return this.requestData.clientTag;
        };
        KalturaRequestBuilder.prototype.setApiVersion = function (apiVersion) {
            this.requestData.apiVersion = apiVersion;
        };
        KalturaRequestBuilder.prototype.getApiVersion = function () {
            return this.requestData.apiVersion;
        };
        KalturaRequestBuilder.prototype.setPartnerId = function (partnerId) {
            this.requestData.partnerId = partnerId;
        };
        KalturaRequestBuilder.prototype.getPartnerId = function () {
            return this.requestData.partnerId;
        };
        KalturaRequestBuilder.prototype.setKs = function (ks) {
            this.requestData.ks = ks;
        };
        KalturaRequestBuilder.prototype.getKs = function () {
            return this.requestData.ks;
        };
        KalturaRequestBuilder.prototype.setSessionId = function (sessionId) {
            this.requestData.ks = sessionId;
        };
        KalturaRequestBuilder.prototype.getSessionId = function () {
            return this.requestData.ks;
        };
        KalturaRequestBuilder.prototype.setResponseProfile = function (responseProfile) {
            this.requestData.responseProfile = responseProfile;
        };
        KalturaRequestBuilder.prototype.getResponseProfile = function () {
            return this.requestData.responseProfile;
        };
        var kalturalib = {};
        kalturalib.getkalturaconfiguration = function () {
            return new KalturaConfiguration();
        };
        kalturalib.getkalturaflavorassetservice = function () {
            return KalturaFlavorAssetService;
        };
        kalturalib.getkalturaclient = function ($config) {
            return KalturaClient;
        };
        return kalturalib;
    });

angular.module('mm.addons.mod_kalvidres')
    .constant('mmaModKalvidresVideosStore', 'mma_mod_kalvidres_videos')
    .config(["$mmSitesFactoryProvider", "mmaModKalvidresVideosStore", function ($mmSitesFactoryProvider, mmaModKalvidresVideosStore) {
        var stores = [
            {
                name: mmaModKalvidresVideosStore,
                keyPath: ['cmId'],
                indexes: [
                    {
                        name: 'cmId'
                    }
                ]
            }
        ];
        $mmSitesFactoryProvider.registerStores(stores);
    }])
    .factory('$mmaModKalvidres', ["$mmFilepool", "$mmSite", "$mmFS", "$http", "$log", "$q", "$mmSitesManager", "$mmUtil", "$mmText", "$mmCourse", "$mmaModKalvidresKalturalib", "mmaModKalvidresComponent", "mmaModKalvidresVideosStore", function ($mmFilepool, $mmSite, $mmFS, $http, $log, $q, $mmSitesManager, $mmUtil, $mmText, $mmCourse, $mmaModKalvidresKalturalib,
                                           mmaModKalvidresComponent, mmaModKalvidresVideosStore) {
        $log = $log.getInstance('$mmaModKalvidres');
        var self = {};
        self.getks = function (refresh) {
            var deferred = $q.defer();
            var params = {},
                preSets = {};
            if (refresh) {
                preSets.getFromCache = false;
            }
            $mmSite.read('mod_kalvidres_get_ks', params, preSets).then(function (response) {
                if (response.ks) {
                    deferred.resolve(response.ks);
                } else {
                    deferred.reject('Kaltura Error');
                }
            });
            return deferred.promise;
        };
        self.populatefurlfilenam = function (ks, video) {
            var deferred = $q.defer();
            var config = $mmaModKalvidresKalturalib.getkalturaconfiguration();
            config.serviceUrl = 'https://www.kaltura.com';
            var clientclass = $mmaModKalvidresKalturalib.getkalturaclient();
            var client = new clientclass(config);
            client.setKs(ks);
            var flavorassetservice = $mmaModKalvidresKalturalib.getkalturaflavorassetservice();
            flavorassetservice.getWebPlayableByEntryId(video.entry_id).execute(client, function (success, results) {
                if (!success || (results && results.code && results.message)) {
                    deferred.reject('Kaltura Error - getWebPlayableByEntryId');
                } else {
                    var maxbitrate = results.reduce(function (l, e) {
                        return e.bitrate > l.bitrate ? e : l;
                    });
                    flavorassetservice.getUrl(maxbitrate.id).execute(client, function (success, url) {
                        if (!success) {
                            deferred.reject('Kaltura Error - getUrl');
                        } else {
                            video.externalurl = url;
                            video.videourl = url;
                            video.filename = maxbitrate.id + '.' + maxbitrate.fileExt;
                            deferred.resolve(video);
                        }
                    });
                }
            });
            return deferred.promise;
        };
        self.isPluginEnabled = function (siteId) {
            return $mmSitesManager.getSite(siteId).then(function (site) {
                return site.canDownloadFiles();
            });
        };
        self.isGetKalturaVideoResWSAvailable = function () {
            return $mmSite.wsAvailable('mod_kalvidres_get_kalvidres_by_courses')
                && $mmSite.wsAvailable('mod_kalvidres_get_ks')
                && $mmSite.wsAvailable('mod_kalvidres_view_kalvidres');
        };
        self.buildpath = function (cmId, filename) {
            return filename;
        };
        self.getKalturaVideo = function (courseId, cmId, downloadfile) {
            return $mmSitesManager.getSite().then(function (site) {
                return site.getDb().get(mmaModKalvidresVideosStore, [cmId])
                    .then(
                        function (entry) {
                            return entry.video;
                        },
                        function () {
                            return site.read('mod_kalvidres_get_kalvidres_by_courses', {courseids: [courseId]}, {cacheKey: getKalturaVideoCacheKey(courseId)})
                                .then(function (videos) {
                                        var video;
                                        angular.forEach(videos.videos, function (kalturavideo) {
                                            if (!video && kalturavideo['coursemodule'] == cmId) {
                                                video = kalturavideo;
                                            }
                                        });
                                        var fullypopulatedvideopromise =
                                            self.getks()
                                                .then(function (ks) {
                                                    return self.populatefurlfilenam(ks, video);
                                                });
                                        var videowithvideourlsetpromise;
                                        if (downloadfile) {
                                            videowithvideourlsetpromise = fullypopulatedvideopromise.then(function () {
                                                return $mmFilepool.downloadUrl(site.id, video.externalurl, true, 'mmaModKalvidres', cmId, 0, undefined, {isexternalfile: true})
                                                    .then(function (url) {
                                                        video.videourl = url;
                                                    });
                                            });
                                        } else {
                                            videowithvideourlsetpromise = fullypopulatedvideopromise.then(function () {
                                                video.videourl = video.externalurl;
                                            });
                                        }
                                        return videowithvideourlsetpromise
                                            .then(function () {
                                                site.getDb().insert(mmaModKalvidresVideosStore, {cmId: cmId, video: video})
                                            })
                                            .then(function () {
                                                return video;
                                            });
                                    }
                                );
                        }
                    )
            });
        };
        function getKalturaVideoCacheKey(courseid) {
            return 'mmaModKalvidres:kalturavideo:' + courseid;
        }
        self.invalidateKalturaVideoData = function (moduleId, courseId, siteId) {
            return $mmSitesManager.getSite(siteId).then(function (site) {
                return $q.all([
                    site.invalidateWsCacheForKey(getKalturaVideoCacheKey(courseId)),
                    $mmFilepool.removeFilesByComponent(siteId, 'mmaModKalvidres', moduleId),
                    site.getDb().remove(mmaModKalvidresVideosStore, [moduleId])
                ]);
            });
        };
        self.invalidateContent = function (moduleId, courseId, siteId) {
            siteId = siteId || $mmSite.getId();
            var promises = [];
            promises.push(self.invalidateKalturaVideoData(moduleId, courseId, siteId));
            promises.push($mmFilepool.invalidateFilesByComponent(siteId, mmaModKalvidresComponent, moduleId));
            promises.push($mmCourse.invalidateModule(moduleId, siteId));
            return $mmUtil.allPromises(promises);
        };
        self.logView = function (id) {
            if (id) {
                var params = {
                    videoid: id
                };
                return $mmSite.write('mod_kalvidres_view_kalvidres', params);
            }
            return $q.reject();
        };
        return self;
    }])
;

angular.module('mm.addons.mod_kalvidres')
    .factory('$mmaModKalvidresPrefetchHandler', ["$mmPrefetchFactory", "mmaModKalvidresComponent", "$mmaModKalvidres", "$mmCourse", "$q", "mmCoreNotDownloaded", "mmCoreDownloaded", "$mmSitesManager", function ($mmPrefetchFactory, mmaModKalvidresComponent, $mmaModKalvidres, $mmCourse, $q, mmCoreNotDownloaded, mmCoreDownloaded, $mmSitesManager) {
            var self = $mmPrefetchFactory.createPrefetchHandler(mmaModKalvidresComponent, true);
            self.invalidateContent = function (moduleId, courseId) {
                return $mmaModKalvidres.invalidateContent(moduleId, courseId);
            };
            self.invalidateModule = function (module, courseId) {
                var promises = [];
                promises.push($mmaModKalvidres.invalidateKalturaVideoData(module.id, courseId));
                promises.push($mmCourse.invalidateModule(module.id));
                return $q.all(promises);
            };
            self.determineStatus = function (status, canCheck, module) {
                if (status === mmCoreDownloaded) {
                    return mmCoreOutdated;
                }
                return status;
            };
            self.removeFiles = function (module, courseId) {
                return $mmaModKalvidres.invalidateKalturaVideoData(module.id, courseId);
            };
            self.downloadOrPrefetchBase = self.downloadOrPrefetch;
            self.downloadOrPrefetch = function (module, courseId, prefetch, dirPath) {
                return self.downloadOrPrefetchBase(module, courseId, prefetch, dirPath)
                    .then($mmaModKalvidres.getKalturaVideo(courseId, module.id, true));
            };
            return self;
        }]
    );

angular.module('mm.addons.mod_kalvidres')
.filter('mmaModKalvidresVideoUrl', ['$sce', function ($sce) {
    return function(url) {
        return $sce.trustAsResourceUrl(url);
    };
}]);