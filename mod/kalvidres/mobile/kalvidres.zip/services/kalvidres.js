// (C) Copyright 2015 Martin Dougiamas
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

angular.module('mm.addons.mod_kalvidres')

    .constant('mmaModKalvidresVideosStore', 'mma_mod_kalvidres_videos')

    .config(function ($mmSitesFactoryProvider, mmaModKalvidresVideosStore) {
        var stores = [
            {
                name: mmaModKalvidresVideosStore,
                keyPath: ['cmId'],
                indexes: [
                    {
                        name: 'cmId'
                    }
                ]
            }
        ];
        $mmSitesFactoryProvider.registerStores(stores);
    })

    /**
     * Page factory.
     *
     * @module mm.addons.mod_kalvidres
     * @ngdoc service
     * @name $mmaModKalvidres
     */
    .factory('$mmaModKalvidres', function ($mmFilepool, $mmSite, $mmFS, $http, $log, $q, $mmSitesManager, $mmUtil, $mmText, $mmCourse, $mmaModKalvidresKalturalib,
                                           mmaModKalvidresComponent, mmaModKalvidresVideosStore) {
        $log = $log.getInstance('$mmaModKalvidres');

        var self = {};

        /**
         * Get a ks to instantiate an API client.
         *
         * @module mm.addons.mod_kalvidres
         * @ngdoc method
         * @name $mmaModKalvidres#getks
         * @param {Boolean} [refresh] True when we should not get the value from the cache.
         * @return {Promise}        Promise resolved when the chat is retrieved.
         */
        self.getks = function (refresh) {
            var deferred = $q.defer();

            var params = {},
                preSets = {};

            if (refresh) {
                preSets.getFromCache = false;
            }

            $mmSite.read('mod_kalvidres_get_ks', params, preSets).then(function (response) {
                if (response.ks) {
                    deferred.resolve(response.ks);
                } else {
                    deferred.reject('Kaltura Error');
                }
            });

            return deferred.promise;
        };

        /**
         * Get info needed to use a kaltura video
         *
         * @module mm.addons.mod_kalvidres
         * @ngdoc method
         * @name $mmaModKalvidres#getks
         * @param {Boolean} [refresh] True when we should not get the value from the cache.
         * @return {Promise}        Promise resolved with an object containing the url and filename of the video
         */
        self.populatefurlfilenam = function (ks, video) {
            var deferred = $q.defer();

            var config = $mmaModKalvidresKalturalib.getkalturaconfiguration();
            config.serviceUrl = 'https://www.kaltura.com';
            var clientclass = $mmaModKalvidresKalturalib.getkalturaclient();
            var client = new clientclass(config);
            client.setKs(ks);

            var flavorassetservice = $mmaModKalvidresKalturalib.getkalturaflavorassetservice();
            flavorassetservice.getWebPlayableByEntryId(video.entry_id).execute(client, function (success, results) {
                if (!success || (results && results.code && results.message)) {
                    deferred.reject('Kaltura Error - getWebPlayableByEntryId');
                } else {
                    var maxbitrate = results.reduce(function (l, e) {
                        return e.bitrate > l.bitrate ? e : l;
                    });

                    flavorassetservice.getUrl(maxbitrate.id).execute(client, function (success, url) {
                        if (!success) {
                            deferred.reject('Kaltura Error - getUrl');
                        } else {
                            video.externalurl = url;
                            video.videourl = url;
                            video.filename = maxbitrate.id + '.' + maxbitrate.fileExt;
                            deferred.resolve(video);
                        }
                    });
                }
            });

            return deferred.promise;
        };

        /**
         * Check if page plugin is enabled in a certain site.
         *
         * @module mm.addons.mod_kalvidres
         * @ngdoc method
         * @name $mmaModKalvidres#isPluginEnabled
         * @param  {String} [siteId] Site ID. If not defined, current site.
         * @return {Promise}         Promise resolved with true if plugin is enabled, rejected or resolved with false otherwise.
         */
        self.isPluginEnabled = function (siteId) {
            return $mmSitesManager.getSite(siteId).then(function (site) {
                return site.canDownloadFiles();
            });
        };

        /**
         * Returns whether or not getPage WS available or not.
         *
         * @module mm.addons.mod_kalvidres
         * @ngdoc method
         * @name $mmaModKalvidres#isGetKalturaVideoResWSAvailable
         * @return {Boolean}
         */
        self.isGetKalturaVideoResWSAvailable = function () {
            return $mmSite.wsAvailable('mod_kalvidres_get_kalvidres_by_courses')
                && $mmSite.wsAvailable('mod_kalvidres_get_ks')
                && $mmSite.wsAvailable('mod_kalvidres_view_kalvidres');
        };

        self.buildpath = function (cmId, filename) {
            return filename;
        };

        /**
         * Get a page by course module ID.
         *
         * @module mm.addons.mod_kalvidres
         * @ngdoc method
         * @name $mmaModKalvidres#getKalturaVideoData
         * @param {Number} courseId Course ID.
         * @param {Number} cmId     Course module ID.
         * @param {String} [siteId] Site ID. If not defined, current site.
         * @return {Promise}        Promise resolved when the book is retrieved.
         */
        self.getKalturaVideo = function (courseId, cmId, downloadfile) {
            return $mmSitesManager.getSite().then(function (site) {
                return site.getDb().get(mmaModKalvidresVideosStore, [cmId])
                    .then(
                        // If it is in the db then use it.
                        function (entry) {
                            return entry.video;
                        },
                        function () {
                            // Get all the kalvidres activities from this course (done in batch to optimise caching).
                            return site.read('mod_kalvidres_get_kalvidres_by_courses', {courseids: [courseId]}, {cacheKey: getKalturaVideoCacheKey(courseId)})
                                .then(function (videos) {
                                        var video;
                                        // Spin through the videos to find the one we're after.
                                        angular.forEach(videos.videos, function (kalturavideo) {
                                            if (!video && kalturavideo['coursemodule'] == cmId) {
                                                video = kalturavideo;
                                            }
                                        });
                                        var fullypopulatedvideopromise =
                                            // Get an API key.
                                            self.getks()
                                                .then(function (ks) {
                                                    // Get video data from kaltura.
                                                    return self.populatefurlfilenam(ks, video);
                                                });

                                        var videowithvideourlsetpromise;
                                        if (downloadfile) {
                                            // Download the file and use the new local URL.
                                            videowithvideourlsetpromise = fullypopulatedvideopromise.then(function () {
                                                return $mmFilepool.downloadUrl(site.id, video.externalurl, true, 'mmaModKalvidres', cmId, 0, undefined, {isexternalfile: true})
                                                    .then(function (url) {
                                                        video.videourl = url;
                                                    });
                                            });
                                        } else {
                                            // Don't download the file but use the external URL.
                                            videowithvideourlsetpromise = fullypopulatedvideopromise.then(function () {
                                                video.videourl = video.externalurl;
                                            });
                                        }

                                        return videowithvideourlsetpromise
                                        // Cache the final URL.
                                            .then(function () {
                                                site.getDb().insert(mmaModKalvidresVideosStore, {cmId: cmId, video: video})
                                            })
                                            .then(function () {
                                                // Return the video.
                                                return video;
                                            });
                                    }
                                );
                        }
                    )
            });
        };

        /**
         * Get cache key for page data WS calls.
         *
         * @param {Number} courseid Course ID.
         * @return {String}         Cache key.
         */
        function getKalturaVideoCacheKey(courseid) {
            return 'mmaModKalvidres:kalturavideo:' + courseid;
        }

        /**
         * Invalidates page data.
         *
         * @module mm.addons.mod_kalvidres
         * @ngdoc method
         * @name $mmaModKalvidres#invalidateBookData
         * @param {Number} courseId Course ID.
         * @param {String} [siteId] Site ID. If not defined, current site.
         * @return {Promise}        Promise resolved when the data is invalidated.
         */
        self.invalidateKalturaVideoData = function (moduleId, courseId, siteId) {
            return $mmSitesManager.getSite(siteId).then(function (site) {
                return $q.all([
                    site.invalidateWsCacheForKey(getKalturaVideoCacheKey(courseId)),
                    $mmFilepool.removeFilesByComponent(siteId, 'mmaModKalvidres', moduleId),
                    site.getDb().remove(mmaModKalvidresVideosStore, [moduleId])
                ]);
            });
        };

        /**
         * Invalidate the prefetched content.
         *
         * @module mm.addons.mod_kalvidres
         * @ngdoc method
         * @name $mmaModKalvidres#invalidateContent
         * @param  {Number} moduleId The module ID.
         * @param  {Number} courseId Course ID of the module.
         * @param  {String} [siteId] Site ID. If not defined, current site.
         * @return {Promise}
         */
        self.invalidateContent = function (moduleId, courseId, siteId) {
            siteId = siteId || $mmSite.getId();

            var promises = [];

            promises.push(self.invalidateKalturaVideoData(moduleId, courseId, siteId));
            promises.push($mmFilepool.invalidateFilesByComponent(siteId, mmaModKalvidresComponent, moduleId));
            promises.push($mmCourse.invalidateModule(moduleId, siteId));

            return $mmUtil.allPromises(promises);
        };

        /**
         * Report a page as being viewed.
         *
         * @module mm.addons.mod_kalvidres
         * @ngdoc method
         * @name $mmaModKalvidres#logView
         * @param {String} id Module ID.
         * @return {Promise}  Promise resolved when the WS call is successful.
         */
        self.logView = function (id) {
            if (id) {
                var params = {
                    videoid: id
                };
                return $mmSite.write('mod_kalvidres_view_kalvidres', params);
            }
            return $q.reject();
        };

        return self;
    })
;
