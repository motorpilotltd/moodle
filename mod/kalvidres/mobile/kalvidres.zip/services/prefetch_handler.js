// (C) Copyright 2015 Martin Dougiamas
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

angular.module('mm.addons.mod_kalvidres')

/**
 * Mod page prefetch handler.
 *
 * @module mm.addons.mod_kalvidres
 * @ngdoc service
 * @name $mmaModKalvidresPrefetchHandler
 */
    .factory('$mmaModKalvidresPrefetchHandler', function ($mmPrefetchFactory, mmaModKalvidresComponent, $mmaModKalvidres, $mmCourse, $q, mmCoreNotDownloaded, mmCoreDownloaded, $mmSitesManager) {

            var self = $mmPrefetchFactory.createPrefetchHandler(mmaModKalvidresComponent, true);


            /**
             * Invalidate the prefetched content.
             *
             * @module mm.addons.mod_kalvidres
             * @ngdoc method
             * @name $mmaModKalvidresPrefetchHandler#invalidateContent
             * @param  {Number} moduleId The module ID.
             * @param  {Number} courseId Course ID of the module.
             * @return {Promise}
             */
            self.invalidateContent = function (moduleId, courseId) {
                return $mmaModKalvidres.invalidateContent(moduleId, courseId);
            };

            /**
             * Invalidates WS calls needed to determine module status.
             *
             * @module mm.addons.mod_kalvidres
             * @ngdoc method
             * @name $mmaModKalvidresPrefetchHandler#invalidateModule
             * @param  {Object} module   Module to invalidate.
             * @param  {Number} courseId Course ID the module belongs to.
             * @return {Promise}         Promise resolved when done.
             */
            self.invalidateModule = function (module, courseId) {
                var promises = [];

                promises.push($mmaModKalvidres.invalidateKalturaVideoData(module.id, courseId));
                promises.push($mmCourse.invalidateModule(module.id));

                return $q.all(promises);
            };

            self.determineStatus = function (status, canCheck, module) {
                if (status === mmCoreDownloaded) {
                    // Show outdated since we can't tell if it was updated.
                    return mmCoreOutdated;
                }
                return status;
            };

            // Override removeFiles function so that we also clear out cached local URL to video.
            self.removeFiles = function (module, courseId) {
                return $mmaModKalvidres.invalidateKalturaVideoData(module.id, courseId);
            };

            // Override downloadOrPrefetch function to also make calls to Kaltura webservice and download video.
            self.downloadOrPrefetchBase = self.downloadOrPrefetch;
            self.downloadOrPrefetch = function (module, courseId, prefetch, dirPath) {
                return self.downloadOrPrefetchBase(module, courseId, prefetch, dirPath)
                    .then($mmaModKalvidres.getKalturaVideo(courseId, module.id, true));
            };

            return self;
        }
    );
